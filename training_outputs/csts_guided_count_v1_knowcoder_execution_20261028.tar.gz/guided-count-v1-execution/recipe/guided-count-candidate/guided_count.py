"""One fixed condition-derived native count recipe; no target-answer selection.

Concrete mention classes and three same-schema demonstrations adapt the task
interface. Span validation, literal stage union and the conservative aggregator
are unchanged from reviewed whitespace-v5. This is a development candidate,
never a passed general counting capability.
"""
from pathlib import Path
import hashlib
import json
from native_adapter.schema import compile_condition, native_prompt, implementation_identity, plan_digest, selected_schemas
from native_adapter.normalize import normalize_native, normalize_stages, _constructors

ROOT=Path(__file__).resolve().parent
PROFILE='native_guided_count_same_schema_v1'
STAGES=('mentions','quantity_bindings','identity')
SYSTEM='You are a highly skilled assistant at digesting and extracting information from textual content. Below is an input containing standard type definitions and textual content. Please complete it with the extracted information in the form of structured code.'
DEFINITIONS={
 'Person':'An explicitly mentioned person or group of people, including occupational or age terms.',
 'Animal':'An explicitly mentioned animal or group of animals, including species names.',
 'Woman':'An explicitly identified woman or group of women. Do not label a child, baby or other person as Woman without explicit supporting wording.',
 'Wheel':'An explicitly mentioned wheel or group of wheels. A vehicle does not state how many wheels are present; do not infer unmentioned parts.'}
MENTION_SUFFIX=' Copy the smallest complete target noun phrase, including its determiner, cardinal quantity and adjectives; retain modifiers needed to distinguish referents, but exclude the following main predicate/action clause. Include subset and repeated referring phrases separately. Do not emit a bare numeral as a target.'
QUANTITY='An explicit cardinal word, cardinal phrase or numeral stating how many target individuals a noun phrase denotes. Copy only that explicit quantity expression. Exclude articles a/an/another, vague phrases such as a number of, and identifiers including badges, tags, jerseys, serials and tickets. Never invent a numeric word for an article.'
RELATIONS={
 'HasQuantity':'The first argument is a complete target noun phrase; the second is its explicit cardinal quantity expression from candidate_mentions. Copy both exactly. No arithmetic or unstated counts. Identifiers are not quantities.',
 'SameReferent':'Two complete target referring phrases explicitly denoting the same individual or group. Copy both phrases, preserving their different determiners; mere similar wording is not sufficient.',
 'DistinctFrom':'Two complete target noun phrases explicitly denoting disjoint individuals/groups. A separately introduced individual can be disjoint from a group; do not infer disjointness merely from two mentions.',
 'PartOf':'First argument: a complete target phrase denoting a member/subset. Second argument: the complete containing target group phrase. Only explicit or unambiguous subset reference; never add that member again.'}


def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def compile_guided(condition):
    plan=compile_condition(condition)
    if not plan['supported'] or plan['family']!='aggregate_counts_quantities':
        raise ValueError('Guided recipe requires a supported ordinary count condition')
    label=plan['schemas'][0]['name'].removesuffix('Group')
    if label not in DEFINITIONS:raise ValueError('No frozen independent same-schema scene for this ontology')
    old=plan['schemas'][0]['name']
    for schema in plan['schemas']:
        if schema['kind']=='entity' and schema['target_type']!='Quantity':
            prefix='Negated' if schema['polarity']=='negative' else 'Uncertain' if schema['polarity']=='uncertain' else ''
            schema['name']=prefix+label
            schema['description']=DEFINITIONS[label]+MENTION_SUFFIX
        elif schema['name']=='Quantity':
            schema['description']=QUANTITY
            schema['answer_role']='context'
        elif schema['name'] in RELATIONS:schema['description']=RELATIONS[schema['name']]
    plan['guided_count_recipe']={'profile':PROFILE,'ontology':label,'previous_mention_class':old,
        'schema_adapted':True,'same_schema_demonstrations_per_stage':1,
        'aggregation_changed':False,'model_arithmetic_requested':False}
    return plan


def demonstration(plan):
    raw=(ROOT/'demonstrations.json').read_bytes()
    examples=json.loads(raw)
    return examples[plan['guided_count_recipe']['ontology']]


def demo_payload(plan,model,stage):
    example=demonstration(plan);name=plan['guided_count_recipe']['ontology']
    spans=example['target_mentions'];quantities=example['quantity_mentions']
    if stage=='mentions':
        records=[(name,[s]) for s in spans]+[('Quantity',[s]) for s in quantities]
    elif stage=='quantity_bindings':records=[('HasQuantity',pair) for pair in example['quantity_bindings']]
    elif stage=='identity':records=[(kind,[a,b]) for kind,a,b in example['identity']]
    else:raise ValueError('Unknown guided count stage')
    def q(value):return json.dumps(value,ensure_ascii=False)
    values=[]
    for constructor,args in records:
        if stage=='mentions':values.append(constructor+'('+('span=' if model=='gollie' else '')+q(args[0])+')')
        elif model=='knowcoder':values.append(constructor+'('+','.join('Entity('+q(v)+')' for v in args)+')')
        else:values.append(constructor+'(arg1='+q(args[0])+',arg2='+q(args[1])+')')
    return ('results = ' if model=='knowcoder' else '')+'['+','.join(values)+']'


def candidate_state(payload,plan,model,passage):
    """Project only literal stage1 annotations after source-span validation."""
    normalize_native(payload,plan,model,passage,count_stage='mentions',profile='positive_anchor',coverage_complete=False)
    parsed=_constructors(payload,plan,model,count_stage='mentions',profile='positive_anchor')
    field='name' if model=='knowcoder' else 'span'
    candidates={plan['guided_count_recipe']['ontology']:[], 'Quantity':[]}
    for item in parsed:
        name=item['constructor'];span=item['fields'][field]
        if name not in candidates:raise ValueError('Unexpected candidate class')
        if span not in candidates[name]:candidates[name].append(span)
    return {'stage1_payload_sha256':digest(payload.encode()),'candidates':candidates,
        'canonical_candidates_sha256':digest(encoded(candidates))}


def _with_candidates(prompt,model,state):
    block='# Previously extracted candidate mentions; use only these literal arguments and verify each relation in the source. Do not invent missing candidates.\ncandidate_mentions = '+json.dumps(state['candidates'],ensure_ascii=False,sort_keys=True)
    if model=='knowcoder':
        if not prompt.endswith('\nOutput:\n'):raise ValueError('Know completion marker changed')
        return prompt[:-len('\nOutput:\n')]+'\n'+block+'\nOutput:\n'
    marker='\n\n# The annotation instances'
    if marker not in prompt:raise ValueError('Go completion marker changed')
    start,end=prompt.rsplit(marker,1)
    return start+'\n\n'+block+marker+end


def guided_prompt(plan,model,passage,stage,prior=None):
    if stage not in STAGES:raise ValueError('Unknown guided count stage')
    example=demonstration(plan)
    demo=native_prompt(plan,model,example['sentence'],count_stage=stage,profile='positive_anchor')
    target=native_prompt(plan,model,passage,count_stage=stage,profile='positive_anchor')
    answer=demo_payload(plan,model,stage)
    if stage!='mentions':
        if prior is None:raise ValueError('Conditional count stage requires its actual parsed stage1 output')
        state=candidate_state(prior['payload'],plan,model,passage)
        demo_state=candidate_state(demo_payload(plan,model,'mentions'),plan,model,example['sentence'])
        target=_with_candidates(target,model,state)
        demo=_with_candidates(demo,model,demo_state)
    if model=='knowcoder':
        prefix=SYSTEM+'\nInput:\n'
        if not target.startswith(prefix) or not demo.startswith(prefix):raise ValueError('Canonical Know wrapper changed')
        return demo+answer+'\nInput:\n'+target[len(prefix):]
    if model=='gollie':return demo+' '+answer+'\n\n'+target
    raise ValueError('Unknown native model')


def support_identity():
    return {'guided_count_module_sha256':digest(Path(__file__).read_bytes()),
        'demonstrations_sha256':digest((ROOT/'demonstrations.json').read_bytes()),
        'compiler_implementation_files':implementation_identity(),
        'compiler_implementation_sha256':digest(encoded(implementation_identity()))}


def bind_stage(plan,model,passage,stage,count_tokens,prior=None):
    prompt=guided_prompt(plan,model,passage,stage,prior=prior);tokens=count_tokens(prompt)
    context=2048 if model=='knowcoder' else 16384
    if type(tokens) is not int or tokens<1 or tokens+512>context:
        raise ValueError('Actual guided stage tokens plus512 reserve do not fit; no truncation')
    result={'prompt':prompt,'model':model,'count_stage':stage,'task_stage':None,'profile':'positive_anchor',
        'prompt_profile':PROFILE,'input_tokens':tokens,'max_new_tokens':512,'context_limit':context,
        'plan_sha256':plan_digest(plan),'prompt_sha256':digest(prompt.encode()),
        'implementation_sha256':implementation_identity(),'guided_count_identity':support_identity(),
        'target_prompt_sha256':digest(native_prompt(plan,model,passage,count_stage=stage,profile='positive_anchor').encode())}
    if stage!='mentions':
        state=candidate_state(prior['payload'],plan,model,passage)
        result['prior_stage1']={**state,'stage1_binding_sha256':digest(encoded(prior['bound'])),
            'stage1_output_token_ids_sha256':digest(encoded(prior['output_token_ids']))}
    return result


def verify_binding(bound,plan,model,passage,count_tokens,prior=None):
    expected=bind_stage(plan,model,passage,bound['count_stage'],count_tokens,prior=prior)
    if bound!=expected:raise ValueError('Guided count source/schema/demo/prior/tokenizer binding changed')
    return True


def validate_downstream(payload,plan,model,passage,stage,prior):
    """Reject new endpoints; never repair a model's omitted candidates or links."""
    state=candidate_state(prior['payload'],plan,model,passage)
    target=plan['guided_count_recipe']['ontology']
    allowed=state['candidates']
    parsed=_constructors(payload,plan,model,count_stage=stage,profile='positive_anchor')
    definitions={s['name']:s for s in selected_schemas(plan,model,count_stage=stage,profile='positive_anchor')}
    for item in parsed:
        values=[item['fields'][role] for role in definitions[item['constructor']]['fields']]
        spans=[v['fields']['name'] if isinstance(v,dict) else v for v in values]
        right='Quantity' if stage=='quantity_bindings' else target
        if spans[0] not in allowed[target] or spans[1] not in allowed[right]:
            raise ValueError('Downstream relation invents an endpoint absent from actual stage1 candidates')
    return normalize_native(payload,plan,model,passage,count_stage=stage,profile='positive_anchor',coverage_complete=False)

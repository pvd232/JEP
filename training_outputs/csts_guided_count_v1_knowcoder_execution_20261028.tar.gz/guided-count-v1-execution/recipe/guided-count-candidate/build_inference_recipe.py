"""Freeze source/plan/stage1 prompts and conditional target-template hashes, no model calls."""
from pathlib import Path
import json
import guided_count as guide
import guided_count_capture as capture
import native_capture as runtime


def main():
    rows=[]
    for source in capture.sources():
        plan=guide.compile_guided(source['condition']);bounds={}
        for model in ('knowcoder','gollie'):
            mid,rev=(('golaxy/KnowCoder-7B-IE','90ba076763dfb2e9efefd84a0e599f15ae533597') if model=='knowcoder' else
                     ('HiTZ/GoLLIE-7B','d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9'))
            codec,_=runtime._cpu_codec(model,{'model_id':mid,'revision':rev,'tokenizer_id':mid,'tokenizer_revision':rev})
            bound=guide.bind_stage(plan,model,source['passage'],'mentions',codec.count_tokens)
            bounds[model]={'mentions':bound,'conditional_stages':{stage:{'stage':stage,
                'input_template':'same-schema demonstration + unchanged-source target + own parsed stage1 candidate_mentions',
                'target_prompt_sha256':guide.digest(guide.native_prompt(plan,model,source['passage'],count_stage=stage,profile='positive_anchor').encode()),
                'max_new_tokens':512,'runtime_exact_token_bound_required':True} for stage in guide.STAGES[1:]}}
        rows.append({'source':source,'plan':plan,'plan_sha256':guide.plan_digest(plan),'requests':bounds})
    packet={'status':'FROZEN_GUIDED_COUNT_DEVELOPMENT_REQUEST_RECIPE','sources':6,'stages_per_source':3,
        'profile':guide.PROFILE,'stage1_exact_prompts_frozen':True,'downstream_exact_prompts_bound_after_own_stage1':True,
        'model_quality_passed':False,'items':rows,'guided_count_identity':guide.support_identity()}
    (Path(__file__).parent/'inference-recipe.json').write_text(json.dumps(packet,ensure_ascii=False,sort_keys=True,indent=2)+'\n')

if __name__=='__main__':main()

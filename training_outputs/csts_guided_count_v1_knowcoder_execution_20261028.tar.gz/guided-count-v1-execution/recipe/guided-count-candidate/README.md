# Fixed conditional guided-count development recipe

This is one declared adaptation of the failed independent count stages, using
the same six already-exposed sources and checkpoints. It does not enable general
counting or establish a counting-quality gate. No target reference annotations
are read. The original finite run and prompt bytes remain separate and unchanged.

The condition alone chooses the concrete native class Person, Animal, Woman or
Wheel. Full target noun phrases preserve determiners, cardinals, adjectives and
identifying modifiers. Quantity annotations contain explicit cardinal expressions
only. Articles remain in target noun phrases; no Quantity object or literal
numeric word is invented for a/an/another. Badge, tag, jersey, ticket and serial
numbers are excluded by the task definitions and independent examples.

Each ontology has one independent synthetic scene, fixed across its conditions
and targets. It demonstrates a quantified group, a separately introduced
singleton, an explicit subset, a definite remention and an unrelated identifier.
The same scene supplies the mentions, HasQuantity and identity demonstrations,
using the exact target stage's schema. Demonstrations contain no totals or
arithmetic. These are new task/schema/prompt bytes, not an unchanged-target
ablation or a claim that all definitions already appeared in author training.

The actual pipeline is conditional. Stage1 emits concrete target and explicit
Quantity mentions. The AST parser and literal source-span normalizer validate
those outputs. Both later stages receive the original source plus only that
run's parsed stage1 candidate inventory. Each downstream binding records the
prior raw payload SHA, output-token-ID SHA, bound-request SHA and canonical
candidate SHA. It rejects any relation endpoint absent from its own candidate
inventory. Nothing is supplied from target references, demonstration candidates,
a regex repair, another model or a missing-edge heuristic.

Invalid/truncated stage1 leaves both downstream slots unrun as failures. A valid
empty list remains a real abstention and later stages can return empty lists.
Stage2 parse failure does not suppress the independent identity stage, which
also depends only on stage1. API failures stop remaining requests. Every planned
slot stays in the fixed18-stage denominator/model; no retries or replacement
cases are selected. Runtime budgets use the actual tokenizer with512 reserved
output tokens, and reject rather than truncate an oversized conditional prompt.

The unchanged reviewed whitespace-v5 AST normalizer and counts.py aggregate only
the literal union of valid stage outputs. Existing article/quantifier semantics
remain unchanged. No arithmetic is requested from either model, and no missing
quantity or identity edge is repaired. Coverage and semantic support remain
unvalidated; totals cannot be promoted to exact scene counts.

Use the separately approved provider on PYTHONPATH before this candidate, and
run one model/process with the existing historical native backend/settings:

```
HISTORICAL_PYTHON -m run_guided_count --model knowcoder --protocol protocol-knowcoder.json --output NEW_OUTPUT
HISTORICAL_PYTHON -m run_guided_count --model gollie --protocol protocol-gollie.json --output ANOTHER_NEW_OUTPUT
```

Raw stage prompts, input/output token IDs, candidates, dependencies, backend
identity and failed/unrun slots are retained. The provider remains unchanged;
this package binds its full ten-module compiler identity plus its own guided
module, synthetic demonstrations and six-source inventory in a new protocol.
Locked/fresh sources, per-case recipe branches and production dispatch are absent.

Explicit cardinal Quantity records are auxiliary context, so an isolated number
cannot itself mark the requested count as answered. The complete target NPs and
source-supported bindings provide candidate evidence. Articles are not extracted
as Quantity objects, and the existing conditional article interpretation in the
aggregator is left intact. Missing explicit Quantity candidates remain missing.

The two canonical protocol files bind the agreed deployment root
`/content/jep-native-author-calibration-20261028/guided-count-v1-execution`, with
provider in `provider/native-general-capture` and this candidate in
`recipe/guided-count-candidate`. Their exact source inventory, module/demo/recipe
bytes, checkpoints, tokenizers, runtime receipts, backend options, and512 output
budget are frozen. Go's copied driver shim is byte-identical to the previously
reviewed one. No new dependency, driver, global cache or model implementation
change is required.

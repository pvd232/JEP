"""Finite conditional guided-count development operator; never production counts."""
import hashlib
import json
from pathlib import Path
import native_capture as runtime
import guided_count as guide

ROOT=Path(__file__).resolve().parent
STAGES=guide.STAGES


def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return guide.encoded(value)


def sources():
    return json.loads((ROOT/'sources.json').read_bytes())


def authorization():
    return {'purpose':'six_exposed_conditional_guided_count_v1',
        'sources_sha256':digest((ROOT/'sources.json').read_bytes()),
        'inference_recipe_sha256':digest((ROOT/'inference-recipe.json').read_bytes()),
        'source_ids':[s['id'] for s in sources()],
        'guided_count_identity':guide.support_identity(),
        'schema_profile':'positive_anchor','prompt_profile':guide.PROFILE,
        'stages':list(STAGES),'dependency':'binding_and_identity_use_only_own_validated_stage1_candidates',
        'max_model_calls_per_source':3,'stage_slots_per_model':18,
        'model_quality_passed':False,'production_count_dispatch_enabled':False,
        'coverage_complete':False,'aggregator_changed':False}


def verify_configuration(source,model,protocol):
    cfg=protocol['models'][model]['native_capture']
    descriptor=protocol['models'][model]
    expected={s['id']:s for s in sources()}
    if source.get('id') not in expected or source!=expected[source['id']]:
        raise ValueError('Guided count source is outside frozen six-source inventory')
    if model not in {'knowcoder','gollie'}:raise ValueError('Unknown native model')
    if descriptor['handler']!={'module':'guided_count_capture','callable':'capture_one','sha256':digest(Path(__file__).read_bytes())}:
        raise ValueError('Guided count handler changed')
    if descriptor['max_model_calls_per_source']!=3 or type(descriptor['max_model_calls_per_source']) is not int:
        raise ValueError('Guided count requires three fixed slots per source')
    if cfg.get('guided_count_development')!=authorization():raise ValueError('Guided conditional recipe identity changed')
    if cfg['max_new_tokens']!=512 or cfg['profile']!='positive_anchor' or cfg['prompt_profile']!=guide.PROFILE:
        raise ValueError('Guided recipe profile/output budget changed')
    if cfg['context_limit']!=(2048 if model=='knowcoder' else 16384):raise ValueError('Reviewed context bound changed')
    if cfg.get('stage_overrides') not in (None,{}):raise ValueError('No per-stage profile/budget alternatives')
    runtime._verify_support(cfg)
    if cfg['generation'].get('do_sample') is not False or cfg['generation'].get('num_beams')!=1 or cfg['generation'].get('num_return_sequences')!=1:
        raise ValueError('Guided recipe requires one greedy output')
    if model=='knowcoder' and (cfg['generation'].get('gpu_memory_utilization')!=0.6 or cfg['generation'].get('max_num_seqs')!=4):
        raise ValueError('Reviewed resource cap changed')
    return cfg,guide.compile_guided(source['condition'])


def capture_one(source,model,protocol):
    result={'id':source.get('id'),'model':model,'protocol_canonical_sha256':digest(encoded(protocol)),
        'route_supported':False,'development_authorized':False,'model_quality_passed':False,
        'production_count_dispatch_enabled':False,'coverage_complete':False,'parse_valid':False,
        'semantic_support_validated':False,'runtime_status':'not_run','truncated':False,
        'raw_output':None,'normalized_evidence':None,'error':'','model_calls':0,
        'bound_inputs':[],'bound_input_verified':False,'stage_outputs':[],
        'automatic_retries':False,'automatic_companion_cases':False,'planned_stage_slots':3,
        'conditional_stages':True}
    session=None;before=0;prior=None;payloads={};fatal=None;sent=[]
    try:
        cfg,plan=verify_configuration(source,model,protocol)
        result.update(route_supported=True,development_authorized=True,plan_sha256=guide.plan_digest(plan))
        with runtime._LOCK:
            session=runtime._session(model,cfg);before=session.calls
            for stage in STAGES:
                entry={'stage':stage,'runtime_status':'not_run','parse_valid':False,'generated':None,
                    'model_calls':0,'error':''}
                result['stage_outputs'].append(entry)
                if fatal is not None or (stage!='mentions' and prior is None):
                    entry['error']='Not run: '+(fatal or 'stage1 did not produce valid source-grounded candidates')
                    continue
                prior_for_stage=prior if stage!='mentions' else None
                bound=guide.bind_stage(plan,model,source['passage'],stage,session.count_tokens,prior=prior_for_stage)
                guide.verify_binding(bound,plan,model,source['passage'],session.count_tokens,prior=prior_for_stage)
                entry['bound_input']=bound
                calls_before=session.calls
                try:
                    generated=session.generate(bound)
                except Exception as error:
                    entry.update(runtime_status='timeout' if isinstance(error,TimeoutError) else 'error',error=type(error).__name__+': '+str(error))
                    if getattr(session,'last_raw',None) is not None:entry['raw_backend_error_response']=session.last_raw
                    fatal=entry['error']
                    continue
                finally:
                    delta=session.calls-calls_before
                    if delta not in (0,1):raise ValueError('Backend made undeclared request count')
                    entry['model_calls']=delta
                    if delta:
                        result['bound_inputs'].append(bound);sent.append((bound,prior_for_stage))
                entry['generated']=generated
                if generated['truncated']:
                    entry.update(runtime_status='truncated',error='Native output budget exhausted')
                    result['truncated']=True
                    if stage=='mentions':fatal='Invalid stage1: truncated output'
                    continue
                try:
                    if stage=='mentions':
                        guide.candidate_state(generated['payload'],plan,model,source['passage'])
                        prior={'payload':generated['payload'],'bound':bound,'output_token_ids':generated['output_token_ids']}
                    else:guide.validate_downstream(generated['payload'],plan,model,source['passage'],stage,prior)
                    entry.update(runtime_status='ok',parse_valid=True)
                    payloads[stage]=generated['payload']
                except (ValueError,SyntaxError,RecursionError) as error:
                    entry.update(runtime_status='error',error=type(error).__name__+': '+str(error))
                    if stage=='mentions':fatal='Invalid stage1: '+entry['error']
            if len(payloads)==3:
                result['normalized_evidence']=guide.normalize_stages(payloads,plan,model,source['passage'],coverage_complete=False,profile='positive_anchor')
                result.update(runtime_status='ok',parse_valid=True)
            else:
                result.update(runtime_status='truncated' if result['truncated'] else 'error',
                    error='One or more fixed guided stages failed or remained unrun')
            result['bound_input_verified']=all(guide.verify_binding(b,plan,model,source['passage'],session.count_tokens,prior=p) for b,p in sent) and bool(sent)
    except Exception as error:
        result.update(runtime_status='timeout' if isinstance(error,TimeoutError) else 'error',error=type(error).__name__+': '+str(error))
    finally:
        if session is not None:
            result['model_calls']=session.calls-before
            if result['model_calls']:result['backend_metadata']=session.metadata
        present={entry['stage']:entry['generated']['payload'] for entry in result['stage_outputs'] if entry.get('generated') is not None}
        result['raw_output']=json.dumps(present,ensure_ascii=False,sort_keys=True) if present else None
        # Every planned slot remains visible even a static/initial binding error.
        seen={entry['stage'] for entry in result['stage_outputs']}
        for stage in STAGES:
            if stage not in seen:result['stage_outputs'].append({'stage':stage,'runtime_status':'not_run','parse_valid':False,'generated':None,'model_calls':0,'error':result['error']})
    return result

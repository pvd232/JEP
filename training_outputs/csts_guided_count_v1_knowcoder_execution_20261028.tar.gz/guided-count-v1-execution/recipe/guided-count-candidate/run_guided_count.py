"""Run exactly the frozen six exposed sources through the conditional count recipe."""
import argparse
import json
import os
from pathlib import Path
import uuid
import guided_count_capture as capture


def write_once(path,value):
    raw=capture.encoded(value)
    temporary=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as out:out.write(raw);out.flush();os.fsync(out.fileno())
        os.link(temporary,path)
    finally:
        if temporary.exists():temporary.unlink()


def run(model,protocol,output):
    sources=capture.sources()
    if len(sources)!=6:raise ValueError('Expected the frozen six-source development inventory')
    for source in sources:capture.verify_configuration(source,model,protocol)
    output=Path(output);output.mkdir(exist_ok=False)
    write_once(output/'protocol.json',protocol)
    write_once(output/'authorization.json',capture.authorization())
    results=[]
    for index,source in enumerate(sources):
        folder=output/('%02d-'%index+source['id']);folder.mkdir()
        write_once(folder/'attempt.json',{'source':source,'protocol_sha256':capture.digest(capture.encoded(protocol)),
            'source_claimed_once':True,'no_resume_or_retry':True})
        result=capture.capture_one(source,model,protocol)
        write_once(folder/'result.json',result);results.append(result)
    summary={'sources':6,'planned_stage_slots':18,'conditional_recipe':True,
        'model_calls':sum(r['model_calls'] for r in results),
        'valid_stage_slots':sum(s['parse_valid'] for r in results for s in r['stage_outputs']),
        'failed_or_unrun_stage_slots':sum(not s['parse_valid'] for r in results for s in r['stage_outputs']),
        'operationally_complete_sources':sum(r['runtime_status']=='ok' and r['parse_valid'] for r in results),
        'model_quality_passed':False,'production_count_dispatch_enabled':False,'coverage_complete':False,
        'semantic_support_validated':False,'fixed_denominator':True}
    write_once(output/'summary.json',summary);return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=('knowcoder','gollie'),required=True)
    parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();protocol=json.loads(args.protocol.read_bytes())
    print(json.dumps(run(args.model,protocol,args.output),sort_keys=True))

if __name__=='__main__':main()

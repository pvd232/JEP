"""Pure configuration preparation using the previously reviewed runtime protocol."""
from pathlib import Path
import json
import guided_count_capture as capture
import guided_count as guide

ROOT=Path(__file__).resolve().parent
DEPLOY=Path('/content/jep-native-author-calibration-20261028/guided-count-v1-execution')
PREVIOUS=Path('/tmp/jep-finite-count-runtime-20261028')


def main():
    for model in ('knowcoder','gollie'):
        previous=json.loads((PREVIOUS/('protocol-'+model+'.json')).read_bytes())
        cfg=previous['models'][model]['native_capture']
        del cfg['finite_count_development']
        cfg['guided_count_development']=capture.authorization()
        cfg['prompt_profile']=guide.PROFILE
        cfg['support_manifest_path']=str(DEPLOY/'provider/native-general-capture/support-seal.json')
        if model=='gollie':cfg['runtime_shim']['path']=str(DEPLOY/'recipe/guided-count-candidate/driver_runtime_shim.py')
        protocol={'status':'FROZEN_FINITE_CONDITIONAL_GUIDED_COUNT_DEVELOPMENT_V1',
            'scope':'Exactly the six exposed sources, one fixed ontology/stage recipe; ownstage1 candidates only in conditional relations.',
            'model_quality_passed':False,'production_count_dispatch_enabled':False,
            'shared_gpu':True,'timing_isolated':False,
            'models':{model:{'handler':{'module':'guided_count_capture','callable':'capture_one',
                'sha256':capture.digest(Path(capture.__file__).read_bytes())},
                'max_model_calls_per_source':3,'native_capture':cfg}}}
        for source in capture.sources():capture.verify_configuration(source,model,protocol)
        raw=capture.encoded(protocol)
        (ROOT/('protocol-'+model+'.json')).write_bytes(raw)
        print(model,capture.digest(raw))

if __name__=='__main__':main()

"""CPU-only source/demo/pipeline proofs; fake outputs never establish quality."""
from copy import deepcopy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import guided_count as guide
import guided_count_capture as capture
import native_capture as runtime
from build_protocol import runtime_config

CONDITIONS={'Person':'number of people','Animal':'number of animals','Woman':'number of women','Wheel':'number of wheels'}


def codec(model):
    if model=='knowcoder':mid,rev='golaxy/KnowCoder-7B-IE','90ba076763dfb2e9efefd84a0e599f15ae533597'
    else:mid,rev='HiTZ/GoLLIE-7B','d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9'
    return runtime._cpu_codec(model,{'model_id':mid,'revision':rev,'tokenizer_id':mid,'tokenizer_revision':rev})[0]


class FakeBackend:
    instances=0;payloads={};fail_mentions=False;truncate_mentions=False
    def __init__(self,model,cfg):
        type(self).instances+=1;self.calls=0;self.model=model;self.codec=codec(model);self.metadata={'fake_backend':True};self.last_raw=None
    def count_tokens(self,text):return self.codec.count_tokens(text)
    def generate(self,bound):
        self.calls+=1;stage=bound['count_stage'];payload=self.payloads[stage]
        if stage=='mentions' and self.fail_mentions:payload="__import__('os').system('false')"
        return {'payload':payload,'input_token_ids':self.codec.encode(bound['prompt']),
            'output_token_ids':self.codec.encode(payload)[1:]+[2],
            'truncated':stage=='mentions' and self.truncate_mentions}


def protocol(model):
    # Fake runtime receipt is never opened by this fake backend.
    identity=runtime.support_identity()
    cfg={'support_manifest_sha256':identity['support_manifest_sha256'],
        'compiler_implementation_sha256':identity['compiler_implementation_sha256'],
        'compiler_implementation_files':identity['compiler_implementation_files'],
        'model_id':'golaxy/KnowCoder-7B-IE' if model=='knowcoder' else 'HiTZ/GoLLIE-7B',
        'revision':'90ba076763dfb2e9efefd84a0e599f15ae533597' if model=='knowcoder' else 'd3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9',
        'tokenizer_id':'golaxy/KnowCoder-7B-IE' if model=='knowcoder' else 'HiTZ/GoLLIE-7B',
        'tokenizer_revision':'90ba076763dfb2e9efefd84a0e599f15ae533597' if model=='knowcoder' else 'd3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9',
        'backend':'author_vllm_0.2.2_cu118' if model=='knowcoder' else 'pinned_original_flash_model',
        'dtype':'float16' if model=='knowcoder' else 'bfloat16','snapshot':'fake',
        'runtime_manifest_path':'fake','runtime_manifest_sha256':'0'*64,
        'profile':'positive_anchor','prompt_profile':guide.PROFILE,'max_new_tokens':512,
        'context_limit':2048 if model=='knowcoder' else 16384,'stage_overrides':{},
        'generation':{'do_sample':False,'num_beams':1,'num_return_sequences':1,'gpu_memory_utilization':0.6,'max_num_seqs':4},
        'guided_count_development':capture.authorization()}
    return {'models':{model:{'handler':{'module':'guided_count_capture','callable':'capture_one','sha256':capture.digest(Path(capture.__file__).read_bytes())},'max_model_calls_per_source':3,'native_capture':cfg}}}


class GuidedTests(unittest.TestCase):
    def test_same_schema_demos_all_ontologies_models_and_stages(self):
        for label,condition in CONDITIONS.items():
            plan=guide.compile_guided(condition);example=guide.demonstration(plan)
            self.assertEqual(plan['schemas'][0]['name'],label)
            for model in ('knowcoder','gollie'):
                raw=guide.demo_payload(plan,model,'mentions')
                state=guide.candidate_state(raw,plan,model,example['sentence'])
                self.assertEqual(state['candidates'][label],example['target_mentions'])
                self.assertEqual(state['candidates']['Quantity'],example['quantity_mentions'])
                self.assertEqual(len(example['quantity_mentions']),2)
                prior={'payload':raw,'bound':{'synthetic_demo':True},'output_token_ids':[]}
                payloads={'mentions':raw}
                for stage in guide.STAGES[1:]:
                    payloads[stage]=guide.demo_payload(plan,model,stage)
                    guide.validate_downstream(payloads[stage],plan,model,example['sentence'],stage,prior)
                merged=guide.normalize_stages(payloads,plan,model,example['sentence'],coverage_complete=False,profile='positive_anchor')
                self.assertFalse(merged['coverage_validated'])
                self.assertNotEqual(merged['quantity']['kind'],'exact')
    def test_conditional_candidates_are_own_output_not_demo_or_gold(self):
        plan=guide.compile_guided('number of people');passage='Three sailors wave.'
        prior={'payload':'results = [Person("Three sailors")]', 'bound':{'a':1},'output_token_ids':[1,2]}
        bound=guide.bind_stage(plan,'knowcoder',passage,'quantity_bindings',codec('knowcoder').count_tokens,prior=prior)
        target=bound['prompt'].rsplit('\nInput:\n',1)[1]
        self.assertIn('"Person": ["Three sailors"]',target)
        self.assertIn('"Quantity": []',target)
        self.assertNotIn('Seven nurses',target)
        with self.assertRaises(ValueError):guide.validate_downstream('results=[HasQuantity(Entity("Three sailors"),Entity("Three"))]',plan,'knowcoder',passage,'quantity_bindings',prior)
    def test_keyword_order_does_not_change_semantic_roles(self):
        plan=guide.compile_guided('number of people');passage='Three sailors wave.'
        for model,raw,valid,invalid in (
          ('gollie','[Person(span="Three sailors"),Quantity(span="Three")]',
           '[HasQuantity(arg2="Three",arg1="Three sailors")]',
           '[HasQuantity(arg2="Three sailors",arg1="Three")]'),
          ('knowcoder','results=[Person("Three sailors"),Quantity("Three")]',
           'results=[HasQuantity(tail_entity=Entity("Three"),head_entity=Entity("Three sailors"))]',
           'results=[HasQuantity(tail_entity=Entity("Three sailors"),head_entity=Entity("Three"))]')):
            prior={'payload':raw,'bound':{},'output_token_ids':[]}
            guide.validate_downstream(valid,plan,model,passage,'quantity_bindings',prior)
            with self.assertRaises(ValueError):guide.validate_downstream(invalid,plan,model,passage,'quantity_bindings',prior)
    def test_prior_hash_drift_rejects_binding(self):
        plan=guide.compile_guided('number of people');e=guide.demonstration(plan)
        prior={'payload':guide.demo_payload(plan,'knowcoder','mentions'),'bound':{'a':1},'output_token_ids':[7]}
        bound=guide.bind_stage(plan,'knowcoder',e['sentence'],'identity',codec('knowcoder').count_tokens,prior=prior)
        changed=deepcopy(prior);changed['output_token_ids']=[8]
        with self.assertRaises(ValueError):guide.verify_binding(bound,plan,'knowcoder',e['sentence'],codec('knowcoder').count_tokens,prior=changed)
    def test_no_implicit_article_or_identifier_quantity_demonstrations(self):
        for condition in CONDITIONS.values():
            e=guide.demonstration(guide.compile_guided(condition))
            self.assertFalse(e['implicit_article_quantity_objects'])
            self.assertTrue(all(q in {'Seven','Eight','Six','Nine','One'} for q in e['quantity_mentions']))
    def test_full_source_spans_required(self):
        plan=guide.compile_guided('number of people')
        for raw in ('results=[Person("missing")]',"__import__('os').system('false')"):
            with self.assertRaises(ValueError):guide.candidate_state(raw,plan,'knowcoder','People wave.')
    def test_runtime_budget_never_truncates_input(self):
        plan=guide.compile_guided('number of people');e=guide.demonstration(plan)
        with self.assertRaises(ValueError):guide.bind_stage(plan,'knowcoder',e['sentence'],'mentions',lambda s:2000)
    def test_unknown_count_ontology_does_not_get_arbitrary_demo(self):
        with self.assertRaises(ValueError):guide.compile_guided('number of vehicles')


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.plan=guide.compile_guided('number of people');self.example=guide.demonstration(self.plan)
        self.source={'id':'synthetic-test-only','condition':'number of people','passage':self.example['sentence']}
        runtime._SESSIONS.clear();FakeBackend.instances=0;FakeBackend.fail_mentions=FakeBackend.truncate_mentions=False
        FakeBackend.payloads={s:guide.demo_payload(self.plan,'knowcoder',s) for s in guide.STAGES}
    def run_fake(self):
        with patch.object(capture,'sources',return_value=[self.source]),patch.object(runtime,'BACKEND_FACTORY',FakeBackend):
            p=protocol('knowcoder');return capture.capture_one(self.source,'knowcoder',p)
    def test_three_conditional_requests_without_invented_links(self):
        r=self.run_fake();self.assertEqual(r['runtime_status'],'ok',r['error'])
        self.assertEqual(r['model_calls'],3);self.assertTrue(r['bound_input_verified'])
        self.assertEqual(len(r['stage_outputs']),3)
        prior_raw=guide.digest(FakeBackend.payloads['mentions'].encode())
        self.assertEqual([b['prior_stage1']['stage1_payload_sha256'] for b in r['bound_inputs'][1:]],[prior_raw]*2)
        self.assertFalse(r['model_quality_passed']);self.assertFalse(r['coverage_complete'])
    def test_invalid_stage1_preserves_all_slots_and_makes_one_call(self):
        FakeBackend.fail_mentions=True;r=self.run_fake()
        self.assertEqual(r['model_calls'],1);self.assertFalse(r['parse_valid'])
        self.assertEqual([x['runtime_status'] for x in r['stage_outputs']],['error','not_run','not_run'])
        self.assertIn('__import__',r['raw_output'])
    def test_truncated_stage1_leaves_downstream_unrun(self):
        FakeBackend.truncate_mentions=True;r=self.run_fake()
        self.assertEqual(r['model_calls'],1);self.assertTrue(r['truncated'])
        self.assertEqual([x['runtime_status'] for x in r['stage_outputs']],['truncated','not_run','not_run'])
    def test_missing_candidate_edge_is_rejected_without_repair(self):
        FakeBackend.payloads['mentions']='results=[Person("Seven nurses")]'
        r=self.run_fake();self.assertEqual(r['model_calls'],3)
        self.assertFalse(r['parse_valid']);self.assertIsNone(r['normalized_evidence'])
        self.assertTrue(all(x['runtime_status']=='error' for x in r['stage_outputs'][1:]))
    def test_source_outside_exact_inventory_has_zero_calls(self):
        r=capture.capture_one(self.source,'knowcoder',protocol('knowcoder'))
        self.assertEqual(r['model_calls'],0);self.assertFalse(r['development_authorized'])

if __name__=='__main__':unittest.main()

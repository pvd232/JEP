"""One frozen conditional six-source/three-stage guided-count development capture; no retries."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028');ROOT=TASK/'guided-count-v1-execution'
ENV=TASK/'environments/knowcoder-author-py310'
PROTOCOL_SHA={'knowcoder':'bdb5391bbda32fd810c2e49787744cc0f56b318bba0c9496a64884b2b9aa7411','gollie':'91e83aee5bb50b11364029940b83021ffc38f52ea3aee77cf8ebb4352352fa4d'}
def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['knowcoder','gollie'],required=True);model=parser.parse_args().model
    output=TASK/('results/guided-count-v1-'+model);receipt=TASK/('results/guided-count-v1-'+model+'-worker.json');log=TASK/('logs/guided-count-v1-'+model+'.log');archive=TASK/('results/guided-count-v1-'+model+'-execution.tar.gz')
    if any(path.exists() for path in [output,receipt,log,archive]):raise ValueError('Finite count attempt exists; inspect, do not repeat')
    record={'status':'started','phase':'preflight','model':model,'started_at':time.time(),'authorized_sources':6,'planned_stage_slots':18,'output_token_cap':512,'automatic_retries':False,'general_counts_enabled':False,'fresh_or_locked_calls':False,'model_quality_passed':False,'conditional_recipe':True,'own_stage1_conditioning':True,'fixed_denominator':True}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    try:
        if model=='gollie':
            preceding=TASK/'results/guided-count-v1-knowcoder-worker.json'
            if (TASK/'guided-count-v1-knowcoder-dispatch.json').exists():
                record['phase']='waiting_for_count_know_exit';write(receipt,record);deadline=time.monotonic()+1500
                while not preceding.exists() or json.loads(preceding.read_text())['status'] not in ('complete','failed'):
                    if time.monotonic()>deadline:raise RuntimeError('Prior own count worker did not finish; no overlapping generation')
                    time.sleep(2)
        protocol=ROOT/'recipe/guided-count-candidate'/('protocol-'+model+'.json')
        if hashlib.sha256(protocol.read_bytes()).hexdigest()!=PROTOCOL_SHA[model]:raise ValueError('Reviewed finite protocol differs')
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')];required=int(total*0.6)+8*1024 if model=='knowcoder' else 45*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: actual free memory below reviewed budget')
        provider=ROOT/'provider/native-general-capture';finite=ROOT/'recipe/guided-count-candidate'
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONPATH=str(provider)+os.pathsep+str(finite),XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-finite-count'))
        if model=='gollie':
            driver_root=TASK/'environments/triton-driver-discovery-v2';driver_receipt=driver_root/'receipt.json';driver=json.loads(driver_receipt.read_text())
            if hashlib.sha256(driver_receipt.read_bytes()).hexdigest()!='4e67a2813087b42714d618ad55f733645489450096c7af3a58f16cdd544dbbd7':raise ValueError('Reviewed driver receipt differs')
            if driver['status']!='ready_cpu_discovery_verified' or hashlib.sha256((driver_root/'bin/ldconfig').read_bytes()).hexdigest()!=driver['wrapper_sha256']:raise ValueError('Driver wrapper differs')
            runtime['PATH']=str(driver_root/'bin')+os.pathsep+runtime.get('PATH','')
            audit=TASK/'results/gollie-pinned-artifact-audit-20261028.json'
            if hashlib.sha256(audit.read_bytes()).hexdigest()!='8caeb672bc09a34767369c27a10eb6127791062f037f53cd2827a9f1b6095418':raise ValueError('Verified Go primary byte audit differs')
            if json.loads(audit.read_text())['status']!='verified':raise ValueError('Go primary byte audit not ready')
            record.update(driver_receipt_sha256=hashlib.sha256(driver_receipt.read_bytes()).hexdigest(),primary_artifact_audit_sha256=hashlib.sha256(audit.read_bytes()).hexdigest())
        command=[str(ENV/'bin/python'),'-m','run_guided_count','--model',model,'--protocol',str(protocol),'--output',str(output)]
        record.update(phase='finite_capture',command=command,pythonpath=runtime['PYTHONPATH'],protocol_sha256=PROTOCOL_SHA[model]);write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        if (output/'summary.json').exists():record['summary']=json.loads((output/'summary.json').read_text())
        if result.returncode or 'summary' not in record:raise RuntimeError('Finite capture operational error; all raw failed/unrun slots retained where produced')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest() if log.exists() else None);write(receipt,record)
        index={str(path.relative_to(TASK)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(output.rglob('*')) if path.is_file()} if output.exists() else {}
        index_path=TASK/('results/guided-count-v1-'+model+'-execution-index.json');write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__)]:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():tf.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
        write(TASK/('results/guided-count-v1-'+model+'-execution-archive.json'),{'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

"""Mechanical cross-source error context regression; fake backend only."""
import unittest
from unittest.mock import patch
import native_capture as api
import build_protocol


class FakeBackend:
    def __init__(self,model,cfg):
        self.calls=0;self.last_raw=None;self.metadata={'fake_backend':True}
    def count_tokens(self,prompt):return 20
    def generate(self,bound):
        self.calls+=1;self.last_raw={'sentinel':'PRIOR_SOURCE_ONLY'}
        return {'payload':'results = []','truncated':False,'input_token_ids':[1],'output_token_ids':[2]}


class ErrorContextTests(unittest.TestCase):
    def test_zero_call_preparation_failure_cannot_inherit_previous_raw_context(self):
        api._SESSIONS.clear()
        cfg=build_protocol.runtime_config('knowcoder','/fake/checkpoint',api.ROOT/'runtime-manifest.json')
        protocol={'models':{'knowcoder':{'handler':{'sha256':api.support_identity()['handler_sha256']},'max_model_calls_per_source':1,'native_capture':cfg}}}
        source={'id':'public-first','condition':'type of food','passage':'A sandwich rests on a tray.'}
        with patch.object(api,'BACKEND_FACTORY',FakeBackend),patch.object(api,'_gate_passed',return_value=True):
            first=api.capture_one(source,'knowcoder',protocol)
            self.assertEqual(first['runtime_status'],'ok',first['error']);self.assertEqual(first['model_calls'],1)
            session=next(iter(api._SESSIONS.values()));self.assertEqual(session.last_raw,{'sentinel':'PRIOR_SOURCE_ONLY'})
            second=api.capture_one({**source,'id':'public-next','inference_requests':[{'prompt':'deliberately mismatched public fixture'}]},'knowcoder',protocol)
        self.assertEqual(second['runtime_status'],'error');self.assertEqual(second['model_calls'],0)
        self.assertEqual(second['stage_outputs'],[]);self.assertIsNone(second['raw_output'])
        self.assertNotIn('raw_backend_error_response',second);self.assertIsNone(session.last_raw)


if __name__=='__main__':unittest.main()

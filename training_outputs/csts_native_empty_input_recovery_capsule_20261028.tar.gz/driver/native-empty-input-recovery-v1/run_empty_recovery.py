"""Exactly seven first neural generations/model after mechanical empty-input repair.

This thin finite driver reuses the approved capture callback/backends. It never
opens the original48 source packet, ratings, paired passages or generated31
records. Audited selection receipts prove every selected original made0 calls.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import uuid
import native_capture as capture

ROOT=Path(__file__).resolve().parent
SOURCES_SHA='bf956fe5c07c9f55088487ca40521d6f288e5651d77dbf44572356c1987e2a3a'
SELECTION_SHA='826f5c7f58f700dd75a34bca8b56add4e0e7d1ea16552b1a481d2fa93326ff7d'
ORIGIN='mechanical_empty_input_first_neural_generation_recovery_v1'


def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()


def selected_sources():
    source_bytes=(ROOT/'sources.json').read_bytes();proof_bytes=(ROOT/'selection-receipt.json').read_bytes()
    if sha(source_bytes)!=SOURCES_SHA or sha(proof_bytes)!=SELECTION_SHA:
        raise ValueError('Reviewed first-generation source selection/proof changed')
    sources=json.loads(source_bytes);proof=json.loads(proof_bytes)
    if not isinstance(sources,list) or len(sources)!=7 or len({s['id'] for s in sources})!=7:
        raise ValueError('Recovery requires exactly seven unique sources')
    if proof['maximum_new_model_calls']!=14 or proof['source_projection_sha256']!=SOURCES_SHA or proof['original_artifacts_mutated'] is not False or proof['literal_gold_or_ratings_copied'] is not False:
        raise ValueError('Reviewed selection scope/provenance changed')
    proofs={p['source_id']:p for p in proof['proofs']}
    if set(proofs)!={s['id'] for s in sources}:raise ValueError('Selection proof ID inventory differs')
    for source in sources:
        if set(source)!={'id','passage','condition'} or source['passage']!='' or not isinstance(source['condition'],str) or not source['condition'].strip():
            raise ValueError('Only unchanged empty-string inference triples are authorized')
        record=proofs[source['id']]
        if record['primary_model_calls']!={'gollie':0,'knowcoder':0} or record['raw_or_scored_content_retained'] is not False or record['primary_error']!='ValueError: A nonempty passage is required':
            raise ValueError('Selected source previously generated or has a different failure')
        hashes=record['primary_capture_sha256']
        if set(hashes)!={'gollie','knowcoder'} or any(not isinstance(h,str) or len(h)!=64 for h in hashes.values()):
            raise ValueError('Missing original capture hash proof')
    return sources,proof


def preflight(model,protocol):
    if model not in {'knowcoder','gollie'}:raise ValueError('Unknown frozen native model')
    sources,proof=selected_sources();descriptor=protocol['models'][model];cfg=descriptor['native_capture']
    if descriptor['max_model_calls_per_source']!=1 or type(descriptor['max_model_calls_per_source']) is not int:
        raise ValueError('Recovery protocol must cap exactly one first generation/source')
    if descriptor['handler']['module']!='native_capture' or descriptor['handler']['callable']!='capture_one' or descriptor['handler']['sha256']!=sha(Path(capture.__file__).read_bytes()):
        raise ValueError('Reviewed existing callback identity changed')
    capture._verify_support(cfg)
    for source in sources:
        plan=capture._compile(source['condition'],cfg)
        specs,error=capture._stage_specs(plan,cfg)
        if not plan['supported'] or error or not isinstance(specs,list) or len(specs)!=1:
            raise ValueError('Selected recovery source does not have exactly one unchanged supported stage')
        if not capture._gate_passed(descriptor,source,plan,model,specs[0]):
            raise ValueError('Separate exact-seven recovery authorization failed')
    return sources,proof


def write_once(path,value):
    raw=encoded(value);temporary=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as out:out.write(raw);out.flush();os.fsync(out.fileno())
        os.link(temporary,path)
    finally:
        if temporary.exists():temporary.unlink()


def run(model,protocol,output):
    sources,proof=preflight(model,protocol)
    output=Path(output);output.mkdir(exist_ok=False)
    origin={'origin':ORIGIN,'model':model,'authorized_sources':7,'maximum_model_calls':7,
        'source_projection_sha256':SOURCES_SHA,'selection_receipt_sha256':SELECTION_SHA,
        'primary_protocol_sha256':proof['primary_protocol_sha256'],
        'primary_job_seal_sha256':proof['primary_job_seal_sha256'],
        'original48_artifacts_unchanged':True,'generated31_repeated':False,
        'first_neural_call_for_each_source':True,'semantic_tuning':False,
        'new_schema_or_demonstration':False,'count_or_quote_fallback':False}
    write_once(output/'origin.json',origin);write_once(output/'protocol.json',protocol)
    results=[];total_calls=0
    for index,source in enumerate(sources):
        folder=output/('%02d-'%index+source['id']);folder.mkdir()
        write_once(folder/'request.json',{'source':source,'model':model,'origin':ORIGIN,
            'protocol_sha256':sha(encoded(protocol)),'selection_receipt_sha256':SELECTION_SHA,
            'primary_capture_sha256':next(p for p in proof['proofs'] if p['source_id']==source['id'])['primary_capture_sha256'][model],
            'atomic_source_claim':True,'single_first_generation_attempt':True})
        returned=capture.capture_one(source,model,protocol)
        # Preserve the callback result before checking operational or replay flags.
        write_once(folder/'handler-return.json',returned)
        calls=returned.get('model_calls')
        if type(calls) is not int or calls not in (0,1):raise ValueError('Callback exceeded the exact one-call source cap')
        total_calls+=calls
        if total_calls>7:raise ValueError('Recovery exceeded seven model requests')
        if returned.get('id')!=source['id'] or returned.get('model')!=model:raise ValueError('Callback returned another source/model')
        # Existing owner verifier remains inert; raw hallucinations or [] are not
        # repaired, and source-grounding failures stay failures.
        try:
            replay=capture.verify_normalize_record(source,model,protocol,returned)
            replay_record={'status':'verified','normalized_evidence':replay}
        except Exception as error:
            replay_record={'status':'replay_error','error':type(error).__name__+': '+str(error)}
        write_once(folder/'replay.json',replay_record)
        write_once(folder/'capture.json',returned)
        results.append((returned,replay_record))
    summary={'origin':ORIGIN,'model':model,'sources':7,'planned_sources':7,
        'model_calls':total_calls,'maximum_model_calls':7,
        'operationally_ok':sum(r['runtime_status']=='ok' and r['parse_valid'] for r,_ in results),
        'unsupported':sum(r['runtime_status']=='unsupported' for r,_ in results),
        'errors_or_unrun':sum(r['runtime_status'] not in {'ok','unsupported'} for r,_ in results),
        'replay_verified':sum(v['status']=='verified' for _,v in results),
        'original48_artifacts_unchanged':True,'generated31_repeated':False,
        'first_generation_recovery_not_semantic_retry':True,'fresh_or_count_or_quote_calls':False,
        'quality_qualification_claimed':False}
    write_once(output/'summary.json',summary)
    return summary


def main():
    seal=json.loads((ROOT/'seal.json').read_bytes())
    for name,expected in seal['files'].items():
        artifact=(ROOT/name).resolve()
        if not artifact.is_relative_to(ROOT) or sha(artifact.read_bytes())!=expected:
            raise ValueError('Frozen finite recovery driver artifact changed: '+name)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=('knowcoder','gollie'),required=True)
    parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();print(json.dumps(run(args.model,json.loads(args.protocol.read_bytes()),args.output),sort_keys=True))

if __name__=='__main__':main()

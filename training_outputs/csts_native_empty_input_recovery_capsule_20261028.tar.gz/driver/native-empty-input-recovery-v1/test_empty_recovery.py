"""CPU-only finite first-generation recovery tests; no models loaded."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
import run_empty_recovery as driver
import native_capture as capture
import native_capture_backends as backend

PROTOCOL=Path('/tmp/jep-native-empty-first-generation-protocol-v2-20261028/protocol.json')


class FakeEmptyBackend:
    instances=0
    invent=False
    def __init__(self,model,cfg):
        type(self).instances+=1;self.calls=0;self.model=model
        self.codec,_=capture._cpu_codec(model,cfg);self.metadata={'synthetic_cpu_backend':True};self.last_raw=None
    def count_tokens(self,text):return self.codec.count_tokens(text)
    def generate(self,bound):
        self.calls+=1
        payload=('results=[Vehicle("invented")]' if self.model=='knowcoder' else '[Vehicle(span="invented")]') if self.invent else ('results=[]' if self.model=='knowcoder' else '[]')
        inputs=self.codec.encode(bound['prompt']);outputs=self.codec.encode(payload)[1:]+[2]
        raw=self.codec.decode(outputs,skip_special_tokens=True)
        return {'payload':raw,'api_text':raw,'input_token_ids':inputs,'output_token_ids':outputs,
            'input_tokens':len(inputs),'output_tokens':len(outputs),'truncated':False,
            'raw_decoded_generation':raw,'raw_decode_with_special_tokens':self.codec.decode(outputs),
            'author_projection':backend.know_support.author_projection(self.codec,inputs,outputs),
            'stop_reason':'stop' if self.model=='knowcoder' else 'eos',
            'generation_options':({'n':1,'best_of':1,'temperature':0.0,'stop':'"""','max_tokens':512} if self.model=='knowcoder' else
             {'method':'manual_greedy_cache','max_new_tokens':512,'do_sample':False,'num_beams':1})}


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        capture._SESSIONS.clear();FakeEmptyBackend.instances=0;FakeEmptyBackend.invent=False
        self.protocol=json.loads(PROTOCOL.read_bytes())
    def test_selection_is_exact_seven_empty_zero_call_records_both_models(self):
        sources,proof=driver.selected_sources()
        self.assertEqual(len(sources),7);self.assertTrue(all(s['passage']=='' for s in sources))
        self.assertEqual(proof['maximum_new_model_calls'],14)
        for item in proof['proofs']:self.assertEqual(item['primary_model_calls'],{'gollie':0,'knowcoder':0})
    def test_all_fourteen_static_source_routes_are_single_stage_and_authorized(self):
        for model in ('knowcoder','gollie'):
            sources,_=driver.preflight(model,self.protocol)
            self.assertEqual(len(sources),7)
    def test_successful_empty_outputs_replay_with_real_tokenizer_and_no_companions(self):
        for model in ('knowcoder','gollie'):
            capture._SESSIONS.clear();FakeEmptyBackend.instances=0
            with tempfile.TemporaryDirectory() as directory,patch.object(capture,'BACKEND_FACTORY',FakeEmptyBackend),patch.object(capture,'_verify_record_backend_metadata'):
                output=Path(directory)/'new';summary=driver.run(model,self.protocol,output)
                self.assertEqual(summary['model_calls'],7);self.assertEqual(summary['operationally_ok'],7)
                self.assertEqual(summary['replay_verified'],7);self.assertEqual(FakeEmptyBackend.instances,1)
                self.assertFalse(summary['generated31_repeated'])
                self.assertEqual(len([p for p in output.iterdir() if p.is_dir()]),7)
                with self.assertRaises(FileExistsError):driver.run(model,self.protocol,output)
    def test_hallucinated_annotation_against_empty_source_fails_grounding_without_fallback(self):
        source=driver.selected_sources()[0][0];FakeEmptyBackend.invent=True
        for model in ('knowcoder','gollie'):
            capture._SESSIONS.clear()
            with patch.object(capture,'BACKEND_FACTORY',FakeEmptyBackend),patch.object(capture,'_verify_record_backend_metadata'):
                record=capture.capture_one(source,model,self.protocol)
                self.assertEqual(record['model_calls'],1)
                self.assertEqual(record['runtime_status'],'error');self.assertFalse(record['parse_valid'])
                self.assertIn('invented',record['raw_output']);self.assertIsNone(record['normalized_evidence'])
                self.assertIsNone(capture.verify_normalize_record(source,model,self.protocol,record))
    def test_nonempty_or_outside_source_cannot_be_admitted(self):
        sources,_=driver.selected_sources();source=dict(sources[0],passage='changed')
        for model in ('knowcoder','gollie'):
            cfg=self.protocol['models'][model]['native_capture'];plan=capture._compile(source['condition'],cfg)
            specs,_=capture._stage_specs(plan,cfg)
            self.assertFalse(capture._gate_passed(self.protocol['models'][model],source,plan,model,specs[0]))
            outside=dict(sources[0],id='not-selected')
            self.assertFalse(capture._gate_passed(self.protocol['models'][model],outside,plan,model,specs[0]))

if __name__=='__main__':unittest.main()

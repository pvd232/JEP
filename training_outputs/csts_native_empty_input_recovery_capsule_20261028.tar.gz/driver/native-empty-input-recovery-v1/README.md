# Mechanical empty-input first-generation recovery

This finite capsule permits at most one neural request for each of seven exact
empty-string sources, once per model: fourteen first generations in total. The
31 already-generated sources/model are inaccessible to this driver. Original48
captures, attempts, protocols, primary reviews and denominators remain immutable.
This is a separately labeled additive recovery origin, not semantic retry,
exposed tuning, fresh evaluation or a count/quote fallback.

The source-only projection and independently audited selection receipt are bound
by exact hashes. Each selected source has passage=='' and its unchanged ID and
condition. Both original model records made zero calls and contain no current
request bindings, stage outputs or delivered raw/normalized prediction. Some
original Know error capsules retained stale cached debug context from a previous
source; those are not seven model responses. No such debug/raw/scored content is
copied into the recovery inputs.

The approved core change is exactly two type-only guards: schema._target_prompt
and normalize_native now permit empty/whitespace strings while rejecting
nonstrings. No instruction, example, schema, checkpoint, decoding, token budget,
nonempty prompt or semantic normalizer behavior changes. Literal[] can be
normalized against empty text; any nonempty invented mention still fails source
grounding. A separate administrative provider authorization admits only the exact
seven triples and their audited zero-call provenance. Cached last_raw is cleared
before preparing each source and is retained only for a current attempted call.

The driver reuses capture_one, its exact canonical backends and inert raw-token
verifier. It preflights all seven as single-stage/cap1 before loading a model.
Each new source folder is claimed exclusively before its first attempt, and its
raw handler return is saved before validation/replay. Errors, empty outputs,
hallucinations and truncations are retained; none selects a replacement or retry.
A preexisting output directory is refused. The outer operator additionally owns
exclusive model-launch receipts, Know→Go serialization, resource guards and
self-archiving; original48 launch/source claims are never reused.

Run one model/process with provider first and this driver second in PYTHONPATH:

```
HISTORICAL_PYTHON -m run_empty_recovery --model knowcoder --protocol RECOVERY_PROTOCOL/protocol.json --output NEW_OUTPUT
HISTORICAL_PYTHON -m run_empty_recovery --model gollie --protocol RECOVERY_PROTOCOL/protocol.json --output ANOTHER_NEW_OUTPUT
```

Outputs are origin.json, the exact canonical protocol.json, seven new folders
(request.json,handler-return.json,capture.json,replay.json) and summary.json. The
summary reports actual requests, operational failures and inert replay status;
it does not promote source support, counting ability or model quality. Existing
primary96 measurements are not rewritten by this capsule.

"""Freeze small, post-screen target-compatible native diagnostics without GPU calls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
import textwrap

CODE = Path("/tmp/jep-extraction-knowcoder-author-v4-code-20261028")
SOURCE = Path("/tmp/jep-extraction-knowcoder-author-v4-20261028/sources.json")
ROOT = Path("/tmp/jep-native-target-diagnostic-20261028")
ROOT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location("frozen_native", CODE / "csts_pilot/extraction_native.py")
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
sources_bytes = SOURCE.read_bytes()
sources = json.loads(sources_bytes)
# Fixed source-only selections before any diagnostic outputs; never consult labels/captures.
choices = [
    (1, "soccer_sport", True, "PlaysSport", "Participant", "Sport", "participant", "sport",
     [["team", "soccer"]]),
    (2, "tennis_sport", True, "PlaysSport", "Participant", "Sport", "participant", "sport",
     [["girl", "tennis"]]),
    (3, "plate_food", True, "ContainsFood", "Container", "Food", "container", "food",
     [["plate", "sandwich"], ["plate", "pickle"]]),
    (5, "surfboard_color", True, "HasColor", "Object", "Color", "object", "color",
     [["surfboard", "white"]]),
    (29, "surfer_clothing", True, "WearsClothing", "Person", "Clothing", "person", "clothing",
     [["man", "wetsuit"]]),
    (60, "pizza_location", True, "LocatedIn", "Food", "Place", "food", "location",
     [["pizza", "table"]]),
    (76, "snow_color_absent", False, "HasColor", "Object", "Color", "object", "color", []),
    (138, "batter_location_absent", False, "LocatedIn", "Person", "Place", "person", "location", []),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

def doc(text, indent="    "):
    # Real multiline Python docstrings; same generic guideline text as arm A.
    return indent + '\"\"\"' + "\n" + textwrap.indent(textwrap.fill(text, width=88), indent) + "\n" + indent + '\"\"\"'

def guideline(item):
    return (
        "Condition: " + item["condition"] + ". "
        "Extract all subject/value pairs answering this condition. "
        "The first argument identifies the subject including stated quantities; "
        "the second gives its requested value including all qualifications. "
        "Keep separately mentioned subjects separate, including repeated values. "
        "Return an empty list when the requested information is unavailable. "
        + native.NATIVE_POLICY
    )

def prompt(item, arm, variant, rel, ht, tt, hf, tf):
    if variant == "A":
        return native.build_native_prompt(item, arm)
    concrete = variant == "C"
    name = rel if concrete else "ConditionRelation"
    desc = doc(guideline(item))
    sentence = json.dumps(item["passage"], ensure_ascii=False)
    if arm == "knowcoder":
        definition = (
            'class Entity:\n    """The base class for all entities."""\n'
            '    def __init__(self, name: str):\n        self.name = name\n\n'
            'class Relation:\n    """The base class for all relations."""\n'
            '    def __init__(self, head_entity: Entity, tail_entity: Entity):\n'
            '        self.head_entity = head_entity\n        self.tail_entity = tail_entity\n\n'
        )
        if concrete:
            for et in dict.fromkeys([ht, tt]):
                definition += (
                    "class " + et + "(Entity):\n"
                    + doc("A textually mentioned " + et.lower() + "; preserve its name or description.") + "\n"
                    '    def __init__(self, name: str):\n        super().__init__(name=name)\n\n'
                )
        htype, ttype = (ht, tt) if concrete else ("Entity", "Entity")
        definition += (
            "class " + name + "(Relation):\n" + desc + "\n"
            "    def __init__(self, head_entity: " + htype + ", tail_entity: " + ttype + "):\n"
            "        super().__init__(head_entity=head_entity, tail_entity=tail_entity)\n\n"
            '\"\"\"\nThis is an object-oriented programming task: instantiate all corresponding '
            'Relation Objects in the following sentence.\n\"\"\"\n'
            "sentence = " + sentence
        )
        return native.KNOWCODER_SYSTEM + "\nInput:\n" + definition + "\nOutput:\n"
    fields = (
        "    " + hf + ": str  # " + ht + " subject explicitly mentioned in the text.\n"
        "    " + tf + ": str  # " + tt + " value supported by the text.\n"
    ) if concrete else (
        "    arg1: str  # Subject, preserving quantities and qualifications.\n"
        "    arg2: str  # Condition-specific value supported by the text.\n"
    )
    return (
        "# The following lines describe the task definition\n"
        "@dataclass\nclass " + name + "(Relation):\n" + desc + "\n\n"
        + fields + "\n\n# This is the text to analyze\ntext = " + sentence
        + "\n\n# The annotation instances that take place in the text above are listed here\nresult ="
    )

fixtures = []
for index, fid, positive, rel, ht, tt, hf, tf, gold in choices:
    item = sources[index]
    variants = {}
    for arm in ("knowcoder", "gollie"):
        variants[arm] = {}
        for variant in ("A", "B", "C"):
            concrete = variant == "C"
            variants[arm][variant] = {
                "prompt": prompt(item, arm, variant, rel, ht, tt, hf, tf),
                "relation_class": rel if concrete else "ConditionRelation",
                "relation_fields": ["head_entity", "tail_entity"] if arm == "knowcoder"
                    else ([hf, tf] if concrete else ["arg1", "arg2"]),
                "entity_classes": [ht, tt] if concrete else ["Entity", "Entity"],
                "expected_relations": [
                    [rel if concrete else "ConditionRelation", head, tail] for head, tail in gold
                ],
            }
    fixtures.append({
        "fixture_id": fid, "source_index": index, "source": item,
        "expected_nonempty": positive,
        "gold_note": "Minimal supported subject/value anchors, not exhaustive surface-form gold. "
            "Exact string matches are descriptive only; inspect raw outputs for semantic binding and omissions.",
        "variants": variants,
    })
dump(ROOT / "fixtures.json", fixtures)
shutil.copyfile(SOURCE, ROOT / "sources.json")
shutil.copyfile(Path(__file__), ROOT / "prepare_diagnostic.py")
shutil.copytree(CODE, ROOT / "code", ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
dump(ROOT / "design.json", {
    "purpose": "Post-screen pipeline and target-mapping diagnostic; never a representative quality score.",
    "selection_timing": "Selected after main-screen abstentions and before all target-diagnostic outputs.",
    "primary_screen_unchanged": True,
    "fixtures": "Six literal positive and two truly absent conditions from the frozen 239 actual sources; "
        "source-only selection, no references or similarity labels consulted.",
    "variants": {
        "A": "Exact frozen v4 generic ConditionRelation prompt.",
        "B": "Same ConditionRelation, entity/field types, guideline semantics and native decoding; "
            "author-style headers, multiline docstrings and base-class descriptions only.",
        "C": "B formatting plus descriptive relation and typed entity names (KnowCoder) "
            "or descriptive relation and field names (GoLLIE). A changed task mapping, not a proven bug fix.",
    },
    "controls": {
        "weights": native.NATIVE_MODELS, "decoding": {"do_sample": False, "num_beams": 1, "max_new_tokens": 1024},
        "order": "knowcoder then gollie; source fixture order; A,B,C within each source",
        "attempts_per_cell": 1, "expected_answers_in_model_inputs": False,
        "no_demonstrations": True, "no_source_truncation": True,
        "adaptation_after_observing_target_diagnostic_outputs": False,
    },
    "interpretation": "B>A suggests serialization sensitivity, C>B suggests schema/task mapping sensitivity. "
        "Single small selected diagnostics cannot establish model-family quality or identify a unique cause. "
        "No variant chosen for a main rerun after these outputs.",
    "sources": [
        "https://github.com/ICT-GoKnow/KnowCoder/blob/b7859789fc7641e03916074088859aa592332ad3/Cases.md",
        "https://github.com/ICT-GoKnow/KnowCoder/blob/b7859789fc7641e03916074088859aa592332ad3/eval/src/inference.py",
        "https://github.com/hitz-zentroa/GoLLIE/blob/164c611743fdc1befe71bbdf03e08c5eb4e35957/notebooks/Relation%20Extraction.ipynb",
        "https://github.com/hitz-zentroa/GoLLIE/blob/164c611743fdc1befe71bbdf03e08c5eb4e35957/templates/prompt.txt",
    ],
    "proven_vs_hypothesized": {
        "proven": "Authors' native RE examples use descriptive relation names. KnowCoder author RE itself "
            "uses generic Entity, so typed subclasses are not mandatory. GoLLIE author RE uses str arg1/arg2.",
        "hypothesis": "Anonymous question-answer relation and long escaped single-line policy may cause "
            "schema abstention; type-of-food/sport maps attribute or unary typing into binary RE.",
    },
})
print(ROOT)
print("fixtures", len(fixtures), "cells", len(fixtures)*6)

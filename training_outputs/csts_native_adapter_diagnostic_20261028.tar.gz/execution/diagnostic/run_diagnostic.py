"""Run sealed A/B/C native prompt diagnostics; never execute generated code."""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


def bind(node, names):
    if len(node.args) > len(names):
        raise ValueError("Too many arguments")
    values = dict(zip(names, node.args))
    for kw in node.keywords:
        if kw.arg not in names or kw.arg in values:
            raise ValueError("Unknown or duplicate argument")
        values[kw.arg] = kw.value
    if set(values) != set(names):
        raise ValueError("Missing constructor argument")
    return [values[name] for name in names]


def string(node):
    if not isinstance(node, ast.Constant) or not isinstance(node.value, str) or not node.value.strip():
        raise ValueError("Expected nonempty literal string")
    return node.value


def parse(payload, cell, arm):
    if not isinstance(payload, str) or not payload.strip() or len(payload) > 100000:
        raise ValueError("Empty or oversized result")
    body = ast.parse(payload.strip(), mode="exec").body
    if len(body) != 1:
        raise ValueError("Expected one result expression")
    statement = body[0]
    if isinstance(statement, ast.Expr):
        value = statement.value
    elif isinstance(statement, ast.Assign):
        if len(statement.targets) != 1 or not isinstance(statement.targets[0], ast.Name) or statement.targets[0].id not in {"result", "results"}:
            raise ValueError("Unexpected assignment")
        value = statement.value
    else:
        raise ValueError("Unexpected statement")
    if not isinstance(value, ast.List) or len(value.elts) > 256:
        raise ValueError("Expected bounded list")
    rows = []
    for node in value.elts:
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or node.func.id != cell["relation_class"]:
            raise ValueError("Unexpected relation constructor")
        args = bind(node, cell["relation_fields"])
        if arm == "knowcoder":
            values = []
            for arg, cls in zip(args, cell["entity_classes"]):
                if not isinstance(arg, ast.Call) or not isinstance(arg.func, ast.Name) or arg.func.id != cls:
                    raise ValueError("Unexpected typed entity constructor")
                values.append(string(bind(arg, ["name"])[0]))
        else:
            values = list(map(string, args))
        rows.append([node.func.id, *values])
    return rows


def list_empty(payload):
    """Identify an actually empty emitted list separately from schema validation."""
    try:
        body = ast.parse(payload.strip(), mode="exec").body
        if len(body) != 1:
            return None
        node = body[0]
        if isinstance(node, ast.Expr):
            value = node.value
        elif isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {"result", "results"}:
            value = node.value
        else:
            return None
        return len(value.elts) == 0 if isinstance(value, ast.List) else None
    except (SyntaxError, RecursionError, ValueError):
        return None


def generate(generator, prompt):
    from csts_pilot.extraction_native import check_token_budget, native_payload
    batch = generator.tokenizer(prompt, add_special_tokens=True, return_tensors="pt")
    eos = generator.tokenizer.eos_token_id
    eos_removed = False
    if generator.arm == "gollie" and batch["input_ids"][0, -1].item() == eos:
        batch = {key: value[:, :-1] for key, value in batch.items()}
        eos_removed = True
    input_ids = batch["input_ids"][0].tolist()
    check_token_budget(len(input_ids), 1024, generator.descriptor["context_limit"])
    batch = {key: value.to(generator.model.device) for key, value in batch.items()}
    options = {}
    if generator.stopping_criteria is not None:
        options["stopping_criteria"] = generator.stopping_criteria
    started = time.monotonic()
    with generator.torch.inference_mode():
        output = generator.model.generate(
            **batch, max_new_tokens=1024, min_new_tokens=0, do_sample=False,
            num_beams=1, num_return_sequences=1, pad_token_id=eos, **options,
        )
    suffix = output[0, len(input_ids):]
    output_ids = suffix.tolist()
    raw = generator.tokenizer.decode(suffix, skip_special_tokens=True)
    payload, stop = native_payload(raw, generator.arm)
    finished = bool(output_ids and output_ids[-1] == eos)
    return {
        "prompt": prompt, "input_token_ids": input_ids, "output_token_ids": output_ids,
        "raw_decoded_generation": raw, "payload": payload,
        "input_tokens": len(input_ids), "output_tokens": len(output_ids),
        "context_limit": generator.descriptor["context_limit"],
        "gollie_final_eos_removed": eos_removed,
        "stop_reason": "eos" if finished else stop,
        "truncated": len(output_ids) >= 1024 and not finished and stop != "author_stop_string",
        "elapsed_generation_seconds": time.monotonic() - started,
        "environment": dict(generator.environment),
        "decoding": {"do_sample": False, "num_beams": 1, "max_new_tokens": 1024, "min_new_tokens": 0},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    seal = json.loads((root / "seal.json").read_text())
    # Verify every implementation/input file before importing model dependencies.
    for name, expected in seal["files"].items():
        if sha((root / name).read_bytes()) != expected:
            raise ValueError("Sealed diagnostic file changed: " + name)
    fixtures = json.loads((root / "fixtures.json").read_text())
    sources = json.loads((root / "sources.json").read_text())
    if [x["fixture_id"] for x in fixtures] != seal["fixture_order"]:
        raise ValueError("Fixed fixture order changed")
    for fixture in fixtures:
        if sources[fixture["source_index"]] != fixture["source"]:
            raise ValueError("Fixture no longer matches original source")
    sys.path.insert(0, str(root / "code"))
    from csts_pilot.extraction_native import NativeGenerator, NATIVE_MODELS
    if NATIVE_MODELS != seal["checkpoints"]:
        raise ValueError("Frozen checkpoints changed")
    args.output.mkdir(parents=True, exist_ok=False)
    write(args.output / "start.json", {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "purpose": seal["purpose"], "seal_sha256": sha((root / "seal.json").read_bytes()),
        "expected_annotations_in_model_inputs": False, "primary_screen_unchanged": True,
        "cell_order": seal["cell_order"], "attempts_per_cell": 1,
    })
    completed = failed = 0
    for arm in ("knowcoder", "gollie"):
        generator = None
        try:
            generator = NativeGenerator(arm, device="cuda", max_new_tokens=1024)
        except Exception as error:
            write(args.output / (arm + "-load-error.json"), {
                "arm": arm, "error": str(error), "traceback": traceback.format_exc(),
            })
            failed += 24
            continue
        for fixture in fixtures:
            for variant in ("A", "B", "C"):
                cell = fixture["variants"][arm][variant]
                stem = arm + "-" + fixture["fixture_id"] + "-" + variant
                result = {
                    "arm": arm, "fixture_id": fixture["fixture_id"], "variant": variant,
                    "source": fixture["source"], "status": "failed",
                    "expected_nonempty": fixture["expected_nonempty"],
                    "expected_anchor_relations": cell["expected_relations"],
                    "interpretation": fixture["gold_note"],
                    "semantic_review_required": True, "semantic_status": "unreviewed", "parse_status": "not_attempted",
                    "empty_list_emitted": None,
                }
                try:
                    generated = generate(generator, cell["prompt"])
                    write(args.output / (stem + "-generation.json"), generated)
                    if generated["truncated"]:
                        raise ValueError("Output budget exhausted")
                    result["empty_list_emitted"] = list_empty(generated["payload"])
                    result["parse_status"] = "schema_or_literal_validation_failed"
                    rows = parse(generated["payload"], cell, arm)
                    result.update(status="completed", parse_status="valid", parsed_relations=rows, nonempty=bool(rows),
                                  exact_anchor_match=sorted(rows) == sorted(cell["expected_relations"]))
                    completed += 1
                except Exception as error:
                    failed += 1
                    result.update(error=str(error), traceback=traceback.format_exc())
                write(args.output / (stem + "-result.json"), result)
                print(json.dumps({key: result[key] for key in ("arm", "fixture_id", "variant", "status", "nonempty") if key in result}), flush=True)
        del generator
        import gc
        import torch
        gc.collect()
        torch.cuda.empty_cache()
    write(args.output / "complete.json", {"completed": completed, "failed": failed,
                                         "representative_quality_score": False})
    raise SystemExit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()

"""CPU-only SAME9 binding builder; no model runtime or held-out sources."""
import argparse,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from native_adapter.schema import bounded_input,implementation_identity
from native_adapter.know_refinement import KNOW_REFINEMENT


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--tokenizer-json',type=Path,required=True);args=parser.parse_args()
    from tokenizers import Tokenizer
    tokenizer=Tokenizer.from_file(str(args.tokenizer_json));count=lambda text:len(tokenizer.encode(text,add_special_tokens=True).ids)
    original=json.loads((ROOT/'tests/fixtures/base_task_contract_requests.json').read_text())['items']
    items=[];proof=[]
    for row in original:
        requests={}
        for model in ('knowcoder','gollie'):
            bound=bounded_input(row['plan'],model,row['passage'],count if model=='knowcoder' else lambda _:1,profile='positive_anchor',prompt_profile=KNOW_REFINEMENT if model=='knowcoder' else row['prompt_profile'])
            assert bound['target_prompt_sha256']==row['requests'][model]['target_prompt_sha256']
            unchanged=model=='gollie' or bound['prompt_profile_identity']['active_refinement'] is None
            if unchanged:assert bound['prompt']==row['requests'][model]['prompt']
            if model=='gollie':del bound['input_tokens']
            requests[model]=bound;proof.append({'case_id':row['case_id'],'model':model,'prompt_unchanged':unchanged,'input_tokens':bound.get('input_tokens'),'context_limit':bound['context_limit'],'prompt_sha256':bound['prompt_sha256'],'target_prompt_unchanged':True})
        items.append({key:row[key] for key in ('case_id','source_id','passage','condition','plan','plan_sha256','profile','contract_recipe')}|{'prompt_profile':KNOW_REFINEMENT,'requests':requests})
    packet={'status':'PREPARED_NOT_EXECUTED','dispatch_models':['knowcoder_ie'],'go_dispatch_authorized':False,'same_nine_sources':True,'prompt_profile':KNOW_REFINEMENT,'items':items,'model_calls':0}
    receipt={'model_calls':0,'go_all9_generation_prompts_byte_identical':True,'know_ner4_color2_prompts_byte_identical':True,'all18_target_queries_unchanged':True,'tokenizer_json_sha256':hashlib.sha256(args.tokenizer_json.read_bytes()).hexdigest(),'actual_tokenizer_special_tokens':True,'output_reserve':512,'max_know_input_tokens':max(r['input_tokens'] for r in proof if r['model']=='knowcoder'),'compiler_implementation_files':implementation_identity(),'proof':proof}
    (ROOT/'know-refinement-requests.json').write_text(json.dumps(packet,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    (ROOT/'evidence/know-refinement-binding-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'max_know_input_tokens':receipt['max_know_input_tokens'],'go_prompts_unchanged':9,'know_prompts_unchanged':6,'model_calls':0}))


if __name__=='__main__':main()

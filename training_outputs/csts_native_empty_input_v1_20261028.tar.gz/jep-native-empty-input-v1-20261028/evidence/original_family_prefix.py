"""Prepared one-shot prefix; not a frozen inference profile or model launch."""
from pathlib import Path
import json
SYSTEM='You are a highly skilled assistant at digesting and extracting information from textual content. Below is an input containing standard type definitions and textual content. Please complete it with the extracted information in the form of structured code.'
CONDITION='native_fixed_family_one_shot_v1'

def render(target_prompt,model,native_task):
    """Add exactly one completed independent example for the declared native family."""
    examples=json.loads((Path(__file__).parent/'demonstrations.json').read_text())
    if native_task not in examples:
        raise ValueError('Only the separately declared ordinary NER/RE/EE candidate is prepared')
    example=examples[native_task]
    if model=='knowcoder':
        prefix=SYSTEM+'\nInput:\n'
        if not target_prompt.startswith(prefix) or not target_prompt.endswith('\nOutput:\n'):
            raise ValueError('Target must retain the canonical KnowCoder wrapper')
        query=target_prompt[len(prefix):]
        return prefix+example['know_query']+'\nOutput:\n'+example['know_output']+'\nInput:\n'+query
    if model=='gollie':
        if not target_prompt.endswith('result ='):
            raise ValueError('Target must retain the canonical GoLLIE completion marker')
        return example['go_query']+' '+example['go_output']+'\n\n'+target_prompt
    raise ValueError('Unknown native model')

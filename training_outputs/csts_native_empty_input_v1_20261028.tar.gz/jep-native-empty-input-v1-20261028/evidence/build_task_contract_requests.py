"""Build the same nine exposed inputs under one new condition-only recipe."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from native_adapter.schema import compile_condition,native_prompt,bounded_input,implementation_identity
from native_adapter.task_recipe import CONTRACT_RECIPE
from native_adapter.prompt_profiles import ZERO_SHOT,ONE_SHOT


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tokenizer-json',type=Path,required=True)
    parser.add_argument('--screen-sources',type=Path)
    args=parser.parse_args()
    from tokenizers import Tokenizer
    tok=Tokenizer.from_file(str(args.tokenizer_json));count=lambda text:len(tok.encode(text,add_special_tokens=True).ids)
    original=json.loads((ROOT/'tests/fixtures/original_ordinary_requests.json').read_text())['items']
    items=[];go={};invariants=[];maximum=0
    for row in original:
        legacy=compile_condition(row['condition']);plan=compile_condition(row['condition'],contract_recipe=CONTRACT_RECIPE);requests={}
        for model in ('knowcoder','gollie'):
            bound=bounded_input(plan,model,row['passage'],count if model=='knowcoder' else lambda _:1,profile='positive_anchor')
            route=bound['prompt_profile_identity']['recipe_route']
            if route=='preserved_zero_shot_ner':
                assert bound['prompt']==row['requests'][model]['prompt']
                invariant='original_zero_shot_target_and_prompt_unchanged'
            elif route=='preserved_fixed_re_family_one_shot':
                assert bound['prompt']==native_prompt(legacy,model,row['passage'],profile='positive_anchor',prompt_profile=ONE_SHOT)
                invariant='previous_fixed_re_one_shot_prompt_unchanged'
            else:invariant='explicit_new_task_contract'
            invariants.append({'case_id':row['case_id'],'model':model,'route':route,'invariant':invariant,'prompt_sha256':bound['prompt_sha256']})
            if model=='knowcoder':maximum=max(maximum,bound['input_tokens'])
            else:del bound['input_tokens'];go[row['case_id']]=dict(bound)
            requests[model]=bound
        items.append({key:row[key] for key in ('case_id','source_id','passage','condition')}|
                     {'plan':plan,'plan_sha256':requests['knowcoder']['plan_sha256'],'profile':'positive_anchor',
                      'prompt_profile':CONTRACT_RECIPE,'contract_recipe':CONTRACT_RECIPE,'requests':requests})
    screens=[]
    if args.screen_sources:
        for row in json.loads(args.screen_sources.read_text()):
            plan=compile_condition(row['condition'],contract_recipe=CONTRACT_RECIPE)
            if not plan['supported'] or plan['family']=='aggregate_counts_quantities':continue
            for stage in list(plan.get('stage_contract') or {None:None}):
                bound=bounded_input(plan,'knowcoder',row['passage'],count,profile='positive_anchor',task_stage=stage)
                screens.append({'source_id':row['id'],'stage':stage,'input_tokens':bound['input_tokens'],
                                'route':bound['prompt_profile_identity']['recipe_route'],'prompt_sha256':bound['prompt_sha256']})
    packet={'status':'PREPARED_NOT_EXECUTED','contract_recipe':CONTRACT_RECIPE,'prompt_profile':CONTRACT_RECIPE,
            'schema_profile':'positive_anchor','ordinary_sources':9,'reference_companions':0,'model_calls':0,'items':items}
    receipt={'model_calls':0,'development_selected':True,'max_know_same9_input_tokens':maximum,'output_reserve':512,
             'context_limit':2048,'actual_tokenizer_add_special_tokens':True,'tokenizer_json_sha256':hashlib.sha256(args.tokenizer_json.read_bytes()).hexdigest(),
             'screen_noncount_stage_prompts':len(screens),'max_screen_input_tokens':max((row['input_tokens'] for row in screens),default=None),
             'compiler_implementation_files':implementation_identity(),'same9_invariants':invariants,'screen_token_checks':screens,
             'counts_qualified':False,'resolved_event_roles_claimed':False,'gollie_actual_runtime_tokenizer_required':True}
    for name,value in (('task-contract-requests.json',packet),('gollie-binding-contracts.json',go),('evidence/task-contract-binding-receipt.json',receipt)):
        (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({key:receipt[key] for key in ('max_know_same9_input_tokens','max_screen_input_tokens','screen_noncount_stage_prompts','output_reserve','context_limit','model_calls')}))


if __name__=='__main__':main()

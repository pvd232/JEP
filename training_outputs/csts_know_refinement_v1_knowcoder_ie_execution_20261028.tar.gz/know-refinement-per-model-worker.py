"""Single final Know-only SAME9 development refinement; no Go generation or control companions."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ROOT=TASK/'know-refinement-v1-execution/native-know-refinement-capture-v1'
ENV=TASK/'environments/knowcoder-author-py310'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def main():
    output=TASK/'results/know-refinement-v1-knowcoder_ie';receipt=TASK/'results/know-refinement-v1-knowcoder_ie-worker.json';log=TASK/'logs/know-refinement-v1-knowcoder_ie.log';archive=TASK/'results/know-refinement-v1-knowcoder_ie-execution.tar.gz'
    if any(path.exists() for path in [output,receipt,log,archive]):raise ValueError('Final Know refinement attempt exists; inspect, do not repeat')
    record={'status':'started','phase':'preflight','model':'knowcoder_ie','started_at':time.time(),'development_cases':9,'reference_companions':0,'output_token_cap':512,'automatic_retries':False,'go_generation_calls':0,'count_calls':0,'fresh_or_locked_calls':False,'quality_passed':False,'spatial_context_limit':4096,'other_know_context_limit':2048,'prior_captures_unchanged':True}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    try:
        for model in ['knowcoder','gollie']:
            prior=TASK/('results/count-evidence-v1-'+model+'-worker.json')
            if json.loads(prior.read_text()).get('status')!='complete':raise RuntimeError('Prior own CountEvidence worker not complete; no overlapping generation')
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if digest(setup)!='3ac4252a8f81be39bd713d70006fa13cd2dbf63f5876296ff1955f0728f25a94' or json.loads(setup.read_text()).get('status')!='ready_import_verified':raise ValueError('Historical runtime receipt differs')
        control=TASK/'results/knowcoder-legacy-author-attempt02-worker.json'
        if json.loads(control.read_text()).get('status')!='complete':raise ValueError('Canonical Know backend controls not complete')
        record['backend_controls_receipt_sha256']=digest(control)
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')];required=int(total*0.6)+8*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True,'gpu_memory_utilization':0.6};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: actual free memory below reviewed budget')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-know-refinement'));runtime.pop('PYTHONPATH',None)
        snapshot=TASK/'checkpoints/knowcoder/models--golaxy--KnowCoder-7B-IE/snapshots/90ba076763dfb2e9efefd84a0e599f15ae533597'
        command=[str(ENV/'bin/python'),str(ROOT/'run_capture.py'),'--model','knowcoder_ie','--snapshot',str(snapshot),'--output',str(output)]
        record.update(phase='model_capture',command=command);write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        complete=json.loads((output/'complete.json').read_text()) if (output/'complete.json').exists() else None;record['completion']=complete
        if result.returncode or not complete or complete.get('status')!='completed':raise RuntimeError('Final Know development capture failed; exact log/raw outputs retained')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=digest(log) if log.exists() else None);write(receipt,record)
        index={str(path.relative_to(TASK)):digest(path) for path in sorted(output.rglob('*')) if path.is_file()} if output.exists() else {}
        index_path=TASK/'results/know-refinement-v1-knowcoder_ie-execution-index.json';write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__),TASK/'environments/knowcoder-author-setup-amendment02.json',TASK/'results/knowcoder-legacy-author-attempt02-worker.json']:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():tf.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
        write(TASK/'results/know-refinement-v1-knowcoder_ie-execution-archive.json',{'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

# Final Know-only fixed development refinement

Exactly the same nine exposed source triples, KnowCoder-7B-IE only. Go is not
rerun. This is the final declared exposed prompt refinement; no additional
recipes or source-dependent selection are implemented.

The new spatial and clause schema/guidance is bound by the frozen core and
explicit prompt_profile native_know_palette_clause_refinement_v1. Spatial input
budget is4096; the other eight cases remain2048. The pinned historical engine
already uses4096 and its settings/weights/FP16/greedy/512 output cap remain
unchanged. Actual native tokenizer counts must equal the fixed packet. The
largest spatial input2511+512 fits its declared4096 budget.

Know NER4/Color2 and allGo9 proof prompts remain byte-identical to the prior
recipe as recorded by core. There are no Go/control/count/locked/fresh model
calls. Empty, malformed, source-ungrounded and truncated predictions remain
separate failures; no prefix or semantic repairs are performed.

Run one fresh output with the exact pinned IE snapshot:

```
HISTORICAL_PYTHON run_capture.py --model knowcoder_ie --snapshot PINNED_IE --output NEW_OUTPUT
```

The reused author vLLM backend,0.6 resource cap,max_num_seqs4 and original
archive/error/raw-token capture behavior remain unchanged. This is a finite
development check, not a quality/production or transfer approval.

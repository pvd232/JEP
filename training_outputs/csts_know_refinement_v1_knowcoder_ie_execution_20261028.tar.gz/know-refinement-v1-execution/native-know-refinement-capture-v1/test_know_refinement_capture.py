"""CPU-only exact native binding tests; no model calls."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
from tokenizers import Tokenizer
import run_capture as capture


class PinnedTokenizer:
    eos_token_id=2
    def __init__(self):self.tokenizer=Tokenizer.from_file(str(capture.ROOT/'legacy_support/pinned-metadata/ie/tokenizer.json'))
    def encode(self,text,add_special_tokens=True):return self.tokenizer.encode(text,add_special_tokens=add_special_tokens).ids


class RefinementTests(unittest.TestCase):
    def test_all_nine_exact_bindings_and_declared_contexts(self):
        cases=capture.build_cases('knowcoder_ie',PinnedTokenizer())
        self.assertEqual(len(cases),9)
        for case in cases:
            bound=case['binding']
            self.assertEqual(bound['prompt_profile'],capture.PROMPT_PROFILE)
            self.assertEqual(bound['max_new_tokens'],512)
            self.assertEqual(bound['context_limit'],4096 if case['case_id']=='spatial_qualifier' else 2048)
            self.assertLessEqual(bound['input_tokens']+512,bound['context_limit'])
        self.assertEqual(max(c['binding']['input_tokens'] for c in cases),2511)
    def test_go_is_not_a_dispatch_model(self):
        with self.assertRaises(ValueError):capture.build_cases('gollie',PinnedTokenizer())
    def test_changed_source_and_helper_metadata_rejected(self):
        for field in ('source','helper'):
            tok=PinnedTokenizer()
            with tempfile.TemporaryDirectory() as directory:
                root=Path(directory)
                for name in ('ordinary-requests.json','know-refinement-requests.json'):(root/name).write_bytes((capture.ROOT/name).read_bytes())
                packet=json.loads((root/'know-refinement-requests.json').read_bytes())
                if field=='source':packet['items'][0]['passage']+=' changed'
                else:packet['items'][0]['requests']['knowcoder']['implementation_sha256']['normalize.py']='0'*64
                (root/'know-refinement-requests.json').write_text(json.dumps(packet))
                with patch.object(capture,'ROOT',root),self.assertRaises(ValueError):capture.build_cases('knowcoder_ie',tok)

if __name__=='__main__':unittest.main()

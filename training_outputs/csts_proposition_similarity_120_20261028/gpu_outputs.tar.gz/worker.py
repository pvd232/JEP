import fcntl,hashlib,json,subprocess,sys,time,tarfile
from pathlib import Path
root=Path(__file__).parent
status={'status':'starting','started_unix':time.time()}
def save():
    temp=root/'status.tmp';temp.write_text(json.dumps(status,indent=2)+'\n');temp.replace(root/'status.json')
save()
try:
    with Path('/tmp/jep-gpu.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        status['status']='testing';save()
        test=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_proposition_similarity.py','-v'],cwd=root,stdout=(root/'tests.log').open('x'),stderr=subprocess.STDOUT)
        if test.returncode:raise RuntimeError('CPU/tensor tests failed')
        status.update(status='encoding',test_returncode=test.returncode);save()
        command=[sys.executable,'-m','csts_pilot.proposition_similarity','encode','--inputs',str(root/'inputs.json'),'--output',str(root/'output'),'--model-cache','/root/.cache/huggingface/hub/models--Qwen--Qwen3-Embedding-8B/snapshots/c90816d848505624c2434128dfc61132162a0ee9']
        result=subprocess.run(command,cwd=root,stdout=(root/'encoding.log').open('x'),stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError('Encoding subprocess failed: '+str(result.returncode))
        receipt=json.loads((root/'output/receipt.json').read_text())
        if receipt['status']!='complete':raise RuntimeError('Incomplete encoding receipt')
        status.update(status='complete',completed_unix=time.time(),receipt_sha256=hashlib.sha256((root/'output/receipt.json').read_bytes()).hexdigest());save()
        target=Path(str(root)+'-outputs.tar.gz')
        with tarfile.open(target,'w:gz') as archive:
            for name in ['output','inputs.json','plan.md','execution_seal.json','dispatch.json','worker.py','worker.log','status.json','tests.log','encoding.log','csts_pilot/proposition_similarity.py','tests/test_proposition_similarity.py']:
                archive.add(root/name,arcname=name)
        print(json.dumps({'archive':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size}),flush=True)
except Exception as exc:
    status.update(status='failed',error_type=type(exc).__name__,error=str(exc),completed_unix=time.time());save();raise

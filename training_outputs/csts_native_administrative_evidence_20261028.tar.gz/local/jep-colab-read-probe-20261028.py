import sys, subprocess, json, shutil
from importlib import metadata
print(json.dumps({"python":sys.version,"disk_content":shutil.disk_usage("/content")._asdict()}))
for name in ("torch", "transformers", "accelerate", "flash-attn", "google-colab"):
    try:
        print(name,metadata.version(name))
    except metadata.PackageNotFoundError:
        print(name,"not_installed")
for command in (
    ["nvidia-smi","--query-gpu=name,memory.total,memory.used,utilization.gpu","--format=csv,noheader"],
    ["nvidia-smi","--query-compute-apps=pid,process_name,used_gpu_memory","--format=csv,noheader"],
):
    result=subprocess.run(command,capture_output=True,text=True,timeout=10)
    print(result.stdout or result.stderr)

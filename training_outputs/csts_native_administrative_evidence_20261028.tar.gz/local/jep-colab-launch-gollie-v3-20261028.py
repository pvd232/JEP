from pathlib import Path
import hashlib, json, tarfile, subprocess, os, sys
root=Path("/content/jep-extraction-screen-20261028")
bundle=root/"gollie-v3-bundle.tar.gz"
expected="577a7f55c79d1dea8ce37778f6e589d9f994d939a185846d9e4cb0191153d2f4"
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"bundle hash differs"
receipt=root/"gollie-v3-worker.json"
assert not receipt.exists(),"Worker receipt exists: inspect prior worker, do not relaunch"
destination=root/"execution-v3"
assert not destination.exists(),"v3 execution directory exists: inspect before retry"
destination.mkdir()
with tarfile.open(bundle) as archive:
    for member in archive.getmembers():
        candidate=(destination/member.name).resolve()
        assert candidate.is_relative_to(destination.resolve()) and not member.issym() and not member.islnk(),"unsafe archive member"
    archive.extractall(destination,filter="data")
run=destination/"run"
assert not (run/"captures").exists(),"v3 captures already exist"
protocol_hash=hashlib.sha256((run/"protocol.json").read_bytes()).hexdigest()
assert protocol_hash=="e5fcace356bbc1310f90ce90e36811120472f4240b9a5317b4ebc52260fd584d","protocol hash differs"
original=root/"execution"/"run"
for name in ("labels.json","sources.json","pairs.json","references.json","references-seal.json"):
    assert (original/name).read_bytes()==(run/name).read_bytes(),"source/reference bytes differ: "+name
worker=root/"run_gollie_v3.py"
worker.write_text("""from pathlib import Path
import sys,time,json,traceback
sys.path.insert(0,"/content/jep-extraction-screen-20261028/execution-v3/repository")
from csts_pilot.extraction_comparison import run_arm,verify_run
run=Path("/content/jep-extraction-screen-20261028/execution-v3/run")
verify_run(run)
print(json.dumps({"event":"gollie_v3_started","at":time.time()}),flush=True)
try:
 result=run_arm(run,"gollie",cli="unused",execute=True,device="cuda")
 print(json.dumps({"event":"gollie_v3_completed","result":result,"at":time.time()}),flush=True)
except Exception as exc:
 print(json.dumps({"event":"gollie_v3_failed","error_type":type(exc).__name__,"error":str(exc),"at":time.time()}),flush=True)
 traceback.print_exc()
 raise
""")
log=root/"gollie-v3.log"
with receipt.open("x") as handle:
    json.dump({"status":"prepared","bundle_sha256":expected,"protocol_sha256":protocol_hash},handle)
environment=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1")
with log.open("x") as output:
    process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=root,env=environment)
record={"pid":process.pid,"log":str(log),"bundle_sha256":expected,"protocol_sha256":protocol_hash,"status":"dispatched"}
receipt.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))

"""Author-pinned setuptools plus correct vLLM0.2.2 extension gate; core wheels unchanged."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
INITIAL=TASK/'environments/knowcoder-author-setup.json'
RECEIPT=TASK/'environments/knowcoder-author-setup-amendment01.json'
LOG=TASK/'logs/knowcoder-author-setup-amendment01.log'
ARCHIVE=TASK/'results/knowcoder-author-setup-amendment01-artifacts.tar.gz'
ARTIFACTS=TASK/'results/knowcoder-author-environment-amendment01'
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def main():
    if any(p.exists() for p in [RECEIPT,LOG,ARCHIVE,ARTIFACTS]):raise ValueError('Amendment exists: inspect, do not relaunch')
    previous=json.loads(INITIAL.read_text())
    if previous['status']!='failed' or previous.get('commands',[])[-1]['returncode']!=1:raise ValueError('Expected retained initial import-gate failure')
    purelib=ENV/'lib/python3.10/site-packages'
    compiled=sorted(path.name.split('.')[0] for path in (purelib/'vllm').glob('*.so'))
    required={'attention_ops','cache_ops','pos_encoding_ops','layernorm_ops','activation_ops'}
    if not required.issubset(compiled):raise ValueError('Actual official vLLM wheel lacks required historical extension modules: '+repr(compiled))
    ARTIFACTS.mkdir(parents=True)
    runtime=dict(os.environ,UV_PYTHON_INSTALL_DIR=str(TASK/'environments/managed-python'),UV_CACHE_DIR=str(TASK/'cache/uv'),PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='',UV_NO_PROGRESS='1')
    runtime.pop('PYTHONPATH',None)
    record={'status':'started','started_at':time.time(),'environment':str(ENV),'retained_initial_receipt_sha256':hashlib.sha256(INITIAL.read_bytes()).hexdigest(),'actual_vllm_compiled_modules':compiled,'amendment':'Author setuptools68.0.0 + historical extension contract + exact official Flash local metadata version','core_wheels_reinstalled':False,'shared_packages_modified':False,'model_calls':False,'commands':[]}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    with LOG.open('x') as log:
        def command(args,timeout=180):
            print('COMMAND '+json.dumps(args),file=log,flush=True)
            result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=runtime,cwd=TASK,text=True,timeout=timeout)
            log.write(result.stdout);log.flush();record['commands'].append({'argv':args,'returncode':result.returncode});write(RECEIPT,record)
            if result.returncode:raise RuntimeError('Historical import amendment failed; retained log, exit='+str(result.returncode))
            return result.stdout
        try:
            python=str(ENV/'bin/python')
            probe="import sys,sysconfig,json;from pathlib import Path;assert sys.version_info[:2]==(3,10);assert Path(sys.prefix).resolve()==Path("+repr(str(ENV))+").resolve();p=Path(sysconfig.get_paths()['purelib']);assert p.is_relative_to(Path(sys.prefix));print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,'purelib':str(p)}))"
            record['interpreter']=json.loads(command([python,'-c',probe],30))
            command(['uv','pip','install','--python',python,'setuptools==68.0.0'])
            check=command(['uv','pip','check','--python',python]);(ARTIFACTS/'uv-pip-check.txt').write_text(check)
            freeze=command(['uv','pip','freeze','--python',python]);(ARTIFACTS/'resolved-requirements.txt').write_text(freeze)
            code="""import json,sys,sysconfig,importlib,importlib.metadata as m
from pathlib import Path
import torch,transformers,tokenizers,xformers,ray,vllm,flash_attn,accelerate,pkg_resources
from flash_attn.layers.rotary import apply_rotary_emb_func
from flash_attn.flash_attn_interface import flash_attn_kvpacked_func,flash_attn_varlen_kvpacked_func
import flash_attn_2_cuda
from transformers import PreTrainedModel
from transformers.generation import GenerationMixin
expected={'torch':'2.1.0+cu118','transformers':'4.34.1','tokenizers':'0.14.1','vllm':'0.2.2+cu118','flash-attn':'2.3.4+cu118torch2.1cxx11abifalse','accelerate':'0.23.0','setuptools':'68.0.0'}
actual={k:m.version(k) for k in expected}
assert actual==expected,(actual,expected)
assert torch._C._GLIBCXX_USE_CXX11_ABI is False
assert issubclass(PreTrainedModel,GenerationMixin)
modules=sorted(path.name.split('.')[0] for path in Path(vllm.__file__).parent.glob('*.so'))
for name in modules:importlib.import_module('vllm.'+name)
print(json.dumps({'packages':actual,'flash_module_version':flash_attn.__version__,'torch_cuda':torch.version.cuda,'torch_cxx11_abi':torch._C._GLIBCXX_USE_CXX11_ABI,'prefix':sys.prefix,'purelib':sysconfig.get_paths()['purelib'],'vllm_compiled_modules_imported':modules,'ray_import':True,'pkg_resources_import':True,'flash_rotary_import':True,'flash_cuda_extension_import':True,'cuda_device_count_hidden':torch.cuda.device_count()}))
"""
            record['imports']=json.loads(command([python,'-c',code],180).splitlines()[-1])
            (ARTIFACTS/'import-versions.json').write_text(json.dumps(record['imports'],indent=2)+'\n')
            record.update(status='ready_import_verified',gpu_kernel_smoke_pending=True)
        except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        finally:
            record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest());write(RECEIPT,record)
    with tarfile.open(ARCHIVE,'w:gz') as archive:
        for path in [INITIAL,RECEIPT,LOG,Path(__file__),*sorted(ARTIFACTS.rglob('*'))]:
            if path.is_file():archive.add(path,arcname=str(path.relative_to(TASK)))
    write(TASK/'results/knowcoder-author-setup-amendment01-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status']})
    print(json.dumps(record),flush=True)
    if record['status']!='ready_import_verified':sys.exit(1)
if __name__=='__main__':main()

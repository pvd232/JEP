def _jep_gpu_ownership_readonly_20261028():
    from pathlib import Path
    import json,subprocess,os
    record={'kind':'read_only_gpu_ownership'}
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,memory.used,utilization.gpu','--format=csv,noheader'],capture_output=True,text=True,timeout=20)
    procs=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20)
    record.update(gpu=gpu.stdout,gpu_processes=procs.stdout,process_details=[])
    for line in procs.stdout.splitlines():
        first=line.split(',')[0].strip()
        if not first.isdecimal():continue
        pid=int(first);root=Path('/proc')/str(pid);row={'pid':pid}
        try:
            row['executable']=os.readlink(root/'exe');row['cwd']=os.readlink(root/'cwd')
            words=(root/'cmdline').read_bytes().split(b'\0')
            row['command_executable']=words[0].decode(errors='replace') if words else None
            row['script_path']=words[1].decode(errors='replace') if len(words)>1 and words[1].endswith(b'.py') else '[not a script argument]'
            status=(root/'status').read_text()
            row['ppid']=next((x.split(':',1)[1].strip() for x in status.splitlines() if x.startswith('PPid:')),None)
            row['stdout_target']=os.readlink(root/'fd/1')
            row['start_time']=subprocess.run(['ps','-p',str(pid),'-o','lstart='],capture_output=True,text=True,timeout=10).stdout.strip()
            row['ancestry']=[]
            ancestor=row.get('ppid')
            for _ in range(4):
                if not ancestor or ancestor=='0':break
                parent=Path('/proc')/ancestor
                if not parent.exists():break
                parent_words=(parent/'cmdline').read_bytes().split(b'\0')
                parent_status=(parent/'status').read_text()
                ppid=next((x.split(':',1)[1].strip() for x in parent_status.splitlines() if x.startswith('PPid:')),None)
                row['ancestry'].append({'pid':ancestor,'ppid':ppid,'comm':(parent/'comm').read_text().strip(),'script_path':parent_words[1].decode(errors='replace') if len(parent_words)>1 and parent_words[1].endswith(b'.py') else '[not a script argument]'})
                ancestor=ppid
            row['elapsed']=subprocess.run(['ps','-p',str(pid),'-o','etime='],capture_output=True,text=True,timeout=10).stdout.strip()
        except Exception as error:row['inspection_error_type']=type(error).__name__
        record['process_details'].append(row)
    task=Path('/content/jep-native-author-calibration-20261028')
    record['known_workers']={}
    for name in ['knowcoder-legacy-author-dispatch.json','results/knowcoder-legacy-author-worker.json','gollie-author-legacy-dispatch.json','results/gollie-author-legacy-worker.json']:
        path=task/name
        record['known_workers'][name]=json.loads(path.read_text()) if path.exists() else None
    print(json.dumps(record),flush=True)
_jep_gpu_ownership_readonly_20261028()
del _jep_gpu_ownership_readonly_20261028

def _jep_audit_gollie_cached_artifacts_20261028():
    from pathlib import Path
    import hashlib,json,time,traceback
    expected={'repository': 'HiTZ/GoLLIE-7B', 'revision': 'd3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9', 'primary_receipt_sha256': '6e258de99a0b3e3bc4cb67c79b43861310e10271ae6c48343949c53ecb17a95f', 'metadata': {'config.json': '3d0a49e7ba66da12efb0258324e6a685414854c2d16f88b9f86ede7a8a5c2c72', 'generation_config.json': 'afcf2a1da583dbeb66bb367a759713901e23ce19ed83ed8f5a21b0e877addd5b', 'tokenizer_config.json': 'ec29328f38605463d4c2debbc2a966a7899fe5b4c0f23ba6d091bc2515538da8', 'tokenizer.json': '3133bbcd5bf9bae98264c4c081882eef2ceccf9ab6fc9a8dfbcf1f72dbd7a21c', 'special_tokens_map.json': '8ae784bff9067527c68e2bf642edfc9f1b82e2fc8cda728df29b69680917fed7', 'pytorch_model.bin.index.json': 'cca4bc7c3ac8ea3f39416f5ce1af31bf2e4175bced52ad53555b54e9d1614af6', 'modeling_flash_llama.py': '39ed69a0a8f40344981ba6c142074ea315769a770d959ef214aab41d181a6dbd'}, 'shards': {'pytorch_model-00001-of-00002.bin': {'sha256': '07bc7ccfaa747f057747ac1b524febb1de12a9464eaee6cc8c200f6616950f09', 'bytes': 9977144957}, 'pytorch_model-00002-of-00002.bin': {'sha256': '92130c88131cadbc27c581eba81a933d19879ac8c304321bfd3e8cb57e054f8a', 'bytes': 3500581594}}}
    snapshot=Path('/root/.cache/huggingface/hub/models--HiTZ--GoLLIE-7B/snapshots')/expected['revision']
    output=Path('/content/jep-native-author-calibration-20261028/results/gollie-pinned-artifact-audit-20261028.json')
    if output.exists():
        print(output.read_text(),flush=True)
        return
    record={'status':'started','started_at':time.time(),'snapshot':str(snapshot),'repository':expected['repository'],'revision':expected['revision'],'primary_receipt_sha256':expected['primary_receipt_sha256'],'model_calls':False,'gpu_calls':False,'metadata':{},'shards':{},'missing_optional_metadata':[]}
    with output.open('x') as f:json.dump(record,f,indent=2)
    try:
        for name,digest in expected['metadata'].items():
            path=snapshot/name
            if not path.exists() and name=='generation_config.json':
                record['missing_optional_metadata'].append(name)
                continue
            with path.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
            record['metadata'][name]={'sha256':actual,'expected_sha256':digest,'verified':actual==digest}
            if actual!=digest:raise ValueError('Pinned metadata bytes differ: '+name)
        index=json.loads((snapshot/'pytorch_model.bin.index.json').read_text())
        if len(index['weight_map'])!=291 or set(index['weight_map'].values())!=set(expected['shards']):raise ValueError('Pinned291-tensor/two-shard index differs')
        for name,identity in expected['shards'].items():
            path=snapshot/name
            size=path.stat().st_size
            with path.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
            verified=actual==identity['sha256'] and size==identity['bytes']
            record['shards'][name]={'sha256':actual,'expected_sha256':identity['sha256'],'bytes':size,'expected_bytes':identity['bytes'],'verified':verified}
            if not verified:raise ValueError('Pinned primary LFS bytes differ: '+name)
        record.update(status='verified',indexed_tensors=291,actual_shards=2,weight_bytes_verified=True,metadata_bytes_verified=True)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record['finished_at']=time.time();temporary=output.with_suffix('.tmp');temporary.write_text(json.dumps(record,indent=2)+'\n');temporary.replace(output)
    print(json.dumps(record),flush=True)
_jep_audit_gollie_cached_artifacts_20261028()
del _jep_audit_gollie_cached_artifacts_20261028

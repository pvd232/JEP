def _jep_author_model_progress_readonly_20261028():
    from pathlib import Path
    import json,subprocess
    task=Path('/content/jep-native-author-calibration-20261028')
    cases={
      'know_canonical':('results/knowcoder-legacy-author-attempt02-worker.json','logs/knowcoder-legacy-author-attempt02-ie.log','results/knowcoder-legacy-author-attempt02-ie'),
      'go_canonical':('results/gollie-author-legacy-attempt03-worker.json','logs/gollie-author-legacy-attempt03.log','results/gollie-author-legacy-attempt03'),
      'know_ordinary':('results/ordinary-native-v3-knowcoder_ie-worker.json','logs/ordinary-native-v3-knowcoder_ie.log','results/ordinary-native-v3-knowcoder_ie'),
      'go_ordinary':('results/ordinary-native-v3-gollie-worker.json','logs/ordinary-native-v3-gollie.log','results/ordinary-native-v3-gollie'),
    }
    record={}
    for name,(receipt,log,directory) in cases.items():
        path=task/receipt;row={'worker_receipt_exists':path.exists()}
        if path.exists():
            raw=json.loads(path.read_text())
            row['worker']={k:v for k,v in raw.items() if k in ['status','phase','started_at','finished_at','model','model_process_started','gpu_scheduling','error_type','error','returncode','completion','checkpoints']}
        path=task/log
        if path.exists():row['model_log_tail']=path.read_text(errors='replace')[-2200:]
        root=task/directory
        if root.exists():
            row['generation_files']=len(list(root.glob('*-generation.json')))
            row['result_files']=len(list(root.glob('*-result.json')))
            row['all_json_names']=[p.name for p in sorted(root.glob('*.json')) if not p.name.endswith(('-generation.json','-result.json'))][:12]
            for candidate in ['complete.json','completed.json']:
                path=root/candidate
                if path.exists():row[candidate]=json.loads(path.read_text())
        record[name]=row
    gpu=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20)
    procs=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20)
    record['actual_gpu']={'total_free_utilization':gpu.stdout,'compute_processes':procs.stdout}
    print(json.dumps(record),flush=True)
_jep_author_model_progress_readonly_20261028()
del _jep_author_model_progress_readonly_20261028

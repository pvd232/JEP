def _jep_ordinary_native_v3_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os,tarfile
    task=Path('/content/jep-native-author-calibration-20261028')
    worker=task/'ordinary-native-execution-worker.py'
    receipt=task/'ordinary-native-v3-dispatch.json'
    root=task/'ordinary-native-capture-v3-execution'
    bundle=Path('/content/jep-ordinary-native-capture-v3-bundle-20261028.tar.gz')
    assert hashlib.sha256(worker.read_bytes()).hexdigest()=='9496ac580e0624173764db48e280b05f88b4750f92b3de136dd3f3bb126b8f87','Ordinary worker changed'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='6709c82065b3928678e75d3e02e78d1ff0631889a55fe5b9883cf9db91da9b0e','Ordinary capture bundle changed'
    assert not receipt.exists() and not root.exists(),'Ordinary dispatch exists: inspect, do not repeat'
    assert json.loads((task/'results/knowcoder-legacy-author-attempt02-worker.json').read_text())['status']=='complete','Canonical Know controls not complete'
    assert json.loads((task/'results/gollie-author-legacy-worker.json').read_text())['status']=='complete','Canonical Go backend probe not complete'
    memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
    total,free=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')]
    assert free>=int(total*0.6)+8*1024,'Ordinary Know needs0.6 total plus8GiB free reserve'
    root.mkdir()
    with tarfile.open(bundle) as archive:archive.extractall(root,filter='data')
    with receipt.open('x') as handle:json.dump({'status':'prepared','worker_sha256':'9496ac580e0624173764db48e280b05f88b4750f92b3de136dd3f3bb126b8f87'},handle)
    log=task/'logs/ordinary-native-v3-controller.log'
    with log.open('x') as output:process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'status':'dispatched','pid':process.pid,'worker_sha256':'9496ac580e0624173764db48e280b05f88b4750f92b3de136dd3f3bb126b8f87','log':str(log),'models_sequential':True,'max_output_tokens':512,'frozen_ordinary_cases_per_model':9,'separate_know_reference_controls':2}
    receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
_jep_ordinary_native_v3_launch_20261028()
del _jep_ordinary_native_v3_launch_20261028

"""Approved v5 BASE then IE probes, fresh processes, complete guard/model evidence."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
ROOT=TASK/'knowcoder-legacy-vllm-v5-execution/knowcoder-legacy-vllm-v5'
RECEIPT=TASK/'results/knowcoder-legacy-author-attempt02-worker.json'
ARCHIVE=TASK/'results/knowcoder-legacy-author-attempt02-results.tar.gz'
IDENTITIES={'base':('KnowCoder-7B-base','4a7a076f573fe87fe0a97670c63c64214484742f'),'ie':('KnowCoder-7B-IE','90ba076763dfb2e9efefd84a0e599f15ae533597')}
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def gpu_ready():
    processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20,check=True)
    memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20,check=True)
    total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')]
    required=int(total*0.6)+8*1024
    state={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True,'gpu_memory_utilization':0.6}
    return state,free>=required
def main():
    if RECEIPT.exists() or ARCHIVE.exists():raise ValueError('Know attempt02 exists; inspect, do not relaunch')
    record={'status':'started','phase':'preflight','started_at':time.time(),'checkpoints':{},'gpu_scheduling':{},'primary_outputs_and_failed_attempt_unchanged':True,'model_runs_per_checkpoint':1,'checkpoint_order':['base','ie'],'gpu_memory_utilization':0.6,'historical_core_runtime_separate_condition':True}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    outputs=[];logs=[]
    try:
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if json.loads(setup.read_text())['status']!='ready_import_verified':raise ValueError('Historical imports gate not ready')
        record['setup_receipt_sha256']=hashlib.sha256(setup.read_bytes()).hexdigest()
        go=TASK/'results/gollie-author-legacy-attempt02-worker.json'
        record['phase']='waiting_for_prior_go_exit';write(RECEIPT,record)
        deadline=time.monotonic()+1500
        while json.loads(go.read_text())['status'] not in ('complete','failed'):
            if time.monotonic()>deadline:raise RuntimeError('Prior own Go worker did not finish; no overlapping generation')
            time.sleep(2)
        record['phase']='canonical_controls';write(RECEIPT,record)
        for key in IDENTITIES:
            if (TASK/('results/knowcoder-legacy-author-attempt02-'+key)).exists() or (TASK/('logs/knowcoder-legacy-author-attempt02-'+key+'.log')).exists():raise ValueError('Fresh checkpoint outputs/logs required')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-legacy'),TOKENIZERS_PARALLELISM='false');runtime.pop('PYTHONPATH',None)
        for key,(name,rev) in IDENTITIES.items():
            state,ready=gpu_ready();record['gpu_scheduling'][key]=state;write(RECEIPT,record)
            if not ready:raise RuntimeError('Preserve other work: Know needs0.6 total plus8GiB actual free reserve')
            snapshot=TASK/'checkpoints/knowcoder'/('models--golaxy--'+name)/'snapshots'/rev
            if not snapshot.is_dir():raise ValueError('Pinned existing snapshot missing: '+str(snapshot))
            output=TASK/('results/knowcoder-legacy-author-attempt02-'+key);outputs.append(output)
            log=TASK/('logs/knowcoder-legacy-author-attempt02-'+key+'.log');logs.append(log)
            command=[str(ENV/'bin/python'),str(ROOT/'run_legacy.py'),'--checkpoint',key,'--snapshot-path',str(snapshot),'--output',str(output)]
            record.update(phase='checkpoint_'+key);record['checkpoints'][key]={'status':'started','command':command};write(RECEIPT,record)
            started=time.time()
            with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,check=False,timeout=1200)
            record['checkpoints'][key].update(returncode=result.returncode,elapsed_seconds=time.time()-started,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());write(RECEIPT,record)
            if result.returncode:raise RuntimeError('Canonical '+key+' failed; retained exact log, no blind retry')
            complete=json.loads((output/'complete.json').read_text())
            if complete['completed_cells']!=15:raise ValueError('Expected15 fixed canonical cells')
            record['checkpoints'][key].update(status='complete',completion=complete);write(RECEIPT,record)
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record['finished_at']=time.time();write(RECEIPT,record)
        index={}
        for directory in outputs:
            if directory.exists():
                for path in sorted(directory.rglob('*')):
                    if path.is_file():index[str(path.relative_to(TASK))]=hashlib.sha256(path.read_bytes()).hexdigest()
        index_path=TASK/'results/knowcoder-legacy-author-attempt02-capture-index.json';write(index_path,index)
        with tarfile.open(ARCHIVE,'w:gz') as archive:
            for path in [RECEIPT,index_path,Path(__file__),TASK/'environments/knowcoder-author-setup-amendment02.json',*logs]:
                if path.exists():archive.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():archive.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            for directory in outputs:
                if directory.exists():archive.add(directory,arcname=str(directory.relative_to(TASK)))
        write(TASK/'results/knowcoder-legacy-author-attempt02-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

def _jep_read_know_progress_20261028():
    from pathlib import Path
    import json, subprocess
    task=Path('/content/jep-native-author-calibration-20261028')
    result={}
    for name in ['knowcoder-legacy-author-attempt02-dispatch-recovery01.json',
                 'results/knowcoder-legacy-author-attempt02-worker.json']:
        p=task/name
        if p.exists():
            data=json.loads(p.read_text())
            result[name]={key:value for key,value in data.items() if key not in {'traceback'}}
        else:result[name]=None
    for key in ['base','ie']:
        p=task/('logs/knowcoder-legacy-author-attempt02-'+key+'.log')
        result[key+'_log_tail']=p.read_text(errors='replace')[-4500:] if p.exists() else None
        output=task/('results/knowcoder-legacy-author-attempt02-'+key)
        result[key+'_generation_files']=sum(1 for _ in output.rglob('generation.json')) if output.exists() else 0
    result['gpu_processes']=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=15).stdout
    print(json.dumps(result),flush=True)
_jep_read_know_progress_20261028()
del _jep_read_know_progress_20261028

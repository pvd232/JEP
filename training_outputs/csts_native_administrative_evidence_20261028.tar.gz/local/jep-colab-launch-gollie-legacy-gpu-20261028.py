def _jep_gollie_legacy_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os,tarfile
    task=Path('/content/jep-native-author-calibration-20261028')
    worker=task/'gollie-historical-worker-sharedgpu.py'
    receipt=task/'gollie-author-legacy-dispatch.json'
    assert hashlib.sha256(worker.read_bytes()).hexdigest()=='1b4ffd5d92397ad34af3f5424c5fedff4a9d83d80002686094ef4ea76b2e5954','Worker changed'
    assert not receipt.exists(),'Dispatch receipt exists: inspect, do not relaunch'
    assert json.loads((task/'environments/knowcoder-author-setup-amendment02.json').read_text())['status']=='ready_import_verified','Historical imports/version gate not ready'
    gate=json.loads((task/'environments/knowcoder-author-setup-amendment02.json').read_text())
    assert gate['imports']['packages']['flash-attn']=='2.3.4','Observed Flash distribution version differs'
    assert gate['imports']['flash_module_version']=='2.3.4','Observed Flash module version differs from original approved gate'
    gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
    memory=subprocess.run(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
    assert int(memory.stdout.splitlines()[0].strip())>=45*1024,'Go requires45GiB free; preserve unrelated work'
    bundle=Path('/content/jep-gollie-author-legacy-probe-bundle-20261028.tar.gz')
    root=task/'gollie-author-legacy-probe-execution'
    assert not root.exists(),'GoLLIE execution source directory exists'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='bb170d4f30c90ddf11955e82428456a0275954d1a1c1cd0c6baeaca31388a617','GoLLIE bundle changed'
    root.mkdir()
    with tarfile.open(bundle) as archive:archive.extractall(root,filter='data')
    with receipt.open('x') as handle:json.dump({'status':'prepared','worker_sha256':'1b4ffd5d92397ad34af3f5424c5fedff4a9d83d80002686094ef4ea76b2e5954'},handle)
    log=task/'logs'/'gollie-author-legacy-controller.log'
    with log.open('x') as output:
        process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'status':'dispatched','pid':process.pid,'worker_sha256':'1b4ffd5d92397ad34af3f5424c5fedff4a9d83d80002686094ef4ea76b2e5954','log':str(log),'original_captures_unchanged':True}
    receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
_jep_gollie_legacy_launch_20261028()
del _jep_gollie_legacy_launch_20261028

from pathlib import Path
import json, hashlib, tarfile, io
root=Path("/content/jep-extraction-screen-20261028")
out=Path("/content/jep-extraction-native-results-20261028.tar.gz")
paths=[]
for path in root.rglob("knowcoder"):
    if path.is_dir() and path.parent.name in {"captures","arm-executions"}:
        paths.append(path)
for name in ("native-screen.log","native-worker.json","native-screen-results.json","native-screen-status.json"):
    path=root/name
    if path.exists():
        paths.append(path)
for path in root.rglob("protocol.json"):
    paths.append(path)
for path in root.rglob("manifest.json"):
    if "captures" not in path.parts:
        paths.append(path)
files=sorted({file for path in paths for file in ([path] if path.is_file() else path.rglob("*")) if file.is_file()},key=str)
index={str(path.relative_to(root)):{"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()} for path in files}
with tarfile.open(out,"w:gz") as archive:
    for path in files:
        archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
    data=(json.dumps(index,sort_keys=True,indent=2)+"\n").encode()
    entry=tarfile.TarInfo("capture-index.json")
    entry.size=len(data)
    archive.addfile(entry,io.BytesIO(data))
print("archive",str(out),"bytes",out.stat().st_size,"sha256",hashlib.sha256(out.read_bytes()).hexdigest(),"files",len(files))
for path in sorted(root.rglob("result.json")):
    if "knowcoder" in path.parts:
        record=json.loads(path.read_text())
        print("knowcoder_sample",json.dumps({"id":record.get("id"),"valid":record.get("valid"),"payload":record.get("payload")},ensure_ascii=False))
        break
try:
    from transformers import LlamaConfig
    model="HiTZ/GoLLIE-7B"; revision="d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9"
    config=LlamaConfig.from_pretrained(model,revision=revision,local_files_only=True)
    print("gollie_rope",json.dumps({"rope_scaling_repr":repr(getattr(config,"rope_scaling",None)),"rope_parameters_repr":repr(getattr(config,"rope_parameters",None)),"rope_theta_repr":repr(getattr(config,"rope_theta",None)),"dict_fields":{k:v for k,v in config.to_dict().items() if "rope" in k or "rotary" in k}},ensure_ascii=False))
except Exception as exc:
    print("config_probe_error",type(exc).__name__,str(exc))

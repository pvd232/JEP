"""Run unchanged Go author/reference probe; retain every preflight and resource observation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
ROOT=TASK/'gollie-author-legacy-attempt03-execution/gollie-author-legacy-probe'
OUTPUT=TASK/'results/gollie-author-legacy-attempt03'
LOG=TASK/'logs/gollie-author-legacy-attempt03.log'
RECEIPT=TASK/'results/gollie-author-legacy-attempt03-worker.json'
ARCHIVE=TASK/'results/gollie-author-legacy-attempt03-results.tar.gz'
REV='d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9'
SOURCE_SHA='39ed69a0a8f40344981ba6c142074ea315769a770d959ef214aab41d181a6dbd'
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def main():
    if any(path.exists() for path in [OUTPUT,LOG,RECEIPT,ARCHIVE]):raise ValueError('Go attempt03 exists; inspect, do not rerun')
    record={'status':'started','phase':'preflight','started_at':time.time(),'model_process_started':False,'primary_outputs_unchanged':True,'attempts':1,'model_probe_source_unchanged':True,'prior_attempt_zero_generations':True,'runtime_driver_discovery_amendment_only':True}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    gate=TASK/'environments/knowcoder-author-setup-amendment02.json'
    try:
        observed=json.loads(gate.read_text())
        if observed['status']!='ready_import_verified':raise ValueError('Historical imports not ready')
        if observed['imports']['packages']['flash-attn']!='2.3.4' or observed['imports']['flash_module_version']!='2.3.4':raise ValueError('Actual Flash labels differ from approved original guard')
        record['setup_receipt_sha256']=hashlib.sha256(gate.read_bytes()).hexdigest()
        record['phase']='waiting_for_prior_know_exit';write(RECEIPT,record)
        prior=TASK/'results/knowcoder-legacy-author-attempt02-worker.json'
        deadline=time.monotonic()+1500
        while json.loads(prior.read_text())['status'] not in ('complete','failed'):
            if time.monotonic()>deadline:raise RuntimeError('Prior Know worker did not exit; no overlapping model work')
            time.sleep(2)
        driver_root=TASK/'environments/triton-driver-discovery-v2'
        driver_receipt=driver_root/'receipt.json'
        driver=json.loads(driver_receipt.read_text())
        if driver['status']!='ready_cpu_discovery_verified':raise ValueError('Task-local driver discovery not ready')
        driver_bins=Path(driver['path_prefix'])
        if driver_bins!=driver_root/'bin' or hashlib.sha256((driver_bins/'ldconfig').read_bytes()).hexdigest()!=driver['wrapper_sha256']:raise ValueError('Driver discovery wrapper differs from reviewed receipt')
        record.update(driver_discovery_receipt_sha256=hashlib.sha256(driver_receipt.read_bytes()).hexdigest(),driver_path_prefix=str(driver_bins),driver_wrapper_sha256=driver['wrapper_sha256'])
        from huggingface_hub.constants import HF_HUB_CACHE
        snapshot=Path(HF_HUB_CACHE)/'models--HiTZ--GoLLIE-7B'/'snapshots'/REV
        if not snapshot.is_dir():raise ValueError('Pinned existing Go snapshot missing: '+str(snapshot))
        primary=TASK/'inputs/gollie-pinned-modeling.py'
        if hashlib.sha256(primary.read_bytes()).hexdigest()!=SOURCE_SHA:raise ValueError('Uploaded official source SHA differs')
        source=snapshot/'modeling_flash_llama.py'
        if not source.exists():
            with source.open('xb') as output:output.write(primary.read_bytes())
            record['missing_official_source_staged']=True
        else:record['missing_official_source_staged']=False
        if hashlib.sha256(source.read_bytes()).hexdigest()!=SOURCE_SHA:raise ValueError('Existing author source SHA differs; no overwrite')
        record.update(snapshot=str(snapshot),official_source_sha256=SOURCE_SHA,weights_and_config_unchanged=True)
        gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')]
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':gpu.stdout,'total_mib':total,'free_mib_before_launch':free,'utilization_percent_before_launch':utilization,'required_free_mib':45*1024,'shared_gpu':bool(gpu.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True}
        write(RECEIPT,record)
        if free<45*1024:raise RuntimeError('Preserve other work: Go needs45GiB actual free memory')
        if hashlib.sha256((ROOT/'run_backend_probe.py').read_bytes()).hexdigest()!='4307e70c583529af74ec25a7e031af545fd42c40e6a0ff602e5850f8e001bf3d':raise ValueError('Approved original probe changed')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),TOKENIZERS_PARALLELISM='false');runtime.pop('PYTHONPATH',None);runtime['PATH']=str(driver_bins)+os.pathsep+runtime.get('PATH','')
        command=[str(ENV/'bin/python'),str(ROOT/'run_backend_probe.py'),'--snapshot',str(snapshot),'--output',str(OUTPUT)]
        record.update(phase='model_probe',model_process_started=True,command=command);write(RECEIPT,record)
        with LOG.open('x') as output:result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        if result.returncode:raise RuntimeError('Original Go probe failed; full model log retained')
        complete=json.loads((OUTPUT/'completed.json').read_text())
        if complete.get('completed') is not True:raise ValueError('Go backend probe incomplete')
        record.update(status='complete',phase='finished',completion=complete)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest() if LOG.exists() else None);write(RECEIPT,record)
        index={str(path.relative_to(TASK)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(OUTPUT.rglob('*')) if path.is_file()} if OUTPUT.exists() else {}
        index_path=TASK/'results/gollie-author-legacy-attempt03-capture-index.json';write(index_path,index)
        with tarfile.open(ARCHIVE,'w:gz') as archive:
            for path in [RECEIPT,index_path,Path(__file__),LOG,gate,TASK/'inputs/gollie-pinned-modeling.py',TASK/'logs/gollie-author-legacy-controller.log',TASK/'gollie-historical-worker-sharedgpu.py',TASK/'results/gollie-author-legacy-attempt02-worker.json',TASK/'logs/gollie-author-legacy-attempt02.log',TASK/'environments/triton-driver-discovery-v2/receipt.json',TASK/'environments/triton-driver-discovery-v2/bin/ldconfig',TASK/'environments/triton-driver-discovery-v2/system-ldconfig-p.txt',TASK/'environments/triton-driver-discovery-v2/task-discovery-listing.txt']:
                if path.exists():archive.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():archive.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if OUTPUT.exists():archive.add(OUTPUT,arcname=str(OUTPUT.relative_to(TASK)))
        write(TASK/'results/gollie-author-legacy-attempt03-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

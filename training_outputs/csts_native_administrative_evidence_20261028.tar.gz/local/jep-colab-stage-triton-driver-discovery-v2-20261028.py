def _jep_stage_triton_driver_discovery_v2_20261028():
    from pathlib import Path
    import hashlib, json, os, shlex, subprocess, time, traceback
    task = Path('/content/jep-native-author-calibration-20261028')
    root = task / 'environments/triton-driver-discovery-v2'
    root.mkdir(exist_ok=False)
    receipt = root / 'receipt.json'
    record = {'status': 'started', 'started_at': time.time(),
              'model_calls': False, 'gpu_calls': False,
              'global_cache_or_symlinks_modified': False,
              'activation_scope': 'PATH prefix for future task model subprocess only',
              'method': 'Supplement real ldconfig -p text with verified real driver; no cache is built or changed',
              'supersedes_unexecuted_helper': 'alternate-cache v1 rejected because glibc may write its global auxiliary cache'}
    def save():
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(receipt)
    save()
    try:
        binary = Path('/sbin/ldconfig').resolve(strict=True)
        driver = Path('/usr/lib64-nvidia/libcuda.so')
        soname_path = Path('/usr/lib64-nvidia/libcuda.so.1')
        resolved = driver.resolve(strict=True)
        if not resolved.is_relative_to(Path('/usr/lib64-nvidia')) or '/stubs/' in str(resolved):
            raise ValueError('Expected real mounted NVIDIA driver, never CUDA stubs')
        if soname_path.resolve(strict=True) != resolved:
            raise ValueError('Unversioned driver and driver SONAME must resolve to identical real bytes')
        original = subprocess.run([str(binary), '-p'], capture_output=True, text=True, check=True, timeout=15)
        (root / 'system-ldconfig-p.txt').write_text(original.stdout)
        record.update(real_ldconfig=str(binary), real_ldconfig_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                      driver=str(driver), driver_resolved=str(resolved),
                      driver_sha256=hashlib.sha256(resolved.read_bytes()).hexdigest())
        bins = root / 'bin'
        bins.mkdir()
        wrapper = bins / 'ldconfig'
        driver_line = 'libcuda.so.1 (libc6,x86-64) => ' + str(soname_path)
        script = ("#!/bin/sh\n"
                  "if [ \"$#\" -ne 1 ] || [ \"$1\" != \"-p\" ]; then\n"
                  "  printf '%s\\n' 'Task driver discovery supports only ldconfig -p' >&2\n"
                  "  exit 64\n"
                  "fi\n"
                  + shlex.quote(str(binary)) + " -p || exit \"$?\"\n"
                  "printf '%s\\n' " + shlex.quote(driver_line) + "\n")
        wrapper.write_text(script)
        wrapper.chmod(0o755)
        subprocess.run(['/bin/sh', '-n', str(wrapper)], check=True, timeout=10)
        env = dict(os.environ, PATH=str(bins) + os.pathsep + os.environ.get('PATH', ''))
        observed = subprocess.run(['ldconfig', '-p'], env=env, capture_output=True, text=True, check=True, timeout=15)
        (root / 'task-discovery-listing.txt').write_text(observed.stdout)
        if observed.stdout != original.stdout + driver_line + '\n':
            raise ValueError('Wrapper changed real cache output beyond the declared driver supplement')
        for arguments in ([], ['--help'], ['-p', '-X']):
            rejected = subprocess.run([str(wrapper), *arguments], capture_output=True, text=True, timeout=15)
            if rejected.returncode != 64:
                raise ValueError('Task wrapper failed to reject a non-read-only invocation')
        python = task / 'environments/knowcoder-author-py310/bin/python'
        observed_triton = subprocess.run([str(python), '-c',
            'import json; from triton.common.build import libcuda_dirs; print(json.dumps(libcuda_dirs()))'],
            env=dict(env, CUDA_VISIBLE_DEVICES='', PYTHONNOUSERSITE='1'),
            capture_output=True, text=True, check=True, timeout=30)
        (root / 'triton-discovery.stdout').write_text(observed_triton.stdout)
        (root / 'triton-discovery.stderr').write_text(observed_triton.stderr)
        dirs = json.loads(observed_triton.stdout.splitlines()[-1])
        if str(driver.parent) not in dirs:
            raise ValueError('Old Triton did not discover the verified real driver directory')
        record.update(status='ready_cpu_discovery_verified', path_prefix=str(bins),
                      declared_driver_supplement=driver_line, triton_driver_dirs=dirs,
                      wrapper_sha256=hashlib.sha256(wrapper.read_bytes()).hexdigest(),
                      original_listing_sha256=hashlib.sha256(original.stdout.encode()).hexdigest(),
                      supplemented_listing_sha256=hashlib.sha256(observed.stdout.encode()).hexdigest(),
                      wrapper_rejects_unexpected_arguments=True,
                      gpu_kernel_check_pending=True)
    except Exception as error:
        record.update(status='failed', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
    finally:
        record['finished_at'] = time.time()
        save()
    print(json.dumps(record), flush=True)
_jep_stage_triton_driver_discovery_v2_20261028()
del _jep_stage_triton_driver_discovery_v2_20261028

def _jep_historical_import_amendment02_run_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys
    task=Path('/content/jep-native-author-calibration-20261028')
    script=task/'knowcoder-historical-import-amendment02.py'
    assert not (task/'environments/knowcoder-author-setup-amendment02.json').exists(),'Amendment02 exists: inspect before repeating'
    result=subprocess.run([sys.executable,str(script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45,cwd=task)
    print(result.stdout,flush=True)
    print(json.dumps({'import_only_returncode':result.returncode,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}),flush=True)
_jep_historical_import_amendment02_run_20261028()
del _jep_historical_import_amendment02_run_20261028

from pathlib import Path
import json,hashlib,tarfile,subprocess,sys,os
bundle=Path("/content/jep-native-target-diagnostic-bundle-20261028.tar.gz")
expected="f94fbe0943a2e0b1909bc375f646b58cb766d005f43a0c6e555a90ff20dd3714"
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"bundle differs"
activity=subprocess.run(["nvidia-smi","--query-compute-apps=pid,process_name,used_memory","--format=csv,noheader"],capture_output=True,text=True,timeout=10,check=True)
print("gpu_compute_processes",activity.stdout.strip() or "none")
print("gpu_status",subprocess.run(["nvidia-smi","--query-gpu=name,memory.used,memory.total,utilization.gpu","--format=csv,noheader"],capture_output=True,text=True,timeout=10,check=True).stdout.strip())
assert not activity.stdout.strip(),"GPU already has compute processes; preserve other work"
root=Path("/content/jep-native-target-diagnostic-20261028")
receipt=Path("/content/jep-native-target-diagnostic-worker-20261028.json")
assert not receipt.exists(),"Existing worker receipt: inspect before retry"
assert not root.exists(),"Existing execution: inspect before retry"
assert not Path("/content/jep-native-target-diagnostic-results-20261028").exists(),"Existing results: do not repeat"
root.mkdir()
with tarfile.open(bundle) as archive:
    for member in archive.getmembers():
        path=(root/member.name).resolve()
        assert path.is_relative_to(root.resolve()) and not member.issym() and not member.islnk(),"unsafe member"
    archive.extractall(root,filter="data")
assert hashlib.sha256((root/"diagnostic/run_diagnostic.py").read_bytes()).hexdigest()=="469df37f396fddc7213d24b94caea6d4bbb05acf677e328b3aa0bce518f89df9","runner differs"
assert hashlib.sha256((root/"diagnostic/seal.json").read_bytes()).hexdigest()=="d689eb85d6a770ac05005d4ad1df077f0db5d50d7c5359e051bc9057f1a08988","seal differs"
worker=Path("/content/jep-native-target-diagnostic-worker-20261028.py")
worker.write_text("from pathlib import Path\nimport subprocess,sys,json,tarfile,hashlib,io,time\nroot=Path(\"/content/jep-native-target-diagnostic-20261028\")\noutput=Path(\"/content/jep-native-target-diagnostic-results-20261028\")\nprint(json.dumps({\"event\":\"target_diagnostic_started\",\"at\":time.time(),\"cells\":48}),flush=True)\ncommand=[sys.executable,\"diagnostic/run_diagnostic.py\",\"--output\",str(output)]\ntry:\n    result=subprocess.run(command,cwd=root,check=False)\n    receipt={\"returncode\":result.returncode,\"finished_at\":time.time()}\nexcept Exception as exc:\n    receipt={\"error_type\":type(exc).__name__,\"error\":str(exc),\"finished_at\":time.time()}\nPath(\"/content/jep-native-target-diagnostic-completion-20261028.json\").write_text(json.dumps(receipt,indent=2)+\"\\n\")\nartifact=Path(\"/content/jep-native-target-diagnostic-results-20261028.tar.gz\")\nmembers={}\nfor base,prefix in ((root,\"execution\"),(output,\"results\")):\n    if base.exists():\n        for path in base.rglob(\"*\"):\n            if path.is_file():\n                members[prefix+\"/\"+str(path.relative_to(base))]=path\nfor name,arcname in ((\"/content/jep-native-target-diagnostic-worker-20261028.json\",\"worker.json\"),(\"/content/jep-native-target-diagnostic-20261028.log\",\"worker.log\"),(\"/content/jep-native-target-diagnostic-completion-20261028.json\",\"completion.json\")):\n    if Path(name).exists():\n        members[arcname]=Path(name)\nindex={name:{\"bytes\":path.stat().st_size,\"sha256\":hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in members.items()}\nwith tarfile.open(artifact,\"w:gz\") as archive:\n    for name,path in sorted(members.items()):\n        archive.add(path,arcname=name,recursive=False)\n    data=(json.dumps(index,sort_keys=True,indent=2)+\"\\n\").encode()\n    entry=tarfile.TarInfo(\"capture-index.json\");entry.size=len(data)\n    archive.addfile(entry,io.BytesIO(data))\nrecord={**receipt,\"archive\":str(artifact),\"bytes\":artifact.stat().st_size,\"sha256\":hashlib.sha256(artifact.read_bytes()).hexdigest(),\"files\":len(members)}\nPath(\"/content/jep-native-target-diagnostic-archive-20261028.json\").write_text(json.dumps(record,indent=2)+\"\\n\")\nprint(json.dumps({\"event\":\"target_diagnostic_archived\",**record}),flush=True)\n")
with receipt.open("x") as handle:
    json.dump({"status":"prepared","bundle_sha256":expected},handle)
log=Path("/content/jep-native-target-diagnostic-20261028.log")
with log.open("x") as output:
    process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=root,env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1"))
record={"pid":process.pid,"status":"dispatched","bundle_sha256":expected,"log":str(log),"gpu_preflight_no_other_compute":True}
receipt.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))

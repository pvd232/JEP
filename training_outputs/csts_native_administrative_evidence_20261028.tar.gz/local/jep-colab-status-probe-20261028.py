from pathlib import Path
import json, subprocess, re
root = Path("/content/jep-extraction-screen-20261028")
print("root_exists", root.exists())
worker = root / "native-worker.json"
if worker.exists():
    try:
        data = json.loads(worker.read_text())
        allowed = ("pid", "status", "started_at", "finished_at", "arm", "stage", "returncode", "error", "log", "output")
        print("worker", json.dumps({k:v for k,v in data.items() if k in allowed}, ensure_ascii=False))
    except Exception as exc:
        print("worker_read_error", type(exc).__name__)
else:
    print("worker_missing")
log = root / "native-screen.log"
if log.exists():
    lines = log.read_text(errors="replace").splitlines()[-30:]
    safe = [line for line in lines if not re.search(r"token|secret|authorization|bearer|password|credential", line, re.I)]
    print("log_tail", "\n".join(safe))
for arm in ("knowcoder", "gollie"):
    captures = [p for p in root.rglob("result.json") if arm in p.parts]
    valid = 0
    for path in captures:
        try:
            valid += bool(json.loads(path.read_text()).get("valid"))
        except Exception:
            pass
    print("captures", arm, "results", len(captures), "valid", valid)
try:
    res = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.used,memory.total,utilization.gpu", "--format=csv,noheader"], capture_output=True, text=True, timeout=10)
    print("gpu", res.stdout.strip(), "exit", res.returncode)
except Exception as exc:
    print("gpu_probe_error", type(exc).__name__)

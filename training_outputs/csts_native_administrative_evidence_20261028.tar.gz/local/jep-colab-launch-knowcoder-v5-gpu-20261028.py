def _jep_knowcoder_v5_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os,tarfile
    task=Path('/content/jep-native-author-calibration-20261028')
    worker=task/'knowcoder-historical-worker-attempt02.py'
    receipt=task/'knowcoder-legacy-author-attempt02-dispatch.json'
    root=task/'knowcoder-legacy-vllm-v5-execution'
    bundle=Path('/content/jep-knowcoder-legacy-vllm-v5-bundle-20261028.tar.gz')
    assert hashlib.sha256(worker.read_bytes()).hexdigest()=='58a579521f5fbf9e3bf9e09dbe02f340576c952940dbf93b422935f163186ffc','Worker changed'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='ab6edb58ce2d0ce107c65d600b8d96b56dd25beaf50d97cd36a736bac8523931','Knowv5 bundle changed'
    assert not receipt.exists() and not root.exists(),'Knowv5 attempt exists: inspect, do not relaunch'
    assert json.loads((task/'environments/knowcoder-author-setup-amendment02.json').read_text())['status']=='ready_import_verified','Historical import gate not ready'
    go=task/'results/gollie-author-legacy-worker.json'
    assert go.exists() and json.loads(go.read_text())['status'] in ('complete','failed'),'Wait for own Go worker to exit'
    memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
    total,free=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')]
    assert free>=int(total*0.6)+8*1024,'Know needs0.6 total plus8GiB free reserve'
    root.mkdir()
    with tarfile.open(bundle) as archive:archive.extractall(root,filter='data')
    with receipt.open('x') as handle:json.dump({'status':'prepared','worker_sha256':'58a579521f5fbf9e3bf9e09dbe02f340576c952940dbf93b422935f163186ffc'},handle)
    log=task/'logs/knowcoder-legacy-author-attempt02-controller.log'
    with log.open('x') as output:process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'status':'dispatched','pid':process.pid,'worker_sha256':'58a579521f5fbf9e3bf9e09dbe02f340576c952940dbf93b422935f163186ffc','log':str(log),'resource_amendment_gpu_memory_utilization':0.6,'original_captures_and_failed_attempt_unchanged':True}
    receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
_jep_knowcoder_v5_launch_20261028()
del _jep_knowcoder_v5_launch_20261028

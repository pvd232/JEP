from pathlib import Path
import json,hashlib,tarfile,subprocess,sys,os
root=Path("/content/jep-extraction-screen-20261028")
def archive_tree(root, execution_name, artifact, log_name, receipt_name):
    import tarfile,io,hashlib,json
    files=sorted([p for p in (root/execution_name).rglob("*") if p.is_file()],key=str)
    for name in (log_name,receipt_name):
        if (root/name).exists():
            files.append(root/name)
    index={str(p.relative_to(root)):{"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
    with tarfile.open(artifact,"w:gz") as archive:
        for p in files:
            archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
        data=(json.dumps(index,sort_keys=True,indent=2)+"\n").encode()
        entry=tarfile.TarInfo("capture-index.json"); entry.size=len(data)
        archive.addfile(entry,io.BytesIO(data))
    return {"path":str(artifact),"bytes":artifact.stat().st_size,"sha256":hashlib.sha256(artifact.read_bytes()).hexdigest(),"files":len(files)}

old=root/"execution-v3"/"run"
results=list((old/"captures"/"gollie").glob("*/result.json"))
assert len(results)==239,"GoLLIEv3 not complete"
assert '"event": "gollie_v3_completed"' in (root/"gollie-v3.log").read_text(),"GoLLIEworker not complete"
print("gollie_v3_counts",len(results),sum(bool(json.loads(p.read_text()).get("valid")) for p in results))
print("gollie_v3_archive",json.dumps(archive_tree(root,"execution-v3",Path("/content/jep-extraction-gollie-v3-results-20261028.tar.gz"),"gollie-v3.log","gollie-v3-worker.json")))
bundle=root/"knowcoder-v4-bundle.tar.gz"
expected="b1a9bcaac42e0ef03d773da198966066c0b25d7dbab66735637322982542aa61"
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"v4 bundle hash differs"
receipt=root/"knowcoder-v4-worker.json"
assert not receipt.exists(),"Worker receipt exists; inspect before retry"
destination=root/"execution-v4"
assert not destination.exists(),"v4 execution exists; inspect before retry"
destination.mkdir()
with tarfile.open(bundle) as archive:
    for member in archive.getmembers():
        candidate=(destination/member.name).resolve()
        assert candidate.is_relative_to(destination.resolve()) and not member.issym() and not member.islnk(),"unsafe archive member"
    archive.extractall(destination,filter="data")
run=destination/"run"
assert not (run/"captures").exists(),"v4 captures already exist"
protocol_hash=hashlib.sha256((run/"protocol.json").read_bytes()).hexdigest()
assert protocol_hash=="ddc81991dd23713c708e81390849da03e053e4f9685bd3c0767d0d56fef62113","protocol mismatch"
original=root/"execution"/"run"
for name in ("labels.json","sources.json","pairs.json","references.json","references-seal.json"):
    assert (run/name).read_bytes()==(original/name).read_bytes(),"data/ref differs: "+name
worker=root/"run_knowcoder_v4.py"
worker.write_text("from pathlib import Path\nimport sys,time,json,traceback\nsys.path.insert(0,\"/content/jep-extraction-screen-20261028/execution-v4/code\")\nfrom csts_pilot.extraction_comparison import run_arm,verify_run\nroot=Path(\"/content/jep-extraction-screen-20261028\")\nrun=root/\"execution-v4\"/\"run\"\ndef archive_tree(root, execution_name, artifact, log_name, receipt_name):\n    import tarfile,io,hashlib,json\n    files=sorted([p for p in (root/execution_name).rglob(\"*\") if p.is_file()],key=str)\n    for name in (log_name,receipt_name):\n        if (root/name).exists():\n            files.append(root/name)\n    index={str(p.relative_to(root)):{\"bytes\":p.stat().st_size,\"sha256\":hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}\n    with tarfile.open(artifact,\"w:gz\") as archive:\n        for p in files:\n            archive.add(p,arcname=str(p.relative_to(root)),recursive=False)\n        data=(json.dumps(index,sort_keys=True,indent=2)+\"\\n\").encode()\n        entry=tarfile.TarInfo(\"capture-index.json\"); entry.size=len(data)\n        archive.addfile(entry,io.BytesIO(data))\n    return {\"path\":str(artifact),\"bytes\":artifact.stat().st_size,\"sha256\":hashlib.sha256(artifact.read_bytes()).hexdigest(),\"files\":len(files)}\n\nprint(json.dumps({\"event\":\"knowcoder_v4_started\",\"at\":time.time()}),flush=True)\ntry:\n    verify_run(run)\n    result=run_arm(run,\"knowcoder\",cli=\"unused\",execute=True,device=\"cuda\")\n    print(json.dumps({\"event\":\"knowcoder_v4_completed\",\"result\":result,\"at\":time.time()}),flush=True)\nexcept Exception as exc:\n    print(json.dumps({\"event\":\"knowcoder_v4_failed\",\"error_type\":type(exc).__name__,\"error\":str(exc),\"at\":time.time()}),flush=True)\n    traceback.print_exc()\nfinally:\n    artifact=Path(\"/content/jep-extraction-knowcoder-v4-results-20261028.tar.gz\")\n    record=archive_tree(root,\"execution-v4\",artifact,\"knowcoder-v4.log\",\"knowcoder-v4-worker.json\")\n    (root/\"knowcoder-v4-archive.json\").write_text(json.dumps(record,indent=2)+\"\\n\")\n    print(json.dumps({\"event\":\"knowcoder_v4_archived\",**record}),flush=True)\n")
with receipt.open("x") as handle:
    json.dump({"status":"prepared","bundle_sha256":expected,"protocol_sha256":protocol_hash},handle)
log=root/"knowcoder-v4.log"
with log.open("x") as output:
    process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=root,env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1"))
record={"pid":process.pid,"log":str(log),"bundle_sha256":expected,"protocol_sha256":protocol_hash,"status":"dispatched"}
receipt.write_text(json.dumps(record,indent=2)+"\n")
print("knowcoder_v4_dispatch",json.dumps(record))

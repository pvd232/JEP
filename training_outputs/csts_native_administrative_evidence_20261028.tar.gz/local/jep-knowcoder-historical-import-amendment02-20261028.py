"""Import-only gate: record wheel metadata/module labels before exact validation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
RECEIPT=TASK/'environments/knowcoder-author-setup-amendment02.json'
LOG=TASK/'logs/knowcoder-author-setup-amendment02.log'
ARCHIVE=TASK/'results/knowcoder-author-setup-amendment02-artifacts.tar.gz'
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def main():
    if any(path.exists() for path in [RECEIPT,LOG,ARCHIVE]):raise ValueError('Import-only amendment02 exists; inspect rather than repeat')
    previous=TASK/'environments/knowcoder-author-setup-amendment01.json'
    if json.loads(previous.read_text())['status']!='failed':raise ValueError('Expected preserved amendment01 label-gate failure')
    record={'status':'started','started_at':time.time(),'environment':str(ENV),'previous_receipt_sha256':hashlib.sha256(previous.read_bytes()).hexdigest(),'packages_installed':False,'shared_packages_modified':False,'model_calls':False,'amendment':'Observe actual installed distribution/module versions before validation; exact observed bare Flash2.3.4 metadata'}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='')
    runtime.pop('PYTHONPATH',None)
    code="""import json,sys,sysconfig,importlib,importlib.metadata as m
from pathlib import Path
assert sys.version_info[:2]==(3,10)
assert Path(sys.prefix).resolve()==Path('/content/jep-native-author-calibration-20261028/environments/knowcoder-author-py310').resolve()
assert Path(sysconfig.get_paths()['purelib']).is_relative_to(Path(sys.prefix))
import torch,transformers,tokenizers,xformers,ray,vllm,flash_attn,accelerate,pkg_resources
from flash_attn.layers.rotary import apply_rotary_emb_func
from flash_attn.flash_attn_interface import flash_attn_kvpacked_func,flash_attn_varlen_kvpacked_func
import flash_attn_2_cuda
from transformers import PreTrainedModel
from transformers.generation import GenerationMixin
expected={'torch':'2.1.0+cu118','transformers':'4.34.1','tokenizers':'0.14.1','vllm':'0.2.2+cu118','flash-attn':'2.3.4','accelerate':'0.23.0','setuptools':'68.0.0'}
actual={k:m.version(k) for k in expected}
modules=sorted(path.name.split('.')[0] for path in Path(vllm.__file__).parent.glob('*.so'))
observed={'packages':actual,'flash_module_version':flash_attn.__version__,'torch_cuda':torch.version.cuda,'torch_cxx11_abi':torch._C._GLIBCXX_USE_CXX11_ABI,'prefix':sys.prefix,'purelib':sysconfig.get_paths()['purelib'],'observed_vllm_compiled_modules':modules,'ray_import':True,'pkg_resources_import':True,'flash_rotary_import':True,'flash_cuda_extension_import':True}
print('OBSERVED '+json.dumps(observed),flush=True)
assert actual==expected,(actual,expected)
assert torch._C._GLIBCXX_USE_CXX11_ABI is False
assert issubclass(PreTrainedModel,GenerationMixin)
assert {'attention_ops','cache_ops','pos_encoding_ops','layernorm_ops','activation_ops'}.issubset(modules),modules
for name in modules:importlib.import_module('vllm.'+name)
observed.update(vllm_compiled_modules_imported=modules,cuda_device_count_hidden=torch.cuda.device_count())
print('READY '+json.dumps(observed),flush=True)
"""
    command=[str(ENV/'bin/python'),'-c',code]
    try:
        with LOG.open('x') as log:
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=runtime,cwd=TASK,text=True,timeout=180)
            log.write(result.stdout)
        record['returncode']=result.returncode
        for line in result.stdout.splitlines():
            if line.startswith('OBSERVED '):record['observations']=json.loads(line[len('OBSERVED '):])
            if line.startswith('READY '):record['imports']=json.loads(line[len('READY '):])
        if result.returncode:raise RuntimeError('Import-only gate failed; actual observations and complete log retained')
        if 'imports' not in record:raise ValueError('No completed import attestation')
        record.update(status='ready_import_verified',gpu_kernel_smoke_pending=True)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest() if LOG.exists() else None);write(RECEIPT,record)
        with tarfile.open(ARCHIVE,'w:gz') as archive:
            for path in [RECEIPT,LOG,Path(__file__),TASK/'environments/knowcoder-author-setup.json',previous,TASK/'logs/knowcoder-author-setup.log',TASK/'logs/knowcoder-author-setup-amendment01.log']:
                if path.is_file():archive.add(path,arcname=str(path.relative_to(TASK)))
        write(TASK/'results/knowcoder-author-setup-amendment02-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status']})
        print(json.dumps(record),flush=True)
    if record['status']!='ready_import_verified':sys.exit(1)
if __name__=='__main__':main()

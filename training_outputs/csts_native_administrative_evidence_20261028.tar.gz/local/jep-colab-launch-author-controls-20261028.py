from pathlib import Path
import json,hashlib,tarfile,subprocess,sys,os
bundle=Path("/content/jep-native-author-controls-bundle-20261028.tar.gz")
expected="bdaf995e6adc92423699c5deff294931bec8127e4b6af891eb389eafde04f35b"
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"bundle differs"
root=Path("/content/jep-native-author-controls-20261028")
receipt=Path("/content/jep-author-controls-worker-20261028.json")
assert not receipt.exists(),"Existing worker receipt: inspect before retry"
assert not root.exists(),"Existing execution: inspect before retry"
assert not Path("/content/jep-author-controls-results-20261028").exists(),"Existing results: do not repeat"
root.mkdir()
with tarfile.open(bundle) as archive:
    for member in archive.getmembers():
        path=(root/member.name).resolve()
        assert path.is_relative_to(root.resolve()) and not member.issym() and not member.islnk(),"unsafe member"
    archive.extractall(root,filter="data")
worker=Path("/content/jep-native-author-controls-worker-20261028.py")
worker.write_text("from pathlib import Path\nimport subprocess,sys,json,tarfile,hashlib,io,time\nroot=Path(\"/content/jep-native-author-controls-20261028\")\noutput=Path(\"/content/jep-author-controls-results-20261028\")\ncommand=[sys.executable,\"controls/run_author_controls.py\",\"--code\",\"code\",\"--output\",str(output)]\nprint(json.dumps({\"event\":\"author_controls_started\",\"at\":time.time()}),flush=True)\ntry:\n    result=subprocess.run(command,cwd=root,check=False)\n    receipt={\"returncode\":result.returncode,\"finished_at\":time.time()}\nexcept Exception as exc:\n    receipt={\"error_type\":type(exc).__name__,\"error\":str(exc),\"finished_at\":time.time()}\nPath(\"/content/jep-author-controls-completion-20261028.json\").write_text(json.dumps(receipt,indent=2)+\"\\n\")\nartifact=Path(\"/content/jep-author-controls-results-20261028.tar.gz\")\nmembers={}\nfor base,prefix in ((root,\"execution\"),(output,\"results\")):\n    if base.exists():\n        for path in base.rglob(\"*\"):\n            if path.is_file():\n                members[prefix+\"/\"+str(path.relative_to(base))]=path\nfor name,arcname in ((\"/content/jep-author-controls-worker-20261028.json\",\"worker.json\"),(\"/content/jep-author-controls-20261028.log\",\"worker.log\"),(\"/content/jep-author-controls-completion-20261028.json\",\"completion.json\")):\n    if Path(name).exists():\n        members[arcname]=Path(name)\nindex={name:{\"bytes\":path.stat().st_size,\"sha256\":hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in members.items()}\nwith tarfile.open(artifact,\"w:gz\") as archive:\n    for name,path in sorted(members.items()):\n        archive.add(path,arcname=name,recursive=False)\n    data=(json.dumps(index,sort_keys=True,indent=2)+\"\\n\").encode()\n    entry=tarfile.TarInfo(\"capture-index.json\");entry.size=len(data)\n    archive.addfile(entry,io.BytesIO(data))\nrecord={**receipt,\"archive\":str(artifact),\"bytes\":artifact.stat().st_size,\"sha256\":hashlib.sha256(artifact.read_bytes()).hexdigest(),\"files\":len(members)}\nPath(\"/content/jep-author-controls-archive-20261028.json\").write_text(json.dumps(record,indent=2)+\"\\n\")\nprint(json.dumps({\"event\":\"author_controls_archived\",**record}),flush=True)\n")
with receipt.open("x") as handle:
    json.dump({"status":"prepared","bundle_sha256":expected},handle)
log=Path("/content/jep-author-controls-20261028.log")
with log.open("x") as output:
    process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=root,env=dict(os.environ,HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1"))
record={"pid":process.pid,"status":"dispatched","bundle_sha256":expected,"log":str(log)}
receipt.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))

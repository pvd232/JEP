def _jep_historical_import_amendment01_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os
    task=Path('/content/jep-native-author-calibration-20261028')
    script=task/'knowcoder-historical-import-amendment01.py'
    worker=task/'knowcoder-author-setup-amendment01-worker.json'
    assert hashlib.sha256(script.read_bytes()).hexdigest()=='5479d76e57e1bd285e67475a06cd764ac6c4a66b0aab09fa34a012ad6d4bd59e','Amendment source changed'
    assert not worker.exists(),'Amendment worker exists: inspect, do not relaunch'
    assert not (task/'environments/knowcoder-author-setup-amendment01.json').exists(),'Amendment receipt exists'
    assert json.loads((task/'environments/knowcoder-author-setup.json').read_text())['status']=='failed','Initial setup failure must remain preserved'
    with worker.open('x') as handle:json.dump({'status':'prepared','script_sha256':'5479d76e57e1bd285e67475a06cd764ac6c4a66b0aab09fa34a012ad6d4bd59e'},handle)
    log=task/'logs/knowcoder-author-import-amendment01-controller.log'
    with log.open('x') as output:process=subprocess.Popen([sys.executable,str(script)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'pid':process.pid,'status':'dispatched','script_sha256':'5479d76e57e1bd285e67475a06cd764ac6c4a66b0aab09fa34a012ad6d4bd59e','log':str(log),'cpu_only':True,'model_calls':False,'core_wheels_reinstalled':False}
    worker.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
_jep_historical_import_amendment01_launch_20261028()
del _jep_historical_import_amendment01_launch_20261028

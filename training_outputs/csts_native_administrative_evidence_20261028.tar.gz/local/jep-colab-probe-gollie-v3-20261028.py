from pathlib import Path
import json,subprocess
root=Path('/content/jep-extraction-screen-20261028')
receipt=root/'gollie-v3-worker.json'
print('v3_execution_exists',(root/'execution-v3').exists())
print('v3_receipt',receipt.read_text() if receipt.exists() else 'absent')
log=root/'gollie-v3.log'
print('v3_log_tail','\n'.join(log.read_text(errors='replace').splitlines()[-20:]) if log.exists() else 'absent')
results=list((root/'execution-v3'/'run'/'captures'/'gollie').glob('*/result.json'))
print('gollie_v3_results',len(results),'valid',sum(bool(json.loads(p.read_text()).get('valid')) for p in results))
print('gpu',subprocess.run(['nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader'],capture_output=True,text=True,timeout=10).stdout.strip())

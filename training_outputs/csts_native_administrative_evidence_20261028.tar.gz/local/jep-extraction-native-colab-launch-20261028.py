from pathlib import Path
import tarfile, subprocess, sys, json, hashlib
root=Path('/content/jep-extraction-screen-20261028')
workspace=root/'execution'
workspace.mkdir(exist_ok=True)
with tarfile.open(root/'execution.tar.gz') as archive:
    archive.extractall(workspace, filter='data')
worker=root/'run_native_screen.py'
worker.write_text('''from pathlib import Path
import sys,time,json,gc,traceback
root=Path("/content/jep-extraction-screen-20261028")
sys.path.insert(0,str(root/"execution/repository"))
from csts_pilot.extraction_comparison import run_arm,verify_run
import torch
run=root/"execution/run"
verify_run(run)
for arm in ("knowcoder","gollie"):
    started=time.monotonic()
    print(json.dumps({"event":"arm_started","arm":arm,"at":time.time()}),flush=True)
    try:
        result=run_arm(run,arm,cli="unused",execute=True,device="cuda")
        files=list((run/"captures"/arm).glob("*/result.json"))
        results=[json.loads(p.read_text()) for p in files]
        print(json.dumps({"event":"arm_completed","arm":arm,"complete":len(results),"valid":sum(v["valid"] for v in results),"elapsed_seconds":time.monotonic()-started}),flush=True)
    except Exception as error:
        print(json.dumps({"event":"arm_failed","arm":arm,"error_type":type(error).__name__,"error":str(error)}),flush=True)
        traceback.print_exc()
    gc.collect()
    torch.cuda.empty_cache()
print(json.dumps({"event":"native_screen_finished","at":time.time()}),flush=True)
''')
log=(root/'native-screen.log').open('a')
environment=dict(__import__('os').environ)
environment['HF_HUB_OFFLINE']='1'
environment['TOKENIZERS_PARALLELISM']='false'
process=subprocess.Popen([sys.executable,str(worker)],stdout=log,stderr=subprocess.STDOUT,env=environment,start_new_session=True)
receipt={'pid':process.pid,'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'log':str(root/'native-screen.log')}
(root/'native-worker.json').write_text(json.dumps(receipt))
print(json.dumps(receipt))

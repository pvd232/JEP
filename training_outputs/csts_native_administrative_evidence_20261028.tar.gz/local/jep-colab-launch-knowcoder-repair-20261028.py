def _jep_knowcoder_repair_launch_20261028():
    from pathlib import Path
    import json,hashlib,tarfile,subprocess,sys,os,shutil
    task=Path("/content/jep-native-author-calibration-20261028")
    bundle=Path("/content/jep-knowcoder-repair-bundle-20261028.tar.gz")
    expected="577a6917c5720500dab609faef0ae6d2c77431d9bbd4ef3fa0aabbc36e31e4f4"
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"bundle differs"
    assert task.exists(),"Task root missing"
    assert shutil.disk_usage(task).free>=36_000_000_000,"Insufficient disk"
    activity=subprocess.run(["nvidia-smi","--query-compute-apps=pid,process_name,used_memory","--format=csv,noheader"],capture_output=True,text=True,timeout=15,check=True)
    assert not activity.stdout.strip(),"GPU occupied; preserve other work"
    compiler={"python":sys.version,"python_executable":sys.executable,"cuda_home_env":os.environ.get("CUDA_HOME"),"cuda_paths":[str(p) for p in Path("/usr/local").glob("cuda*")],"gpu_compute_processes":activity.stdout.strip(),"disk_free":shutil.disk_usage(task).free}
    for name in ("nvcc","gcc","uv","python3.12"):
        compiler[name]={"path":shutil.which(name)}
        if shutil.which(name):
            result=subprocess.run([name,"--version"],capture_output=True,text=True,timeout=15)
            compiler[name].update(returncode=result.returncode,version=(result.stdout+result.stderr).strip()[:1800])
    import torch
    try:
        from torch.utils.cpp_extension import CUDA_HOME
    except Exception as error:
        CUDA_HOME=None
        compiler["cpp_extension_import_error_type"]=type(error).__name__
    compiler.update(torch_version=torch.__version__,torch_cuda=torch.version.cuda,torch_cxx11_abi=bool(torch._C._GLIBCXX_USE_CXX11_ABI),torch_extension_cuda_home=CUDA_HOME)
    (task/"results/compiler-preflight.json").write_text(json.dumps(compiler,indent=2)+"\n")
    print("compiler_preflight",json.dumps(compiler),flush=True)
    receipt=task/"knowcoder-repair-worker.json"
    execution=task/"knowcoder-repair-execution"
    assert not receipt.exists() and not execution.exists(),"Existing worker or execution; inspect before retry"
    assert not (task/"results/knowcoder-repair-canaries").exists(),"Existing canary outputs; do not repeat"
    execution.mkdir()
    with tarfile.open(bundle) as archive:
        for member in archive.getmembers():
            path=(execution/member.name).resolve()
            assert path.is_relative_to(execution.resolve()) and not member.issym() and not member.islnk(),"unsafe member"
        archive.extractall(execution,filter="data")
    code=execution/"knowcoder-repair"
    seal=json.loads((code/"seal.json").read_text())
    for name,hash_value in seal["files"].items():
        assert hashlib.sha256((code/name).read_bytes()).hexdigest()==hash_value,"sealed source differs: "+name
    cache=task/"checkpoints/knowcoder"
    cache.mkdir(exist_ok=True)
    from huggingface_hub import constants
    original=Path(constants.HF_HUB_CACHE)/"models--golaxy--KnowCoder-7B-base"/"snapshots/4a7a076f573fe87fe0a97670c63c64214484742f"
    seed=cache/"models--golaxy--KnowCoder-7B-base"/"snapshots/4a7a076f573fe87fe0a97670c63c64214484742f"
    reused=[]
    if original.exists():
        seed.mkdir(parents=True,exist_ok=False)
        for path in original.iterdir():
            if path.is_file():
                (seed/path.name).symlink_to(path.resolve())
                reused.append(path.name)
    (task/"results/base-cache-reuse.json").write_text(json.dumps({"source":str(original),"destination":str(seed),"reused_files":reused,"original_files_modified":False},indent=2)+"\n")
    worker=task/"run_knowcoder_repair.py"
    worker.write_text("from pathlib import Path\nimport subprocess,sys,json,tarfile,hashlib,io,time,os\ntask=Path(\"/content/jep-native-author-calibration-20261028\")\nexecution=task/\"knowcoder-repair-execution\"\ncode=execution/\"knowcoder-repair\"\ncache=task/\"checkpoints/knowcoder\"\noutput=task/\"results/knowcoder-repair-canaries\"\ndownload_record=task/\"results/knowcoder-download.json\"\nprint(json.dumps({\"event\":\"knowcoder_repair_started\",\"at\":time.time()}),flush=True)\nrecord={\"started_at\":time.time(),\"stages\":[]}\ntry:\n    command=[sys.executable,str(code/\"download.py\"),\"--cache-dir\",str(cache),\"--record\",str(download_record)]\n    downloaded=subprocess.run(command,cwd=execution,check=False,env=dict(os.environ,HF_HUB_OFFLINE=\"0\",TRANSFORMERS_OFFLINE=\"0\"))\n    record[\"stages\"].append({\"stage\":\"download\",\"returncode\":downloaded.returncode})\n    if downloaded.returncode==0:\n        command=[sys.executable,str(code/\"run_repair.py\"),\"--cache-dir\",str(cache),\"--output\",str(output)]\n        generated=subprocess.run(command,cwd=execution,check=False,env=dict(os.environ,HF_HUB_OFFLINE=\"1\",TRANSFORMERS_OFFLINE=\"1\"))\n        record[\"stages\"].append({\"stage\":\"calibration\",\"returncode\":generated.returncode})\n    record[\"returncode\"]=record[\"stages\"][-1][\"returncode\"]\nexcept Exception as exc:\n    record.update(error_type=type(exc).__name__,error=str(exc))\nrecord[\"finished_at\"]=time.time()\ncompletion=task/\"results/knowcoder-repair-completion.json\"\ncompletion.write_text(json.dumps(record,indent=2)+\"\\n\")\nmembers={}\nfor base,prefix in ((execution,\"execution\"),(output,\"results/knowcoder-repair-canaries\")):\n    if base.exists():\n        for path in base.rglob(\"*\"):\n            if path.is_file():\n                members[prefix+\"/\"+str(path.relative_to(base))]=path\nfor path,arcname in ((download_record,\"results/knowcoder-download.json\"),(completion,\"completion.json\"),(task/\"logs/knowcoder-repair.log\",\"worker.log\"),(task/\"knowcoder-repair-worker.json\",\"worker.json\"),(task/\"results/compiler-preflight.json\",\"compiler-preflight.json\"),(task/\"results/base-cache-reuse.json\",\"base-cache-reuse.json\")):\n    if path.exists():\n        members[arcname]=path\nindex={name:{\"bytes\":path.stat().st_size,\"sha256\":hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in members.items()}\nartifact=Path(\"/content/jep-knowcoder-repair-results-20261028.tar.gz\")\nwith tarfile.open(artifact,\"w:gz\") as archive:\n    for name,path in sorted(members.items()):\n        archive.add(path,arcname=name,recursive=False)\n    data=(json.dumps(index,sort_keys=True,indent=2)+\"\\n\").encode()\n    entry=tarfile.TarInfo(\"capture-index.json\");entry.size=len(data)\n    archive.addfile(entry,io.BytesIO(data))\nsummary={**record,\"archive\":str(artifact),\"bytes\":artifact.stat().st_size,\"sha256\":hashlib.sha256(artifact.read_bytes()).hexdigest(),\"files\":len(members)}\n(task/\"results/knowcoder-repair-archive.json\").write_text(json.dumps(summary,indent=2)+\"\\n\")\nprint(json.dumps({\"event\":\"knowcoder_repair_archived\",**summary}),flush=True)\n")
    with receipt.open("x") as handle:
        json.dump({"status":"prepared","bundle_sha256":expected},handle)
    log=task/"logs/knowcoder-repair.log"
    with log.open("x") as output:
        process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=execution,env=dict(os.environ))
    record={"pid":process.pid,"status":"dispatched","bundle_sha256":expected,"log":str(log),"cache_dir":str(cache),"base_cache_reused_files":len(reused)}
    receipt.write_text(json.dumps(record,indent=2)+"\n")
    print("knowcoder_repair_dispatch",json.dumps(record),flush=True)

_jep_knowcoder_repair_launch_20261028()
del _jep_knowcoder_repair_launch_20261028

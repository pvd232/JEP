def _jep_one_shot_progress_readonly_20261028():
    from pathlib import Path
    import json,subprocess
    task=Path('/content/jep-native-author-calibration-20261028');record={}
    for model in ['knowcoder_ie','gollie']:
        receipt=task/('results/native-one-shot-v1-'+model+'-worker.json');log=task/('logs/native-one-shot-v1-'+model+'.log');root=task/('results/native-one-shot-v1-'+model)
        row={'receipt_exists':receipt.exists()}
        if receipt.exists():
            value=json.loads(receipt.read_text());row['worker']={k:v for k,v in value.items() if k in ['status','phase','started_at','finished_at','model','development_cases','reference_companions','output_token_cap','prompt_profile','gpu_scheduling','returncode','completion','error_type','error']}
        if log.exists():row['log_tail']=log.read_text(errors='replace')[-1400:]
        if root.exists():
            row['generation_files']=len(list(root.glob('*-generation.json')));row['result_files']=len(list(root.glob('*-result.json')))
            if (root/'complete.json').exists():row['complete']=json.loads((root/'complete.json').read_text())
        archive=task/('results/native-one-shot-v1-'+model+'-execution-archive.json')
        if archive.exists():row['archive']=json.loads(archive.read_text())
        record[model]=row
    gpu=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20)
    processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20)
    record['gpu']={'total_free_utilization':gpu.stdout,'compute_processes':processes.stdout}
    print(json.dumps(record),flush=True)
_jep_one_shot_progress_readonly_20261028()
del _jep_one_shot_progress_readonly_20261028

"""Per-process Colab compatibility wrapper; preserve existing runtimes and TLS verification."""
import os
import sys
import urllib.parse
import certifi

# requests already uses certifi; websocket-client's default SSL context needs it too.
os.environ["SSL_CERT_FILE"] = certifi.where()

import websocket
_original_ws_init = websocket.WebSocketApp.__init__

def _colab_websocket_init(self, url, *args, **kwargs):
    headers = kwargs.get("header") or {}
    if isinstance(headers, dict):
        token = headers.get("X-Colab-Runtime-Proxy-Token")
        if token:
            parts = urllib.parse.urlsplit(url)
            params = urllib.parse.parse_qs(parts.query, keep_blank_values=True)
            params["colab-runtime-proxy-token"] = [token]
            url = urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path,
                                         urllib.parse.urlencode(params, doseq=True), parts.fragment))
    return _original_ws_init(self, url, *args, **kwargs)

websocket.WebSocketApp.__init__ = _colab_websocket_init

from colab_cli.state import StateStore
from colab_cli.runtime import ColabRuntime
_target = StateStore().get("jep-full-propositions-20261027")
if _target is None:
    raise SystemExit("Expected existing session is unavailable; no runtime created.")
_existing_kernel = "a4549495-395c-494c-9c2f-921495336eb9"
_original_runtime_init = ColabRuntime.__init__

def _attach_existing_runtime(self, url, token, *args, **kwargs):
    if url == _target.url:
        kwargs["kernel_id"] = _existing_kernel
        kwargs["session_id"] = None
        # Suppress callback writes; preserve local IDs and all remote kernel state.
        kwargs["on_kernel_started"] = None
        kwargs["on_session_started"] = None
    return _original_runtime_init(self, url, token, *args, **kwargs)

ColabRuntime.__init__ = _attach_existing_runtime

if __name__ == "__main__":
    from colab_cli.cli import main
    try:
        main()
    except Exception as error:
        # URLs can contain proxy credentials; avoid dumping exception representations.
        print("Colab wrapper failure: " + type(error).__name__, file=sys.stderr)
        raise SystemExit(1)

def _jep_knowcoder_legacy_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os,tarfile
    task=Path('/content/jep-native-author-calibration-20261028')
    worker=task/'knowcoder-historical-worker.py'
    receipt=task/'knowcoder-legacy-author-dispatch.json'
    assert hashlib.sha256(worker.read_bytes()).hexdigest()=='29b1d2ca76e354bd841737cf12b8018454f808a214bc10efb768a3b0d4be6d2d','Worker changed'
    assert not receipt.exists(),'Dispatch receipt exists: inspect, do not relaunch'
    assert json.loads((task/'environments/knowcoder-author-setup-amendment02.json').read_text())['status']=='ready_import_verified','Historical imports/version gate not ready'
    gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
    assert not gpu.stdout.strip(),'GPU occupied: preserve existing process'
    with receipt.open('x') as handle:json.dump({'status':'prepared','worker_sha256':'29b1d2ca76e354bd841737cf12b8018454f808a214bc10efb768a3b0d4be6d2d'},handle)
    log=task/'logs'/'knowcoder-legacy-author-controller.log'
    with log.open('x') as output:
        process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'status':'dispatched','pid':process.pid,'worker_sha256':'29b1d2ca76e354bd841737cf12b8018454f808a214bc10efb768a3b0d4be6d2d','log':str(log),'original_captures_unchanged':True}
    receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
_jep_knowcoder_legacy_launch_20261028()
del _jep_knowcoder_legacy_launch_20261028

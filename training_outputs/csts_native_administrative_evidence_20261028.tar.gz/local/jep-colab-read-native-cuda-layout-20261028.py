def _jep_read_cuda_layout_20261028():
    from pathlib import Path
    import json, subprocess
    source = Path('/content/jep-native-author-calibration-20261028/environments/knowcoder-author-py310/lib/python3.10/site-packages/triton/common/build.py')
    result = {'triton_discovery_source': source.read_text()[:10000]}
    result['driver_paths'] = []
    for root in ['/usr/lib64-nvidia', '/usr/lib/x86_64-linux-gnu', '/usr/local/cuda/compat']:
        for path in sorted(Path(root).glob('libcuda.so*')):
            result['driver_paths'].append({'path': str(path), 'resolved': str(path.resolve()), 'bytes': path.stat().st_size})
    ld = subprocess.run(['/sbin/ldconfig', '-p'], capture_output=True, text=True, timeout=10)
    result['ldconfig_cuda'] = [line for line in ld.stdout.splitlines() if 'libcuda.so' in line]
    print(json.dumps(result), flush=True)
_jep_read_cuda_layout_20261028()
del _jep_read_cuda_layout_20261028

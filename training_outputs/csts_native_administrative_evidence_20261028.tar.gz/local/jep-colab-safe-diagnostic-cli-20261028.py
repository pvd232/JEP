"""Same compatibility wrapper, with credential-redacted error type/message chain."""
import runpy,re,sys,urllib.parse,json
scope=runpy.run_path('/tmp/jep-colab-safe-cli-20261028.py',run_name='jep_compatibility_import')
from colab_cli.cli import main
session=scope['_target']
def redact(value):
    text=str(value)
    for secret in (session.token,session.url,urllib.parse.quote(session.token,safe=''),urllib.parse.quote_plus(session.token)):
        if secret:text=text.replace(secret,'[REDACTED]')
    text=re.sub(r'(?:https?|wss?)://[^\s\x27\x22<>]+','[URL REDACTED]',text)
    return text[:6000]
try:main()
except Exception as error:
    chain=[];seen=set();current=error
    while current is not None and id(current) not in seen:
        seen.add(id(current));chain.append({'type':type(current).__name__,'message':redact(current)})
        current=current.__cause__ or current.__context__
    print(json.dumps({'safe_error_chain':chain}),file=sys.stderr)
    raise SystemExit(1)

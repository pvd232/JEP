"""Isolated historical author environment; CPU setup and binary imports only."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
MANAGED=TASK/'environments/managed-python'
RECEIPT=TASK/'environments/knowcoder-author-setup.json'
LOG=TASK/'logs/knowcoder-author-setup.log'
ARCHIVE=TASK/'results/knowcoder-author-setup-artifacts.tar.gz'
ARTIFACTS=TASK/'results/knowcoder-author-environment'
PINS=[
 'https://download.pytorch.org/whl/cu118/torch-2.1.0%2Bcu118-cp310-cp310-linux_x86_64.whl#sha256=a81b554184492005543ddc32e96469f9369d778dedd195d73bda9bed407d6589',
 'https://download.pytorch.org/whl/cu118/xformers-0.0.22.post7%2Bcu118-cp310-cp310-manylinux2014_x86_64.whl#sha256=06377ae0e94f9b4fe99e08663dbf3d0d133535d7648e050e435f881facc3b34d',
 'https://github.com/vllm-project/vllm/releases/download/v0.2.2/vllm-0.2.2%2Bcu118-cp310-cp310-manylinux1_x86_64.whl',
 'https://github.com/Dao-AILab/flash-attention/releases/download/v2.3.4/flash_attn-2.3.4%2Bcu118torch2.1cxx11abiFALSE-cp310-cp310-linux_x86_64.whl',
 'transformers==4.34.1','tokenizers==0.14.1','huggingface-hub==0.17.3',
 'numpy==1.25.2','ray==2.8.1','pyarrow==14.0.1','pandas==2.1.3',
 'sentencepiece==0.1.99','einops==0.7.0','psutil==5.9.6','ninja==1.11.1.1',
 'pydantic==1.10.13','fastapi==0.104.1','uvicorn==0.24.0.post1','protobuf==4.25.1',
 'accelerate==0.23.0',
]

def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2)+'\n')
    tmp.replace(path)

def main():
    if RECEIPT.exists() or LOG.exists() or ENV.exists() or ARTIFACTS.exists() or ARCHIVE.exists():
        raise ValueError('Historical setup attempt exists; inspect it, do not retry blindly')
    ARTIFACTS.mkdir(parents=True)
    runtime=dict(os.environ,UV_PYTHON_INSTALL_DIR=str(MANAGED),UV_CACHE_DIR=str(TASK/'cache/uv'),PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='',UV_NO_PROGRESS='1')
    runtime.pop('PYTHONPATH',None)
    record={'status':'started','started_at':time.time(),'environment':str(ENV),'managed_python_root':str(MANAGED),'pins':PINS,'shared_packages_modified':False,'model_calls':False,'cuda_hidden_for_setup':True,'commands':[]}
    with RECEIPT.open('x') as handle: json.dump(record,handle,indent=2)
    with LOG.open('x') as log:
        def command(args,timeout=1800):
            print('COMMAND '+json.dumps(args),file=log,flush=True)
            result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=runtime,cwd=TASK,text=True,timeout=timeout)
            log.write(result.stdout);log.flush()
            record['commands'].append({'argv':args,'returncode':result.returncode})
            write(RECEIPT,record)
            if result.returncode: raise RuntimeError('Historical environment command failed; retained log, exit='+str(result.returncode))
            return result.stdout
        try:
            command(['uv','python','install','3.10'],900)
            managed=command(['uv','python','find','--managed-python','3.10'],60).strip()
            if not Path(managed).resolve().is_relative_to(MANAGED.resolve()):
                raise ValueError('Managed interpreter escaped task-owned root')
            command(['uv','venv','--python',managed,str(ENV)],120)
            python=str(ENV/'bin/python')
            probe="import sys,sysconfig,json;from pathlib import Path;assert sys.version_info[:2]==(3,10);assert Path(sys.prefix).resolve()==Path("+repr(str(ENV))+").resolve();p=Path(sysconfig.get_paths()['purelib']);assert p.is_relative_to(Path(sys.prefix));print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'purelib':str(p),'version':sys.version}))"
            record['interpreter']=json.loads(command([python,'-c',probe],30))
            write(RECEIPT,record)
            command(['uv','pip','install','--python',python]+PINS,1800)
            check=command(['uv','pip','check','--python',python],120)
            (ARTIFACTS/'uv-pip-check.txt').write_text(check)
            freeze=command(['uv','pip','freeze','--python',python],120)
            (ARTIFACTS/'resolved-requirements.txt').write_text(freeze)
            code="""import json,sys,sysconfig,importlib.metadata as m
import torch,transformers,tokenizers,xformers,vllm,vllm._C,flash_attn,accelerate
from flash_attn.layers.rotary import apply_rotary_emb_func
from flash_attn.flash_attn_interface import flash_attn_kvpacked_func,flash_attn_varlen_kvpacked_func
from transformers import PreTrainedModel
from transformers.generation import GenerationMixin
expected={'torch':'2.1.0+cu118','transformers':'4.34.1','tokenizers':'0.14.1','vllm':'0.2.2+cu118','flash-attn':'2.3.4','accelerate':'0.23.0'}
actual={k:m.version(k) for k in expected}
assert actual==expected,(actual,expected)
assert torch._C._GLIBCXX_USE_CXX11_ABI is False
assert issubclass(PreTrainedModel,GenerationMixin)
print(json.dumps({'packages':actual,'torch_cuda':torch.version.cuda,'torch_cxx11_abi':torch._C._GLIBCXX_USE_CXX11_ABI,'prefix':sys.prefix,'purelib':sysconfig.get_paths()['purelib'],'vllm_C_import':True,'flash_rotary_import':True,'flash_kernel_import':True,'cuda_device_count_hidden':torch.cuda.device_count()}))
"""
            record['imports']=json.loads(command([python,'-c',code],180).splitlines()[-1])
            (ARTIFACTS/'import-versions.json').write_text(json.dumps(record['imports'],indent=2)+'\n')
            record.update(status='ready_import_verified',gpu_kernel_smoke_pending=True)
        except Exception as error:
            record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        finally:
            record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest())
            write(RECEIPT,record)
    with tarfile.open(ARCHIVE,'w:gz') as archive:
        for path in [RECEIPT,LOG,Path(__file__),*sorted(ARTIFACTS.rglob('*'))]:
            if path.is_file(): archive.add(path,arcname=str(path.relative_to(TASK)))
    write(TASK/'results/knowcoder-author-setup-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status']})
    print(json.dumps(record),flush=True)
    if record['status']!='ready_import_verified':sys.exit(1)
if __name__=='__main__':main()

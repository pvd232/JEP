"""One call through the existing CLI runtime; no extra CWD bootstrap or new kernel."""
import argparse,json,re,runpy,sys,urllib.parse
scope=runpy.run_path('/tmp/jep-colab-safe-cli-20261028.py',run_name='jep_compatibility_import')
from colab_cli.runtime import ColabRuntime
session=scope['_target']
def redact(value):
    text=str(value)
    for secret in (session.token,session.url,urllib.parse.quote(session.token,safe=''),urllib.parse.quote_plus(session.token)):
        if secret:text=text.replace(secret,'[REDACTED]')
    return re.sub(r'(?:https?|wss?)://[^\s\x27\x22<>]+','[URL REDACTED]',text)
p=argparse.ArgumentParser();p.add_argument('--file',required=True);p.add_argument('--timeout',type=float,default=60);args=p.parse_args()
from pathlib import Path
code=Path(args.file).read_text()
runtime=ColabRuntime(session.url,session.token,kernel_id='a4549495-395c-494c-9c2f-921495336eb9',session_id=None,on_kernel_started=None,on_session_started=None)
failed=False
try:
    def output(value):print(redact(json.dumps(value)),flush=True)
    values=runtime.execute_code(code,output_hook=output,timeout=args.timeout)
    failed=any(v.get('output_type')=='error' for v in values)
    print(json.dumps({'direct_execution_complete':True,'error_outputs':failed}),flush=True)
except Exception as error:
    failed=True;chain=[];seen=set();current=error
    while current is not None and id(current) not in seen:
        seen.add(id(current));chain.append({'type':type(current).__name__,'message':redact(current)[:6000]});current=current.__cause__ or current.__context__
    print(json.dumps({'safe_error_chain':chain}),file=sys.stderr,flush=True)
finally:
    try:runtime.stop(shutdown_kernel=False)
    except Exception as error:print(json.dumps({'channel_cleanup_error_type':type(error).__name__}),file=sys.stderr,flush=True)
if failed:sys.exit(1)

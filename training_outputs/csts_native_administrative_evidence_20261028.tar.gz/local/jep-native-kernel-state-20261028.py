import json
from pathlib import Path
import requests,certifi
from colab_cli.state import StateStore
session=StateStore().get('jep-full-propositions-20261027')
report={'session':session.name,'requested_kernel':'a4549495-395c-494c-9c2f-921495336eb9'}
try:
 response=requests.get(session.url.rstrip('/')+'/api/kernels',headers={'X-Colab-Runtime-Proxy-Token':session.token},timeout=(10,20),verify=certifi.where())
 report['http_status']=response.status_code
 if response.status_code==200:
  values=response.json()
  report['kernels']=[{key:row.get(key) for key in ('id','name','execution_state','connections','last_activity')} for row in values]
except Exception as error:
 report['error_type']=type(error).__name__
Path('/tmp/jep-native-kernel-state-20261028.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))

def _jep_knowcoder_repair_v2_launch_20261028():
    from pathlib import Path
    import json,hashlib,tarfile,subprocess,sys,os
    task=Path("/content/jep-native-author-calibration-20261028")
    bundle=Path("/content/jep-knowcoder-repair-v2-bundle-20261028.tar.gz")
    expected="e0e562c6eb169a70ddd3ee046bbc5c048d102848ab3c12f70b6398242fc3f351"
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()==expected,"bundle differs"
    activity=subprocess.run(["nvidia-smi","--query-compute-apps=pid,process_name,used_memory","--format=csv,noheader"],capture_output=True,text=True,timeout=15,check=True)
    print("gpu_compute_processes",activity.stdout.strip() or "none",flush=True)
    assert not activity.stdout.strip(),"GPU occupied; preserve other work"
    receipt=task/"knowcoder-repair-v2-worker.json"
    execution=task/"knowcoder-repair-execution-v2"
    assert not receipt.exists() and not execution.exists(),"Existing worker or execution: inspect before retry"
    assert not (task/"results/knowcoder-repair-canaries-v2").exists(),"Existing outputs; do not repeat"
    execution.mkdir()
    with tarfile.open(bundle) as archive:
        for member in archive.getmembers():
            path=(execution/member.name).resolve()
            assert path.is_relative_to(execution.resolve()) and not member.issym() and not member.islnk(),"unsafe member"
        archive.extractall(execution,filter="data")
    code=execution/"knowcoder-repair-v2"
    assert hashlib.sha256((code/"seal.json").read_bytes()).hexdigest()=="cbf3752ec72fdab543721f651f0f0b8f360ecbc7291cddd5c719e15dd001a4ec","seal differs"
    seal=json.loads((code/"seal.json").read_text())
    for name,hash_value in seal["files"].items():
        assert hashlib.sha256((code/name).read_bytes()).hexdigest()==hash_value,"sealed source differs: "+name
    worker=task/"run_knowcoder_repair_v2.py"
    worker.write_text("from pathlib import Path\nimport subprocess,sys,json,tarfile,hashlib,io,time,os\ntask=Path(\"/content/jep-native-author-calibration-20261028\")\nexecution=task/\"knowcoder-repair-execution-v2\"\ncode=execution/\"knowcoder-repair-v2\"\ncache=task/\"checkpoints/knowcoder\"\noutput=task/\"results/knowcoder-repair-canaries-v2\"\nrecord={\"started_at\":time.time(),\"metadata_only_repair\":True}\nprint(json.dumps({\"event\":\"knowcoder_repair_v2_started\",**record}),flush=True)\ntry:\n    command=[sys.executable,str(code/\"run_repair.py\"),\"--cache-dir\",str(cache),\"--output\",str(output)]\n    result=subprocess.run(command,cwd=execution,check=False,env=dict(os.environ,HF_HUB_OFFLINE=\"1\",TRANSFORMERS_OFFLINE=\"1\"))\n    record[\"returncode\"]=result.returncode\nexcept Exception as exc:\n    record.update(error_type=type(exc).__name__,error=str(exc))\nrecord[\"finished_at\"]=time.time()\ncompletion=task/\"results/knowcoder-repair-v2-completion.json\"\ncompletion.write_text(json.dumps(record,indent=2)+\"\\n\")\nmembers={}\nfor base,prefix in ((execution,\"execution\"),(output,\"results/knowcoder-repair-canaries-v2\")):\n    if base.exists():\n        for path in base.rglob(\"*\"):\n            if path.is_file():\n                members[prefix+\"/\"+str(path.relative_to(base))]=path\nfor path,arcname in ((completion,\"completion.json\"),(task/\"results/knowcoder-download.json\",\"download.json\"),(task/\"logs/knowcoder-repair-v2.log\",\"worker.log\"),(task/\"knowcoder-repair-v2-worker.json\",\"worker.json\"),(task/\"results/compiler-preflight.json\",\"compiler-preflight.json\")):\n    if path.exists():\n        members[arcname]=path\nindex={name:{\"bytes\":path.stat().st_size,\"sha256\":hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in members.items()}\nartifact=Path(\"/content/jep-knowcoder-repair-v2-results-20261028.tar.gz\")\nwith tarfile.open(artifact,\"w:gz\") as archive:\n    for name,path in sorted(members.items()):\n        archive.add(path,arcname=name,recursive=False)\n    data=(json.dumps(index,sort_keys=True,indent=2)+\"\\n\").encode()\n    entry=tarfile.TarInfo(\"capture-index.json\");entry.size=len(data)\n    archive.addfile(entry,io.BytesIO(data))\nsummary={**record,\"archive\":str(artifact),\"bytes\":artifact.stat().st_size,\"sha256\":hashlib.sha256(artifact.read_bytes()).hexdigest(),\"files\":len(members)}\n(task/\"results/knowcoder-repair-v2-archive.json\").write_text(json.dumps(summary,indent=2)+\"\\n\")\nprint(json.dumps({\"event\":\"knowcoder_repair_v2_archived\",**summary}),flush=True)\n")
    with receipt.open("x") as handle:
        json.dump({"status":"prepared","bundle_sha256":expected},handle)
    log=task/"logs/knowcoder-repair-v2.log"
    with log.open("x") as output:
        process=subprocess.Popen([sys.executable,str(worker)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=execution,env=dict(os.environ))
    record={"pid":process.pid,"status":"dispatched","bundle_sha256":expected,"log":str(log),"cache_dir":str(task/"checkpoints/knowcoder"),"no_new_download":True}
    receipt.write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record),flush=True)
    
_jep_knowcoder_repair_v2_launch_20261028()
del _jep_knowcoder_repair_v2_launch_20261028


def _jep_knowcoder_historical_setup_launch_20261028():
    from pathlib import Path
    import json,hashlib,subprocess,sys,os,tarfile,shutil
    task=Path('/content/jep-native-author-calibration-20261028')
    bundle=Path('/content/jep-knowcoder-legacy-vllm-v3-bundle-20261028.tar.gz')
    script=task/'knowcoder-historical-setup.py'
    root=task/'knowcoder-legacy-vllm-v3-execution'
    worker=task/'knowcoder-author-setup-worker.json'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='c2805c1da57092916a26c30d2fe91c76ea7bf2e68f4d53fdbe19dedc7b22c107','Bundle seal mismatch'
    assert hashlib.sha256(script.read_bytes()).hexdigest()=='3e146bcfe0ea5d9f7c140b8c3f1cf744611b264130a9fa745f55cc149fd79b7d','Setup script changed'
    assert not worker.exists(),'Worker exists: inspect, do not relaunch'
    assert not root.exists(),'Execution directory exists: inspect, do not overwrite'
    assert not (task/'environments/knowcoder-author-py310').exists(),'Environment exists: inspect'
    assert not (task/'environments/knowcoder-author-setup.json').exists(),'Setup receipt exists'
    assert shutil.disk_usage(task).free>20*1024**3,'Preserve at least 20GiB before historical environment install'
    root.mkdir()
    with tarfile.open(bundle) as archive:
        archive.extractall(root,filter='data')
    with worker.open('x') as handle: json.dump({'status':'prepared','setup_sha256':'3e146bcfe0ea5d9f7c140b8c3f1cf744611b264130a9fa745f55cc149fd79b7d','bundle_sha256':'c2805c1da57092916a26c30d2fe91c76ea7bf2e68f4d53fdbe19dedc7b22c107'},handle)
    log=task/'logs/knowcoder-author-setup-controller.log'
    with log.open('x') as output:
        process=subprocess.Popen([sys.executable,str(script)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ))
    record={'pid':process.pid,'status':'dispatched','script_sha256':'3e146bcfe0ea5d9f7c140b8c3f1cf744611b264130a9fa745f55cc149fd79b7d','log':str(log),'cpu_only':True,'model_calls':False,'shared_packages_modified':False}
    worker.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
_jep_knowcoder_historical_setup_launch_20261028()
del _jep_knowcoder_historical_setup_launch_20261028

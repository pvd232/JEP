def _jep_gollie_setup_launch_20261028():
    from pathlib import Path
    import hashlib,json,subprocess,sys,os
    task=Path("/content/jep-native-author-calibration-20261028")
    script=task/"gollie-setup-environment.py"
    expected="a3680510e5d04ff7c0a338d24f94b4e7698391f23c6ceb6bea323c8d3a689262"
    assert hashlib.sha256(script.read_bytes()).hexdigest()==expected,"Setup script differs"
    receipt=task/"gollie-setup-worker.json"
    assert not receipt.exists(),"Existing setup worker: inspect before retry"
    assert not (task/"environments/gollie-author-flash").exists(),"Existing author environment: inspect before retry"
    assert not (task/"environments/gollie-author-setup.json").exists(),"Existing setup receipt: inspect before retry"
    log=task/"logs/gollie-author-setup-controller.log"
    with receipt.open("x") as handle:
        json.dump({"status":"prepared","script_sha256":expected},handle)
    with log.open("x") as output:
        process=subprocess.Popen([sys.executable,str(script)],stdout=output,stderr=subprocess.STDOUT,start_new_session=True,cwd=task,env=dict(os.environ,PIP_NO_INPUT="1"))
    record={"pid":process.pid,"status":"dispatched","script_sha256":expected,"log":str(log),"setup_receipt":str(task/"environments/gollie-author-setup.json"),"cpu_only_setup":True}
    receipt.write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record),flush=True)
_jep_gollie_setup_launch_20261028()
del _jep_gollie_setup_launch_20261028

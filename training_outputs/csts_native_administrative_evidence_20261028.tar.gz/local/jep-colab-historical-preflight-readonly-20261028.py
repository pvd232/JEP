def _jep_historical_preflight_readonly_20261028():
    from pathlib import Path
    import json,hashlib,shutil,subprocess,traceback
    task=Path('/content/jep-native-author-calibration-20261028')
    targets=[Path('/content/jep-knowcoder-legacy-vllm-v3-bundle-20261028.tar.gz'),task/'knowcoder-historical-setup.py',task/'knowcoder-legacy-vllm-v3-execution',task/'knowcoder-author-setup-worker.json',task/'environments/knowcoder-author-py310',task/'environments/knowcoder-author-setup.json',task/'logs/knowcoder-author-setup-controller.log',task/'logs/knowcoder-author-setup.log']
    record={'kind':'read_only_historical_preflight','files':{}}
    try:
        record['disk_free_bytes']=shutil.disk_usage(task).free
        for path in targets:
            row={'exists':path.exists(),'is_file':path.is_file()}
            if path.is_file():
                row['bytes']=path.stat().st_size
                if path.suffix in ('.json','.log'):row['tail']=path.read_text(errors='replace')[-6000:]
                else:row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            record['files'][str(path)]=row
        probe=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20)
        record['gpu_compute_processes']=probe.stdout;record['gpu_query_returncode']=probe.returncode
    except Exception as error:record.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    print(json.dumps(record),flush=True)
_jep_historical_preflight_readonly_20261028()
del _jep_historical_preflight_readonly_20261028

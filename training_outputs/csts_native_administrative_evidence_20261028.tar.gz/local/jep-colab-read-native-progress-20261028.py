def _jep_read_native_progress_20261028():
    from pathlib import Path
    import json, subprocess
    task = Path('/content/jep-native-author-calibration-20261028')
    names = [
        'results/gollie-author-legacy-attempt02-worker.json',
        'logs/gollie-author-legacy-attempt02.log',
        'logs/gollie-author-legacy-attempt02-controller.log',
    ]
    result = {}
    for name in names:
        path = task / name
        result[name] = path.read_text(errors='replace')[-10000:] if path.exists() else None
    out = task / 'results/gollie-author-legacy-attempt02'
    result['probe_files'] = sorted(str(p.relative_to(out)) for p in out.rglob('*') if p.is_file()) if out.exists() else []
    result['gpu_processes'] = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory', '--format=csv,noheader'], capture_output=True, text=True, timeout=15).stdout
    print(json.dumps(result), flush=True)
_jep_read_native_progress_20261028()
del _jep_read_native_progress_20261028

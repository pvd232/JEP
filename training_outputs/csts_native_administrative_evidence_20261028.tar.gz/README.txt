Administrative setup/import/preflight evidence; not model prediction or quality data

Source files alone do not prove execution; use receipts/logs. Local snapshots can predate terminal archived receipts.
Know repair v1/v2 loaded weights but failed metadata serialization before generation; both have zero generation records.
Know initial author import gate incorrectly requested vllm._C; historical v0.2.2 uses distinct compiled *_ops modules.
Know import amendment01 misread wheel filename suffix as metadata version; amendment02 records actual distribution/module2.3.4 and passes all imports.
Go shared-runtime Flash source builds failed; logs retained. Clean task-owned Python3.10/Torch2.1cu118 environment succeeded.
Know legacy first artifact guard failed on cache filename before Torch/model import; successful v5 hashes actual shard bytes.
Go first author wrapper lacked cached original modeling source; next loaded models but failed Triton real-driver discovery before any generated answer.
The alternate-cache driver helper v1 was HELD and NEVER EXECUTED. Actual v2 only adds a task-local read-only ldconfig -p wrapper for the real driver.
A Connection-lost CLI result does not imply zero generation: Know dispatch recovery was later confirmed to run30 controls successfully. Model predictions stay in their separate archives.
No shared notebook packages, unrelated GPU processes, kernels or session lifecycle were modified by this collection.

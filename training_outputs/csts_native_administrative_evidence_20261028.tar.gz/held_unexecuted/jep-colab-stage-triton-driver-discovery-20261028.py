def _jep_stage_triton_driver_discovery_20261028():
    from pathlib import Path
    import hashlib, json, os, shlex, subprocess, time, traceback
    task = Path('/content/jep-native-author-calibration-20261028')
    root = task / 'environments/triton-driver-discovery-v1'
    root.mkdir(exist_ok=False)
    receipt = root / 'receipt.json'
    record = {'status': 'started', 'started_at': time.time(),
              'model_calls': False, 'gpu_calls': False,
              'global_cache_or_symlinks_modified': False,
              'activation_scope': 'PATH prefix for future task model subprocess only'}
    def save():
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(receipt)
    save()
    try:
        binary = Path('/sbin/ldconfig').resolve(strict=True)
        driver = Path('/usr/lib64-nvidia/libcuda.so')
        resolved = driver.resolve(strict=True)
        if not resolved.is_relative_to(Path('/usr/lib64-nvidia')) or '/stubs/' in str(resolved):
            raise ValueError('Expected real mounted NVIDIA driver, never CUDA stubs')
        help_result = subprocess.run([str(binary), '--help'], capture_output=True, text=True, check=True, timeout=15)
        (root / 'ldconfig-help.txt').write_text(help_result.stdout)
        if not all(flag in help_result.stdout for flag in ('-C', '-f', '-X', '-i', '-p')):
            raise ValueError('Real ldconfig does not expose the required explicit-cache flags')
        record.update(real_ldconfig=str(binary), real_ldconfig_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                      driver=str(driver), driver_resolved=str(resolved),
                      driver_sha256=hashlib.sha256(resolved.read_bytes()).hexdigest())
        config = root / 'ld.so.conf'
        config.write_text('/usr/lib64-nvidia\n')
        cache = root / 'ld.so.cache'
        command = [str(binary), '-X', '-i', '-C', str(cache), '-f', str(config)]
        result = subprocess.run(command, capture_output=True, text=True, check=True, timeout=30)
        record['cache_build_command'] = command
        (root / 'cache-build.stdout').write_text(result.stdout)
        (root / 'cache-build.stderr').write_text(result.stderr)
        bins = root / 'bin'
        bins.mkdir()
        wrapper = bins / 'ldconfig'
        script = ("#!/bin/sh\n"
                  "if [ \"$#\" -ne 1 ] || [ \"$1\" != \"-p\" ]; then\n"
                  "  printf '%s\\n' 'Task driver discovery supports only ldconfig -p' >&2\n"
                  "  exit 64\n"
                  "fi\n"
                  "exec " + shlex.quote(str(binary)) + " -p -C " + shlex.quote(str(cache)) + "\n")
        wrapper.write_text(script)
        wrapper.chmod(0o755)
        env = dict(os.environ, PATH=str(bins) + os.pathsep + os.environ.get('PATH', ''))
        observed = subprocess.run(['ldconfig', '-p'], env=env, capture_output=True, text=True, check=True, timeout=15)
        (root / 'task-cache-listing.txt').write_text(observed.stdout)
        cuda_lines = [line for line in observed.stdout.splitlines() if 'libcuda.so' in line]
        if not any(str(driver.parent) in line for line in cuda_lines):
            raise ValueError('Task cache does not contain the verified real NVIDIA driver')
        rejected = subprocess.run([str(wrapper)], capture_output=True, text=True, timeout=15)
        if rejected.returncode != 64:
            raise ValueError('Task wrapper failed to reject a mutating/default invocation')
        # Import only: prove the old Triton discovery path now sees real libraries.
        python = task / 'environments/knowcoder-author-py310/bin/python'
        observed_triton = subprocess.run([str(python), '-c',
            'import json; from triton.common.build import libcuda_dirs; print(json.dumps(libcuda_dirs()))'],
            env=dict(env, CUDA_VISIBLE_DEVICES='', PYTHONNOUSERSITE='1'),
            capture_output=True, text=True, check=True, timeout=30)
        (root / 'triton-discovery.stdout').write_text(observed_triton.stdout)
        (root / 'triton-discovery.stderr').write_text(observed_triton.stderr)
        dirs = json.loads(observed_triton.stdout.splitlines()[-1])
        if str(driver.parent) not in dirs:
            raise ValueError('Old Triton did not discover the verified real driver directory')
        record.update(status='ready_cpu_discovery_verified', path_prefix=str(bins),
                      discovered_cuda_lines=cuda_lines, triton_driver_dirs=dirs,
                      cache_sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),
                      wrapper_sha256=hashlib.sha256(wrapper.read_bytes()).hexdigest(),
                      config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),
                      wrapper_rejects_unexpected_arguments=True,
                      gpu_kernel_check_pending=True)
    except Exception as error:
        record.update(status='failed', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
    finally:
        record['finished_at'] = time.time()
        save()
    print(json.dumps(record), flush=True)
_jep_stage_triton_driver_discovery_20261028()
del _jep_stage_triton_driver_discovery_20261028

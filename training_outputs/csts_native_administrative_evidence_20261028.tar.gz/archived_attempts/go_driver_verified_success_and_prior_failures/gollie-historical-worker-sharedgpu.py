"""Run the sealed original GoLLIE Flash versus stock-eager reference probe once."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
ROOT=TASK/'gollie-author-legacy-probe-execution/gollie-author-legacy-probe'
OUTPUT=TASK/'results/gollie-author-legacy-probe'
LOG=TASK/'logs/gollie-author-legacy-probe.log'
RECEIPT=TASK/'results/gollie-author-legacy-worker.json'
ARCHIVE=TASK/'results/gollie-author-legacy-probe-results.tar.gz'
REV='d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9'
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def main():
    if any(path.exists() for path in [OUTPUT,LOG,RECEIPT,ARCHIVE]):raise ValueError('GoLLIE historical attempt already exists; inspect rather than relaunch')
    gate=TASK/'environments/knowcoder-author-setup-amendment02.json'
    if json.loads(gate.read_text())['status']!='ready_import_verified':raise ValueError('Historical setup gate not ready')
    from huggingface_hub.constants import HF_HUB_CACHE
    snapshot=Path(HF_HUB_CACHE)/'models--HiTZ--GoLLIE-7B'/'snapshots'/REV
    if not snapshot.is_dir():raise ValueError('Original pinned local GoLLIE cache missing: '+str(snapshot))
    if hashlib.sha256((snapshot/'modeling_flash_llama.py').read_bytes()).hexdigest()!='39ed69a0a8f40344981ba6c142074ea315769a770d959ef214aab41d181a6dbd':raise ValueError('Pinned original GoLLIE source differs')
    gpu=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
    memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
    total_mib,free_mib,utilization=[int(x.strip()) for x in memory.stdout.splitlines()[0].split(',')]
    if free_mib<45*1024:raise RuntimeError('Preserve other work: Go requires45GiB free before launch')
    shared_gpu={'foreign_compute_processes_before_launch':gpu.stdout,'total_mib':total_mib,'free_mib_before_launch':free_mib,'utilization_percent_before_launch':utilization,'required_free_mib':45*1024,'shared_gpu':bool(gpu.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True}
    record={'status':'started','started_at':time.time(),'snapshot':str(snapshot),'setup_receipt_sha256':hashlib.sha256(gate.read_bytes()).hexdigest(),'primary_outputs_unchanged':True,'attempts':1,'original_flash_vs_transformers434_eager':True,'parity_with_old520_sdpa_claimed':False,'gpu_scheduling':shared_gpu}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),TOKENIZERS_PARALLELISM='false')
    runtime.pop('PYTHONPATH',None)
    try:
        command=[str(ENV/'bin/python'),str(ROOT/'run_backend_probe.py'),'--snapshot',str(snapshot),'--output',str(OUTPUT)]
        record['command']=command;write(RECEIPT,record)
        with LOG.open('x') as output:result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        if result.returncode:raise RuntimeError('Legacy GoLLIE process failed; preserve full cause, no blind retry')
        completion=json.loads((OUTPUT/'completed.json').read_text())
        if completion.get('completed') is not True:raise ValueError('GoLLIE probe incomplete')
        record.update(status='complete',completion=completion)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest() if LOG.exists() else None);write(RECEIPT,record)
        index={str(path.relative_to(TASK)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(OUTPUT.rglob('*')) if path.is_file()} if OUTPUT.exists() else {}
        index_path=TASK/'results/gollie-author-legacy-capture-index.json';write(index_path,index)
        with tarfile.open(ARCHIVE,'w:gz') as archive:
            for path in [RECEIPT,index_path,Path(__file__),LOG,gate]:
                if path.exists():archive.add(path,arcname=str(path.relative_to(TASK)))
            archive.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if OUTPUT.exists():archive.add(OUTPUT,arcname=str(OUTPUT.relative_to(TASK)))
        write(TASK/'results/gollie-author-legacy-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

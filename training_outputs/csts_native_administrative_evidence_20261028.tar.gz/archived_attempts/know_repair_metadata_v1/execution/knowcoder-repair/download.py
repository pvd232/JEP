"""Download only the two explicitly pinned KnowCoder snapshots after checking free disk."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir",type=Path)
    parser.add_argument("--record",type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    seal=json.loads((root/"seal.json").read_text())
    for name,digest in seal["files"].items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
            raise ValueError("Repair package changed: "+name)
    if args.record.exists():
        raise ValueError("Download record already exists; refusing to overwrite")
    from huggingface_hub import snapshot_download, constants
    cache=args.cache_dir or Path(constants.HF_HUB_CACHE)
    cache.mkdir(parents=True,exist_ok=True)
    free=shutil.disk_usage(cache).free
    # Both snapshots require about27GB if the isolated cache is empty. Leave8GBreserve.
    required=36_000_000_000
    if free<required:
        raise RuntimeError("Need at least36GBfree for both pinned snapshots and8GBreserve")
    design=json.loads((root/"design.json").read_text())
    allow=["config.json","generation_config.json","pytorch_model.bin.index.json",
        "pytorch_model-00001-of-00002.bin","pytorch_model-00002-of-00002.bin",
        "special_tokens_map.json","tokenizer.json","tokenizer.model","tokenizer_config.json","README.md"]
    records={}
    for name,identity in design["checkpoints"].items():
        path=Path(snapshot_download(identity["model_id"],revision=identity["revision"],
            cache_dir=str(cache),allow_patterns=allow))
        index=json.loads((path/"pytorch_model.bin.index.json").read_text())
        expected_shards={"pytorch_model-00001-of-00002.bin","pytorch_model-00002-of-00002.bin"}
        if set(index["weight_map"].values())!=expected_shards or len(index["weight_map"])!=291:
            raise ValueError("Unexpected pinned KnowCoder shard/index structure")
        files={}
        for file in sorted(path.iterdir()):
            if file.is_file() and file.name in allow:
                entry={"bytes":file.stat().st_size,"cache_resolved_basename":file.resolve().name}
                if not file.name.endswith(".bin"):
                    entry["sha256"]=hashlib.sha256(file.read_bytes()).hexdigest()
                files[file.name]=entry
        records[name]={"identity":identity,"path":str(path),"files":files}
        print(json.dumps({"model":name,"snapshot":str(path),"verified_index_tensors":291}),flush=True)
    value={"free_bytes_before":free,"free_bytes_after":shutil.disk_usage(cache).free,
        "seal_sha256":hashlib.sha256((root/"seal.json").read_bytes()).hexdigest(),"snapshots":records,
        "note":"Weight identities are pinnedHubrevision and retainedcacheblob basenames; no claim of independently recomputed weightfileSHA256."}
    with args.record.open("x",encoding="utf-8") as handle:
        json.dump(value,handle,ensure_ascii=False,indent=2,sort_keys=True)
        handle.write("\n")


if __name__=="__main__":
    main()

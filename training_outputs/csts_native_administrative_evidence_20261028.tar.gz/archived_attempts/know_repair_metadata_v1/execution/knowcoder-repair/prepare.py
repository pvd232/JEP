"""Prepare fixed KnowCoder checkpoint/precision/native-schema canaries, no inference."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil

ROOT = Path("/tmp/jep-knowcoder-repair-20261028")
AUTHOR = "b7859789fc7641e03916074088859aa592332ad3"
SCHEMA = "6741109ca2055b2fb022be4adb963dda2d95d34c"
native_code = Path("/tmp/jep-extraction-knowcoder-author-v4-code-20261028")
sources_path = Path("/tmp/jep-extraction-knowcoder-author-v4-20261028/sources.json")
sources = json.loads(sources_path.read_text())
author_fixture = next(x for x in json.loads(Path("/tmp/jep-native-author-controls-20261028/author_fixtures.json").read_text()) if x["arm"] == "knowcoder")
system = author_fixture["prompt"].split("\nInput:\n", 1)[0]
library = {}
for filename in ("Relations.py", "Entities.py"):
    source = (ROOT / filename).read_text()
    classes = {}
    for match in re.finditer(r"^class ([A-Za-z_][A-Za-z0-9_]*)\([^\n]*", source, re.M):
        end = source.find("\nclass ", match.end())
        block = source[match.start():end if end >= 0 else None].strip()
        if match.group(1) not in classes:
            try:
                ast.parse(block)
            except SyntaxError:
                continue
            classes[match.group(1)] = block
    library[filename] = classes

def without_examples(block):
    lines = []
    for line in block.splitlines():
        if line.strip().startswith("Examples:"):
            continue
        lines.append(line)
    return "\n".join(lines)

def schema(name, task, examples):
    classes = library["Relations.py" if task == "RE" else "Entities.py"]
    selected = []
    visited = set()
    def add(label):
        if label in {"Entity", "Relation"} or label in visited:
            return
        visited.add(label)
        block = classes[label]
        node = ast.parse(block).body[0]
        for base in node.bases:
            if not isinstance(base, ast.Name):
                raise ValueError("Nonliteral schema base")
            add(base.id)
        selected.append((label, block if examples else without_examples(block)))
    add(name)
    base = "class Entity:\n\tdef __init__(self, name: str):\n\t\tself.name = name\n"
    if task == "RE":
        base += "\nclass Relation:\n\tdef __init__(self, head_entity: Entity, tail_entity: Entity):\n\t\tself.head_entity = head_entity\n\t\tself.tail_entity = tail_entity\n"
    return base + "\n" + "\n\n".join(block for _, block in selected), [label for label, _ in selected]

def prompt(item, label, task, examples):
    definitions, classes = schema(label, task, examples)
    subject = "Relation Classes and related Entity Classes" if task == "RE" else "Entity Classes"
    kind = "Relation" if task == "RE" else "Entity"
    instruction = (
        '"""\nThis is an object-oriented programming task: Some ' + subject
        + " are defined above. Please instantiate all the corresponding " + kind
        + ' Objects in the following sentence.\n"""'
    )
    query = definitions + "\n\n" + instruction + "\nsentence = " + json.dumps(item["passage"], ensure_ascii=False)
    return system + "\nInput:\n" + query + "\nOutput:\n", classes

# Fixed source-only selection before all repair outputs, no JEP references/ratings used.
choices = [
    (1, "soccer_sport_relation", "Sport", "RE", [["team", "soccer"]]),
    (2, "tennis_sport_entity", "Sport", "NER", [["tennis"]]),
    (3, "food_entity", "Food", "NER", [["sandwich"], ["pickle"]]),
    (5, "surfboard_color_relation", "Color", "RE", [["surfboard", "white"]]),
    (29, "surfer_clothing_relation", "Wears", "RE", [["man", "wetsuit"]]),
    (60, "pizza_location_relation", "Location", "RE", [["pizza", "table"]]),
    (76, "snow_color_absent", "Color", "RE", []),
]
fixtures = [{
    "fixture_id": "published_author_kurush", "task": "RE", "target_class": None,
    "source": None, "source_index": None, "expected_nonempty": True,
    "variants": {"author_exact": {
        "prompt": author_fixture["prompt"],
        "allowed_classes": author_fixture["allowed_relation_classes"],
        "expected_author_output": author_fixture["expected_author_output"],
        "minimal_expected_anchors": [
            ["LocatedIn", "Kurush", "Dokuzparinsky District"],
            ["LocatedIn", "Dokuzparinsky District", "Dagestan"],
            ["Population", "Kurush", "813"],
        ],
    }},
    "author_source_url": author_fixture["source_url"],
}]
for index, fid, label, task, gold in choices:
    item = sources[index]
    variants = {}
    for examples in (False, True):
        p, classes = prompt(item, label, task, examples)
        variants["published_examples" if examples else "description_only"] = {
            "prompt": p, "allowed_classes": classes,
            "minimal_expected_anchors": [[label, *row] for row in gold],
        }
    fixtures.append({
        "fixture_id": fid, "task": task, "target_class": label, "source": item,
        "source_index": index, "expected_nonempty": bool(gold), "variants": variants,
        "schema_origin": "First matching class definition and required ancestor definitions from pinned published library.",
    })

def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

dump("fixtures.json", fixtures)
shutil.copyfile(sources_path, ROOT / "sources.json")
shutil.copytree(native_code, ROOT / "code", dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
dump("design.json", {
    "purpose": "Post-screen repair canaries, no representative benchmark claims or retroactive source-run replacement.",
    "selection": "Known author fixture plus six literal positive actual-source canaries and one absent-color negative, fixed before repair outputs.",
    "conditions": [
        {"id": "base_bf16", "model": "base", "dtype": "bfloat16"},
        {"id": "base_fp16", "model": "base", "dtype": "float16"},
        {"id": "ie_fp16", "model": "ie", "dtype": "float16"},
    ],
    "checkpoints": {
        "base": {"model_id": "golaxy/KnowCoder-7B-base", "revision": "4a7a076f573fe87fe0a97670c63c64214484742f"},
        "ie": {"model_id": "golaxy/KnowCoder-7B-IE", "revision": "90ba076763dfb2e9efefd84a0e599f15ae533597"},
    },
    "provenance": {
        "author_repo_revision": AUTHOR, "schema_library_revision": SCHEMA,
        "author_inference_url": "https://github.com/ICT-GoKnow/KnowCoder/blob/" + AUTHOR + "/eval/src/inference.py",
        "schema_url": "https://huggingface.co/datasets/golaxy/KnowCoder-Schema-Library/tree/" + SCHEMA + "/schema_pys",
    },
    "changes": "Exact author wrapper and RE/NER task instructions. Target schemas are actual published class definitions, "
        "including required ancestors, versus the prior ad-hoc ConditionRelation. Description-only removes Examples lines; "
        "published-examples retains them. No JEP condition/question or generic evidence policy is added.",
    "mapping": "Native Sport/Food NER extracts typed spans; native Sport/Color/Location/Wears RE extracts Entity head/tail. "
        "These are declared task mappings, not an unchanged syntax-only comparison.",
    "held_constant": {"runtime": "Current Transformers backend; this is NOT yet vLLM reproduction.",
        "tokenizer": "Pinned model tokenizer, use_fast=True, legacy=False, left padding, add_special_tokens=True.",
        "decoding": {"do_sample": False, "num_beams": 1, "max_new_tokens": 1024, "min_new_tokens": 0},
        "stop": "Author triple-quote stop with full raw decode retained.", "attempts_per_cell": 1},
    "precision": "Fresh loads from original cached pinned tensors for each condition; never BF16-to-FP16 recasting. "
        "FP16 matches checkpoint config and author's default vLLM dtype=auto interpretation. BF16 is prior screen precision.",
    "runtime_gaps": "vLLM versus Transformers remains a separate untested engine gap. IE BF16 is not tested; matrix is not a full factorial.",
    "lineage": "README says base trained in both phases, IE further refined; _name_or_path points to KELM/global_step300 "
        "for base and sft_ckpt3500 for IE. Stale paths do not prove phase identity; IE remains an explicitly separate checkpoint.",
    "interpretation": "Expected anchors are minimal and surface variants require semantic review. Nonempty, native schema validity, "
        "anchor match and semantic correctness are separate. If a condition recovers, validate on fresh held-out sources before any main rerun.",
})
print("prepared",len(fixtures),"fixtures;15 prompts/condition;45 total")

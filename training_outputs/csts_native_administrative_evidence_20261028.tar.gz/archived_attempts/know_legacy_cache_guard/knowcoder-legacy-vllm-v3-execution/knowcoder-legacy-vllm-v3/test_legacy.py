"""CPU-only validation for the optional historical author-runtime probe."""
import ast
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import run_legacy as probe

ROOT = Path(__file__).resolve().parent


class LegacyProbeTests(unittest.TestCase):
    def test_runtime_metadata_hf_integer_keys_and_sets(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "runtime.json"
            probe.write(path, {"hf_config": {"id2label": {0: "LABEL_0"}},
                               "strict_loading_report": {"missing_keys": set()}})
            self.assertEqual(json.loads(path.read_text()),
                             {"hf_config": {"id2label": {"0": "LABEL_0"}},
                              "strict_loading_report": {"missing_keys": []}})

    def test_metadata_collision_rejected_before_publication(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "runtime.json"
            with self.assertRaises(ValueError):
                probe.write(path, {1: "integer", "1": "string"})
            self.assertFalse(path.exists())

    def test_copied_shard_hash_and_same_size_corruption(self):
        import hashlib
        with tempfile.TemporaryDirectory() as temporary:
            snapshot = Path(temporary)
            path = snapshot / "shard.bin"
            data = b"good"
            path.write_bytes(data)
            audit = {"selected_shards": {"shard.bin": {
                "lfs": {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}}}}
            good = probe.verify_weight_files(snapshot, audit)["shard.bin"]
            self.assertTrue(good["full_file_hash_recomputed"])
            path.write_bytes(b"evil")
            with self.assertRaisesRegex(ValueError, "Copied shard SHA256"):
                probe.verify_weight_files(snapshot, audit)

    def test_nonfinite_logprob_does_not_lose_token_ids(self):
        for number in (float("inf"), float("-inf"), float("nan")):
            record = {"token_ids": [1, 2], "cumulative_logprob": probe.diagnostic_number(number)}
            self.assertEqual(json.loads(json.dumps(record, allow_nan=False))["token_ids"], [1, 2])
        self.assertEqual(probe.diagnostic_number(-1.25), -1.25)

    def test_version_gate(self):
        with patch.object(probe.metadata, "version", side_effect=lambda name: probe.REQUIRED_VERSIONS.get(name, "other")):
            self.assertEqual(probe.versions()["vllm"], "0.2.2+cu118")
        with patch.object(probe.metadata, "version", return_value="5.20.2"):
            with self.assertRaisesRegex(ValueError, "Historical runtime gate"):
                probe.versions()

    def test_fixed_fixtures_syntax_and_gold_parser(self):
        fixtures = json.loads((ROOT / "fixtures.json").read_text())
        sources = json.loads((ROOT / "sources.json").read_text())
        count = 0
        for fixture in fixtures:
            if fixture["source"] is not None:
                self.assertEqual(sources[fixture["source_index"]], fixture["source"])
            for variant in fixture["variants"].values():
                query = variant["prompt"].split("\nInput:\n", 1)[1].rsplit("\nOutput:\n", 1)[0]
                ast.parse(query)
                expressions = []
                for row in variant["minimal_expected_anchors"]:
                    values = [repr(x) for x in row[1:]]
                    if fixture["task"] == "RE":
                        values = ["Entity(" + x + ")" for x in values]
                    expressions.append(row[0] + "(" + ",".join(values) + ")")
                payload = "results = [" + ",".join(expressions) + "]"
                record = probe.parse_record(payload, fixture, variant)
                self.assertEqual(record["parse_status"], "valid")
                self.assertTrue(record["exact_anchor_match"])
                for bad in ["__import__('os').system('false')", "[]\nimport os", "results = None"]:
                    self.assertNotEqual(probe.parse_record(bad, fixture, variant)["parse_status"], "valid")
                count += 1
        self.assertEqual(count, 15)

    def test_empty_is_separate_from_schema_failure(self):
        fixture = {"task": "RE", "target_class": "Color"}
        variant = {"allowed_classes": ["Color"], "minimal_expected_anchors": []}
        empty = probe.parse_record("results = []", fixture, variant)
        self.assertEqual(empty["parse_status"], "valid")
        self.assertTrue(empty["empty_list_emitted"])
        bad = probe.parse_record('results = [Unknown("a")]', fixture, variant)
        self.assertNotEqual(bad["parse_status"], "valid")
        self.assertFalse(bad["empty_list_emitted"])
        self.assertIsNone(empty["anchors_present"])

    def test_author_projection(self):
        class Tokenizer:
            def decode(self, ids):
                self.ids = ids
                return "<s>system\nInput:\nquery\nOutput:\nresults = []</s>"
        tokenizer = Tokenizer()
        self.assertEqual(probe.author_projection(tokenizer, [1, 2], [3, 4]), "results = []")
        self.assertEqual(tokenizer.ids, [1, 2, 3, 4])

    def test_pinned_snapshot_metadata_and_missing_shard_gate(self):
        design = json.loads((ROOT / "design.json").read_text())
        for checkpoint in ("base", "ie"):
            identity = design["checkpoints"][checkpoint]
            pinned = ROOT / "pinned-metadata" / checkpoint
            with tempfile.TemporaryDirectory() as temporary:
                snapshot = Path(temporary) / identity["revision"]
                snapshot.mkdir()
                for name in probe.METADATA_FILES:
                    shutil.copyfile(pinned / name, snapshot / name)
                audit = probe.snapshot_metadata(snapshot, identity, pinned)
                self.assertEqual(audit["indexed_parameter_tensors"], 291)
                self.assertEqual(len(audit["architecture_derived_parameter_shapes"]), 291)
                with self.assertRaisesRegex(ValueError, "Pinned shard absent"):
                    probe.verify_weight_files(snapshot, audit)
                (snapshot / "config.json").write_text("{}")
                with self.assertRaisesRegex(ValueError, "Pinned snapshot metadata differs"):
                    probe.snapshot_metadata(snapshot, identity, pinned)

    def test_snapshot_revision_gate(self):
        design = json.loads((ROOT / "design.json").read_text())
        with self.assertRaisesRegex(ValueError, "end with the pinned revision"):
            probe.snapshot_metadata(ROOT, design["checkpoints"]["base"], ROOT / "pinned-metadata" / "base")


if __name__ == "__main__":
    unittest.main()

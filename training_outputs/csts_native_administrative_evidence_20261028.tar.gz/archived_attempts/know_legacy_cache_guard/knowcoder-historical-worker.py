"""Run the approved fixed BASE/IE legacy probes in separate sequential processes."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
ROOT=TASK/'knowcoder-legacy-vllm-v3-execution/knowcoder-legacy-vllm-v3'
RECEIPT=TASK/'results/knowcoder-legacy-author-worker.json'
ARCHIVE=TASK/'results/knowcoder-legacy-author-results.tar.gz'
IDENTITIES={'base':('KnowCoder-7B-base','4a7a076f573fe87fe0a97670c63c64214484742f'),'ie':('KnowCoder-7B-IE','90ba076763dfb2e9efefd84a0e599f15ae533597')}
def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def gpu_free():
    result=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=20,check=True)
    if result.stdout.strip():raise RuntimeError('GPU occupied; preserve existing process: '+result.stdout.strip())
    return result.stdout

def main():
    if RECEIPT.exists() or ARCHIVE.exists():raise ValueError('Legacy worker exists; inspect rather than relaunch')
    setup=json.loads((TASK/'environments/knowcoder-author-setup-amendment02.json').read_text())
    if setup['status']!='ready_import_verified':raise ValueError('Historical environment import/version gate not passed')
    for key in IDENTITIES:
        if (TASK/('results/knowcoder-legacy-author-'+key)).exists():raise ValueError('Checkpoint output already exists')
        if (TASK/('logs/knowcoder-legacy-author-'+key+'.log')).exists():raise ValueError('Checkpoint log already exists')
    gpu_free()
    record={'status':'started','started_at':time.time(),'checkpoints':{},'setup_receipt_sha256':hashlib.sha256((TASK/'environments/knowcoder-author-setup-amendment02.json').read_bytes()).hexdigest(),'primary_outputs_unchanged':True,'model_runs_per_checkpoint':1,'checkpoint_order':['base','ie'],'historical_core_runtime_separate_condition':True}
    with RECEIPT.open('x') as handle:json.dump(record,handle,indent=2)
    runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-legacy'),TOKENIZERS_PARALLELISM='false')
    runtime.pop('PYTHONPATH',None)
    outputs=[];logs=[]
    try:
        for key,(name,rev) in IDENTITIES.items():
            gpu_free()
            output=TASK/('results/knowcoder-legacy-author-'+key);outputs.append(output)
            log=TASK/('logs/knowcoder-legacy-author-'+key+'.log');logs.append(log)
            snapshot=TASK/'checkpoints/knowcoder'/('models--golaxy--'+name)/'snapshots'/rev
            if not snapshot.is_dir():raise ValueError('Pinned existing snapshot missing: '+str(snapshot))
            command=[str(ENV/'bin/python'),str(ROOT/'run_legacy.py'),'--checkpoint',key,'--snapshot-path',str(snapshot),'--output',str(output)]
            started=time.time()
            with log.open('x') as handle:
                result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,check=False,timeout=1200)
            record['checkpoints'][key]={'command':command,'returncode':result.returncode,'elapsed_seconds':time.time()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            write(RECEIPT,record)
            if result.returncode:raise RuntimeError('Legacy '+key+' process failed; retain evidence, no blind retry')
            complete=json.loads((output/'complete.json').read_text())
            if complete['completed_cells']!=15:raise ValueError('Legacy probe must return exactly15 fixed cells')
            record['checkpoints'][key]['completion']=complete
            write(RECEIPT,record)
            # Check only, never kill processes. Allow this exited process context to release.
            for _ in range(20):
                try:gpu_free();break
                except RuntimeError:time.sleep(1)
            else:raise RuntimeError('GPU context remained occupied after process exit; stop safely')
        record['status']='complete'
    except Exception as error:
        record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record['finished_at']=time.time();write(RECEIPT,record)
        index={}
        for directory in outputs:
            if directory.exists():
                for path in sorted(directory.rglob('*')):
                    if path.is_file():index[str(path.relative_to(TASK))]=hashlib.sha256(path.read_bytes()).hexdigest()
        index_path=TASK/'results/knowcoder-legacy-author-capture-index.json';write(index_path,index)
        with tarfile.open(ARCHIVE,'w:gz') as archive:
            for path in [RECEIPT,index_path,Path(__file__),TASK/'environments/knowcoder-author-setup-amendment02.json',*logs]:
                if path.exists():archive.add(path,arcname=str(path.relative_to(TASK)))
            archive.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            for directory in outputs:
                if directory.exists():archive.add(directory,arcname=str(directory.relative_to(TASK)))
        write(TASK/'results/knowcoder-legacy-author-archive.json',{'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

"""Regression tests for Transformers loading-report metadata, without model calls."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("repair", ROOT / "run_repair.py")
repair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(repair)


class MetadataTests(unittest.TestCase):
    def test_real_transformers_loading_report_empty_sets(self):
        value = {"strict_loading_report": {
            "missing_keys": set(), "unexpected_keys": set(),
            "mismatched_keys": set(), "error_msgs": [],
        }}
        normalized = repair.metadata_json(value)
        self.assertEqual(normalized["strict_loading_report"], {
            "missing_keys": [], "unexpected_keys": [],
            "mismatched_keys": [], "error_msgs": [],
        })
        self.assertEqual(json.loads(json.dumps(normalized)), normalized)

    def test_nested_sets_and_frozensets_are_deterministic(self):
        self.assertEqual(repair.metadata_json({"x": [frozenset({"z", "a"}), {"b", "a"}]}),
                         {"x": [["a", "z"], ["a", "b"]]})

    def test_unknown_type_rejected_before_file_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            with self.assertRaises(TypeError):
                repair.write(path, {"bad": object()})
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_atomic_complete_json_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "record.json"
            repair.write(path, {"missing_keys": set()})
            first = path.read_bytes()
            self.assertEqual(json.loads(first), {"missing_keys": []})
            with self.assertRaises(FileExistsError):
                repair.write(path, {"replacement": True})
            self.assertEqual(path.read_bytes(), first)
            self.assertEqual([p.name for p in Path(directory).iterdir()], ["record.json"])


if __name__ == "__main__":
    unittest.main()

"""Build a task-local GoLLIE author-code environment; preserve shared packages."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import venv

ROOT = Path('/content/jep-native-author-calibration-20261028')
ENV = ROOT / 'environments/gollie-author-flash'
LOG = ROOT / 'logs/gollie-author-setup.log'
RECEIPT = ROOT / 'environments/gollie-author-setup.json'

def run(command, env=None):
    with LOG.open('a') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, env=env)
    if result.returncode:
        raise RuntimeError('Environment command failed; retained log and exit=' + str(result.returncode))

def main():
    ROOT.mkdir(exist_ok=True)
    LOG.parent.mkdir(exist_ok=True)
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    if RECEIPT.exists():
        raise ValueError('Setup receipt exists: inspect it rather than repeating installation')
    if ENV.exists():
        raise ValueError('Environment already exists: inspect partial setup before recovery')
    start = time.time()
    record = {'status': 'started', 'environment': str(ENV), 'shared_python': sys.executable,
              'shared_packages_modified': False, 'started_at': start,
              'pins': {'transformers': '4.48.3', 'huggingface-hub': '0.28.1',
                       'tokenizers': '0.21.4', 'flash-attn': '2.8.3'}}
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
    try:
        venv.EnvBuilder(system_site_packages=True, with_pip=False).create(ENV)
        python = str(ENV / 'bin/python')
        verify = ('import sys,sysconfig; from pathlib import Path; '
                  f'assert Path(sys.prefix).resolve()==Path({str(ENV)!r}).resolve(); '
                  'assert Path(sysconfig.get_paths()["purelib"]).is_relative_to(Path(sys.prefix)); '
                  'import pip,torch; print(sys.executable,sys.prefix,torch.__version__)')
        run([python, '-c', verify])
        # Explicit target prevents pip from uninstalling or rewriting inherited packages.
        target = subprocess.check_output([python, '-c', 'import sysconfig;print(sysconfig.get_paths()["purelib"])'], text=True).strip()
        packages = ['transformers==4.48.3', 'huggingface-hub==0.28.1', 'tokenizers==0.21.4', 'ninja', 'einops']
        run([python, '-m', 'pip', 'install', '--target', target, '--no-deps', *packages])
        build_env = dict(os.environ, PYTHONNOUSERSITE='1', MAX_JOBS='4', NVCC_THREADS='2',
                         FLASH_ATTN_CUDA_ARCHS='80', TORCH_CUDA_ARCH_LIST='8.0')
        build_env.pop('PYTHONPATH', None)
        build_env['PATH'] = str(Path(target) / 'bin') + os.pathsep + str(ENV / 'bin') + os.pathsep + build_env.get('PATH', '')
        run([python, '-m', 'pip', 'install', '--target', target, '--no-deps',
             '--no-build-isolation', 'flash-attn==2.8.3'], env=build_env)
        probe = ('import sys,torch,transformers,flash_attn; '
                 'from flash_attn.flash_attn_interface import flash_attn_kvpacked_func,flash_attn_varlen_kvpacked_func; '
                 'from flash_attn.layers.rotary import apply_rotary_emb_func; '
                 'from transformers import PreTrainedModel; '
                 'from transformers.generation import GenerationMixin; '
                 'assert issubclass(PreTrainedModel,GenerationMixin); '
                 'assert transformers.__version__=="4.48.3"; '
                 'assert flash_attn.__version__=="2.8.3"; '
                 'print(sys.prefix,torch.__version__,transformers.__version__,flash_attn.__version__)')
        run([python, '-c', probe], env=build_env)
        record.update(status='ready_import_verified', elapsed_seconds=time.time()-start,
                      gpu_kernel_smoke_pending=True)
    except Exception as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error),
                      elapsed_seconds=time.time()-start)
        raise
    finally:
        record['log_sha256'] = hashlib.sha256(LOG.read_bytes()).hexdigest() if LOG.exists() else None
        RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record))

if __name__ == '__main__':
    main()

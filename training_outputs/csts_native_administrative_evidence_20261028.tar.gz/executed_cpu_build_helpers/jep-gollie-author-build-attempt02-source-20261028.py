"""Verbose same-version FlashAttention build attempt in the verified task venv."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,sysconfig
TASK=Path("/content/jep-native-author-calibration-20261028")
ENV=TASK/"environments/gollie-author-flash"
RECEIPT=TASK/"environments/gollie-author-setup-attempt02.json"
LOG=TASK/"logs/gollie-author-setup-attempt02.log"
def main():
    if RECEIPT.exists() or LOG.exists():
        raise ValueError("Attempt02 already exists; inspect it, do not blindly retry")
    python=ENV/"bin/python"
    probe="import sys,sysconfig,json;from pathlib import Path;assert Path(sys.prefix).resolve()==Path("+repr(str(ENV))+").resolve();p=Path(sysconfig.get_paths()['purelib']);assert p.is_relative_to(Path(sys.prefix));print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,'purelib':str(p)}))"
    value=subprocess.run([str(python),"-c",probe],capture_output=True,text=True,timeout=20,check=True)
    verified=json.loads(value.stdout)
    target=verified["purelib"]
    build=dict(os.environ,PYTHONNOUSERSITE="1",PIP_NO_INPUT="1",MAX_JOBS="2",NVCC_THREADS="1",FLASH_ATTENTION_FORCE_BUILD="TRUE",FLASH_ATTN_CUDA_ARCHS="80",TORCH_CUDA_ARCH_LIST="8.0")
    build.pop("PYTHONPATH",None)
    build["PATH"]=str(Path(target)/"bin")+os.pathsep+str(ENV/"bin")+os.pathsep+build.get("PATH","")
    command=[str(python),"-m","pip","install","-v","--no-cache-dir","--target",target,"--no-deps","--no-build-isolation","flash-attn==2.8.3"]
    record={"status":"started","attempt":2,"environment":verified,"shared_packages_modified":False,"package":"flash-attn==2.8.3","command":command,"flags":{k:build[k] for k in ("MAX_JOBS","NVCC_THREADS","FLASH_ATTENTION_FORCE_BUILD","FLASH_ATTN_CUDA_ARCHS","TORCH_CUDA_ARCH_LIST")},"started_at":time.time(),"previous_attempt_preserved":True}
    with RECEIPT.open("x") as handle: json.dump(record,handle,indent=2)
    try:
        with LOG.open("x") as output:
            result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env=build,cwd=TASK,check=False)
        record["build_returncode"]=result.returncode
        if result.returncode:
            raise RuntimeError("Same-version verbose build failed; retained complete compiler log")
        code="import sys,torch,transformers,flash_attn;from transformers import PreTrainedModel;from transformers.generation import GenerationMixin;from flash_attn.flash_attn_interface import flash_attn_kvpacked_func,flash_attn_varlen_kvpacked_func;from flash_attn.layers.rotary import apply_rotary_emb_func;assert transformers.__version__=='4.48.3';assert flash_attn.__version__=='2.8.3';assert issubclass(PreTrainedModel,GenerationMixin);print(sys.prefix,torch.__version__,transformers.__version__,flash_attn.__version__)"
        with LOG.open("a") as output:
            result=subprocess.run([str(python),"-c",code],stdout=output,stderr=subprocess.STDOUT,env=build,check=False)
        record["import_returncode"]=result.returncode
        if result.returncode:
            raise RuntimeError("Build completed but exact author-environment imports failed; retained log")
        record.update(status="ready_import_verified",gpu_kernel_smoke_pending=True)
    except Exception as error:
        record.update(status="failed",error_type=type(error).__name__,error=str(error))
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(LOG.read_bytes()).hexdigest() if LOG.exists() else None)
        RECEIPT.write_text(json.dumps(record,indent=2)+"\n")
        print(json.dumps(record),flush=True)
if __name__=="__main__":main()

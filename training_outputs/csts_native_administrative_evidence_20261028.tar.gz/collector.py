"""Package retained administrative evidence locally; no GPU, network or model calls."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
BASE=Path('/tmp')
OUTPUT=BASE/'jep-native-administrative-evidence-20261028.tar.gz'
entries={};provenance={};origins=[]
def add(name,data,origin,category):
    if name in entries and entries[name]!=data:raise ValueError('Conflicting evidence member')
    entries[name]=data;provenance[name]={'origin':origin,'category':category,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
# Explicitly selected local snapshots: setup/import/build/preflight, never model predictions.
selected=[]
for path in BASE.glob('jep-*'):
    if not path.is_file() or path.suffix not in {'.py','.json','.log','.txt'}:continue
    name=path.name
    source=(path.suffix=='.py' and (name.startswith('jep-colab-') or 'historical' in name or name.startswith('jep-native-kernel-state') or name=='jep-extraction-native-colab-launch-20261028.py'))
    data=(name.startswith(('jep-gollie-author-setup','jep-knowcoder-author-setup','jep-native-kernel-state','jep-triton-driver-discovery-receipt','jep-gollie-author-legacy-controller')))
    if source or data:selected.append(path)
for path in sorted(selected):
    category='operator_source_only_not_execution_proof' if path.suffix=='.py' else 'local_administrative_snapshot'
    if path.name=='jep-colab-stage-triton-driver-discovery-20261028.py':category='HELD_UNEXECUTED_alternate_cache_source'
    add(('held_unexecuted/' if category.startswith('HELD_') else 'local/')+path.name,path.read_bytes(),str(path),category)
for path,expected in [(BASE/'jep-gollie-author-build-attempt02-source-20261028.py','652beb7be6549c65b4342757ee7b4dddbd0167d3db5a8e39eedd0952d36ff03f'),(BASE/'jep-gollie-backend-repair-20261028/setup_environment.py','a3680510e5d04ff7c0a338d24f94b4e7698391f23c6ceb6bea323c8d3a689262')]:
    data=path.read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Actual failed CPU-build helper source differs')
    add('executed_cpu_build_helpers/'+path.name,data,str(path),'exact_failed_build_helper_matching_dispatch_sha256')
archives=[
 ('know_repair_metadata_v1','jep-knowcoder-repair-results-20261028.tar.gz',0),
 ('know_repair_metadata_v2','jep-knowcoder-repair-v2-results-20261028.tar.gz',0),
 ('know_legacy_cache_guard','jep-knowcoder-legacy-author-results-20261028.tar.gz',0),
 ('know_legacy_verified_success','jep-knowcoder-legacy-author-attempt02-results-20261028.tar.gz',30),
 ('go_driver_verified_success_and_prior_failures','jep-gollie-author-legacy-attempt03-results-20261028.tar.gz',None),
]
for label,filename,expected_generations in archives:
    path=BASE/filename
    if not path.exists():continue
    with tarfile.open(path) as archive:
        members=[m for m in archive.getmembers() if m.isfile()]
        count=sum(m.name.endswith('-generation.json') for m in members)
        if expected_generations is not None and count!=expected_generations:raise ValueError('Unexpected generation record count in '+filename)
        prediction_records=0
        for candidate in members:
            if candidate.name.endswith('.json') and candidate.size<1000000:
                try:value=json.loads(archive.extractfile(candidate).read())
                except (ValueError,UnicodeDecodeError):continue
                if isinstance(value,dict) and ('canonical_output' in value or 'output_token_ids' in value):prediction_records+=1
        origin={'label':label,'file':filename,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_named_generation_files':count,'source_prediction_records':prediction_records,'included_prediction_records':0};origins.append(origin)
        for member in members:
            name=member.name;leaf=Path(name).name
            if leaf.endswith(('-generation.json','-result.json')) or leaf in {'raw-batch.json','inputs.json','fixtures.json','sources.json','ordinary-requests.json'}:continue
            include=False;category=''
            if label in {'know_repair_metadata_v1','know_repair_metadata_v2','know_legacy_cache_guard'}:
                include=leaf.endswith(('.log','-worker.json','-load.json','-load-error.json')) or (leaf.endswith('.py') and '__pycache__' not in name and '/tests/' not in name and leaf not in {'Entities.py','Relations.py'})
                category='zero_generation_failed_attempt_source_or_metadata'
            elif label=='know_legacy_verified_success':
                include='environments/knowcoder-author-setup-amendment02.json' in name
                category='verified_import_receipt_resolves_prior_label_failures'
            else:
                include=('environments/triton-driver-discovery-v2/' in name or leaf in {'gollie-author-legacy-attempt02-worker.json','gollie-author-legacy-attempt02.log','gollie-author-legacy-controller.log','gollie-historical-worker-sharedgpu.py','gollie-author-legacy-attempt03-worker.json'})
                category='driver_or_preflight_failure_and_resolution_metadata'
            if include:add('archived_attempts/'+label+'/'+name,archive.extractfile(member).read(),filename+':'+name,category)
add('collector.py',Path(__file__).read_bytes(),str(Path(__file__)),'administrative_collection_source')
notes={
 'purpose':'Administrative setup/import/preflight evidence; not model prediction or quality data',
 'collection':'Built from retained local snapshots and indexed run archives; no remote jobs or model calls',
 'excluded':['environment package trees','checkpoints','caches','weights','generation/result records','raw model batches','evaluation labels'],
 'interpretation':[
  'Source files alone do not prove execution; use receipts/logs. Local snapshots can predate terminal archived receipts.',
  'Know repair v1/v2 loaded weights but failed metadata serialization before generation; both have zero generation records.',
  'Know initial author import gate incorrectly requested vllm._C; historical v0.2.2 uses distinct compiled *_ops modules.',
  'Know import amendment01 misread wheel filename suffix as metadata version; amendment02 records actual distribution/module2.3.4 and passes all imports.',
  'Go shared-runtime Flash source builds failed; logs retained. Clean task-owned Python3.10/Torch2.1cu118 environment succeeded.',
  'Know legacy first artifact guard failed on cache filename before Torch/model import; successful v5 hashes actual shard bytes.',
  'Go first author wrapper lacked cached original modeling source; next loaded models but failed Triton real-driver discovery before any generated answer.',
  'The alternate-cache driver helper v1 was HELD and NEVER EXECUTED. Actual v2 only adds a task-local read-only ldconfig -p wrapper for the real driver.',
  'A Connection-lost CLI result does not imply zero generation: Know dispatch recovery was later confirmed to run30 controls successfully. Model predictions stay in their separate archives.',
  'No shared notebook packages, unrelated GPU processes, kernels or session lifecycle were modified by this collection.'
 ],
 'source_archives':origins,'files':provenance,
}
manifest=(json.dumps(notes,indent=2,sort_keys=True)+'\n').encode();entries['manifest.json']=manifest
entries['README.txt']=('\n'.join([notes['purpose'],'',*notes['interpretation']])+'\n').encode()
with OUTPUT.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,data in sorted(entries.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
receipt={'path':str(OUTPUT),'bytes':OUTPUT.stat().st_size,'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),'files':len(entries),'indexed_files':len(provenance),'model_prediction_records_included':0,'collection_model_calls':0}
(BASE/'jep-native-administrative-evidence-20261028.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

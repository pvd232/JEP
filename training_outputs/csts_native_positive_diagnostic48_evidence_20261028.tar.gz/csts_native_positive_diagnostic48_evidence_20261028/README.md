# Primary fixed48 evidence

This archive contains only the used48 source references/audit and original two-pass review. It excludes unused80/fresh240 source/gold content, checkpoints and credentials. It does not incorporate finite7 first-generation sensitivity outcomes.

Gold and judgments are model-assisted, human-unadjudicated; two fresh review contexts share the same model alias and source-reference anchoring. Original96 pipeline cases remain the denominator. Seven empty-input harness failures per model and their stale historical Know debug context are not model answers or abstentions. Token/byte replay proves execution integrity, not semantic correctness. Intervals describe this diagnostic suite's resampling stability, not representative population accuracy or ranking.

SHA256SUMS.json hashes every included evidence file except itself. The external index binds this immutable archive and the internal index. Original raw native archives/provider/protocol/job are separate immutable artifacts already in training_outputs/.

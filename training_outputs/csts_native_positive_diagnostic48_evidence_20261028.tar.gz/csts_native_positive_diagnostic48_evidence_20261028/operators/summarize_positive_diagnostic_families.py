#!/usr/bin/env python3
"""Metadata-only fixed-suite breakdown; no model calls or source/gold text."""
import argparse
import collections
import hashlib
import json
from pathlib import Path

FAMILIES=('identity_category','color','age_gender_size','counts','action_roles','spatial','presence_negation','scope_uncertainty')
SEED='jep-native-repair-locked-canaries-20261028-v1'


def family_groups():
    return {hashlib.sha256((json.dumps([SEED,family],ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()).hexdigest():family for family in FAMILIES}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--report',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    report=json.loads((args.report/'summary.json').read_text());rows=json.loads((args.report/'candidate-results.json').read_text())
    if report.get('phase')!='locked-canaries'or report.get('capture_scope')!='locked48_diagnostic_only':raise ValueError('This formatter is only for fixed48 diagnostic results')
    groups=family_groups();models={}
    for model in('gollie','knowcoder'):
        selected=[row for row in rows if row['model']==model]
        if len(selected)!=48 or len({row['source_id']for row in selected})!=48:raise ValueError('A model lost a frozen48 denominator')
        counts=collections.Counter(groups.get(row['group_id'])for row in selected)
        if counts!={family:6 for family in FAMILIES}:raise ValueError('Fixed8x6 family coverage differs')
        families={}
        for family in FAMILIES:
            cases=[row for row in selected if groups[row['group_id']]==family]
            families[family]={'expected':6,'operationally_valid':sum(row['operational_valid']for row in cases),
                'accepted_lower':sum(row['accepted_lower']for row in cases),'accepted_upper':sum(row['accepted_upper']for row in cases),
                'source_answerability':dict(collections.Counter(row['answerability']for row in cases)),
                'operational_failures':dict(collections.Counter(row['operational_failure']for row in cases if not row['operational_valid'])),
                'criterion_successes':{key:sum(row['criteria_conjunction'][key]and not row['gold_disputed']for row in cases)
                    for key in('faithful','complete','scope_correct','binding_correct','multiplicity_correct','abstention_correct','inference_correct')}}
        models[model]=families
    value={'phase':'locked-canaries','capture_scope':'locked48_diagnostic_only','models':models,
        'statistical_scope':'Fixed suite/component resampling stability only; no representative population accuracy or ranking.',
        'semantic_qualification_passed':False,'fresh_evaluation_authorized':False,
        'method':'Two independent model-assisted contexts; no human adjudication. Same seven substantive criteria and original48 gold.',
        'summary_sha256':hashlib.sha256((args.report/'summary.json').read_bytes()).hexdigest(),
        'candidate_results_sha256':hashlib.sha256((args.report/'candidate-results.json').read_bytes()).hexdigest()}
    with args.output.open('x')as handle:json.dump(value,handle,sort_keys=True,indent=2);handle.write('\n')
    print(json.dumps({'status':'fixed8x6_family_breakdown_complete','models':list(models),'cases_per_model':48}))


if __name__=='__main__':main()

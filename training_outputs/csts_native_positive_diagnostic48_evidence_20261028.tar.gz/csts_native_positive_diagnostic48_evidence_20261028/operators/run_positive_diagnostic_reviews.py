#!/usr/bin/env python3
"""Run the approved two-pass blinded diagnostic evaluation after raw capture.

No source-gold generation or native inference; no whole-run semantic retries.
Only invoke after the sole GPU operator has returned both immutable captures.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    with path.open('x')as handle:json.dump(value,handle,sort_keys=True,indent=2);handle.write('\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in('job','provider','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--captures',nargs=2,required=True,help='gollie=DIR knowcoder=DIR')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    evaluator=ROOT/'evaluate_native.py';reviewer=ROOT/'review_native_evaluation.py';family=ROOT/'summarize_positive_diagnostic_families.py'
    env={**os.environ,'PYTHONPATH':str(args.provider)+os.pathsep+'/tmp/jep-native-tokenizer-20261028'+os.pathsep+os.environ.get('PYTHONPATH','')}
    packet=args.output/'blinded-packet'
    command=[sys.executable,str(evaluator),'prepare-reviews','--job',str(args.job),
        '--sources',str(ROOT/'locked-canaries/sources.json'),'--gold-dir',str(ROOT/'locked-canaries'),
        '--captures',*args.captures,'--output',str(packet)]
    save(args.output/'preparation-command.json',command)
    with(args.output/'preparation.log').open('x')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    receipt={'status':'RECORDED_BEFORE_TWO_INDEPENDENT_REVIEW_PASSES','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'artifacts':{path.name:sha(path)for path in(evaluator,reviewer,family,ROOT/'generate_gold.py')},
        'job_seal_sha256':sha(args.job/'job-seal.json'),'review_seal_sha256':sha(packet/'review-seal.json'),
        'raw_capture_roots':args.captures,'source_gold_generation_calls':0,'native_model_calls':0,
        'semantic_retries':0,'reviewers':['model:gpt-6.1-sol:max:native-eval-a','model:gpt-6.1-sol:max:native-eval-b'],
        'scope':'Fixed48 diagnostic; no qualification/fresh authorization; suite resampling stability only.'}
    save(args.output/'before-review-calls.json',receipt);processes=[];logs=[]
    for suffix,seed in(('a',202610281),('b',202610282)):
        output=args.output/('review-'+suffix);command=[sys.executable,str(reviewer),'--review',str(packet),'--output',str(output),
            '--reviewer-id','model:gpt-6.1-sol:max:native-eval-'+suffix,'--seed',str(seed)]
        save(args.output/('review-'+suffix+'-command.json'),command)
        log=(args.output/('review-'+suffix+'.log')).open('x');logs.append(log)
        processes.append(subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT))
    statuses=[process.wait()for process in processes]
    for log in logs:log.close()
    save(args.output/'review-process-status.json',{'exit_codes':statuses,'complete':statuses==[0,0],'automatic_whole_run_retries':False})
    if statuses!=[0,0]:
        print(json.dumps({'status':'incomplete_reviews_retained_no_complete_report','exit_codes':statuses}));return 1
    report=args.output/'report';command=[sys.executable,str(evaluator),'summarize','--review',str(packet),'--reviews',
        str(args.output/'review-a/reviews.json'),str(args.output/'review-b/reviews.json'),'--output',str(report)]
    with(args.output/'summary.log').open('x')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run([sys.executable,str(family),'--report',str(report),'--output',str(report/'family-breakdown.json')],env=env,check=True)
    save(args.output/'completion.json',{'status':'COMPLETED_FIXED48_MODEL_ASSISTED_DIAGNOSTIC','summary_sha256':sha(report/'summary.json'),
        'family_breakdown_sha256':sha(report/'family-breakdown.json'),'fresh_evaluation_authorized':False,'semantic_qualification_passed':False})
    print(json.dumps({'status':'complete','report':str(report),'cases_per_model':48,'fresh_evaluation_authorized':False}));return 0


if __name__=='__main__':sys.exit(main())

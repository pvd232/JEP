"""Construct the frozen48 source-explicit diagnostic cases; no inference calls."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path('/tmp/jep-native-repair-evaluation-20261028')
OUT=ROOT/'locked-canaries'
SEED='jep-native-repair-locked-canaries-20261028-v1'


def encoded(value):return (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):
    with path.open('xb')as handle:handle.write(encoded(value))
def fact(subject_id,subject,value,quote,predicate='requested_attribute',count=1,polarity='affirmative',support='explicit',reason='',uncertainty=''):
    return {'subject_id':subject_id,'subject':subject,'subject_count':count,'predicate':predicate,'value':value,
            'polarity':polarity,'source_quote':quote,'support':support,'support_reason':reason,'uncertainty':uncertainty}


def main():
    if OUT.exists():raise ValueError('Canary cohort exists; never overwrite')
    freeze=ROOT/'freeze-receipt.json'
    if not freeze.exists():raise ValueError('Cohort freeze must precede canary preparation')
    cases=[]
    def add(family,index,passage,condition,answer,facts,reason='',ambiguous=False,binding=False,multiplicity=False,negation=False,uncertainty=False):
        identity=sha(encoded([passage,condition]));negative=index in(5,6)
        source={'id':identity,'passage':passage,'condition':condition,'group_id':sha(encoded([SEED,family]))}
        reference={'id':identity,'expected_answer':answer,'answerability':'not_specified'if negative else'ambiguous'if ambiguous else'answered',
                   'reason':reason,'facts':facts,'opportunities':{'binding':binding,'multiplicity':multiplicity,'negation':negation,'uncertainty':uncertainty,'abstention':negative}}
        cases.append({'case_id':family+'-'+str(index),'family':family,'pattern':('minimal_supported','two_bindings','counterfactual','partial_or_uncertain','distractor_absent','empty_absent')[index-1],
                      'source':source,'reference':reference,'is_explicit_absent_target':negative})
    #1: Identity/category. Neither a generic noun nor a nearby label supplies a subtype.
    f='identity_category';c='type of vehicle'
    add(f,1,'The vehicle is a tram.',c,'The vehicle is a tram.',[fact('vehicle','the vehicle','tram','The vehicle is a tram.','type')])
    for i,a,b in((2,'tram','van'),(3,'van','tram')):
        p=f'The first vehicle is a {a}. The second vehicle is a {b}.'
        add(f,i,p,'types of vehicles',f'The first vehicle is a {a}; the second is a {b}.',[fact('first','the first vehicle',a,f'The first vehicle is a {a}.','type'),fact('second','the second vehicle',b,f'The second vehicle is a {b}.','type')],binding=True,multiplicity=True)
    add(f,4,"The first vehicle is a tram; the second vehicle's type is not stated.",'types of vehicles',"The first vehicle is a tram; the second vehicle's type is unspecified.",[fact('first','the first vehicle','tram','The first vehicle is a tram','type')],uncertainty=True)
    add(f,5,'A vehicle is red. A poster names a tram.',c,'not_specified: The vehicle subtype is not stated.',[],reason='The tram is named on a poster, not identified as this vehicle.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #2: Color. Swap assignments without changing the bag of colors.
    f='color';c='color of kite'
    add(f,1,'A kite is violet.',c,'The kite is violet.',[fact('kite','the kite','violet','A kite is violet.','color')])
    for i,a,b in((2,'violet','orange'),(3,'orange','violet')):
        p=f'The left kite is {a}; the right kite is {b}.'
        add(f,i,p,'colors of kites',f'The left kite is {a}; the right kite is {b}.',[fact('left','the left kite',a,f'The left kite is {a}','color'),fact('right','the right kite',b,f'the right kite is {b}.','color')],binding=True,multiplicity=True)
    add(f,4,"The left kite is violet; the right kite's color is not stated.",'colors of kites',"The left kite is violet; the right kite's color is unspecified.",[fact('left','the left kite','violet','The left kite is violet','color')],uncertainty=True)
    add(f,5,'Two kites hang beside a violet flag.','colors of kites','not_specified: Neither kite color is stated.',[],reason='Violet modifies the flag, not the kites.',multiplicity=True)
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #3: Age. No transfer of a nearby object's number to the child.
    f='age_gender_size';c='age of child'
    add(f,1,'The child is eight years old.',c,'The child is eight years old.',[fact('child','the child','eight years old','The child is eight years old.','age')])
    for i,a,b in((2,'eight','eleven'),(3,'eleven','eight')):
        p=f'The first child is {a} years old. The second child is {b} years old.'
        add(f,i,p,'ages of children',f'The first child is {a}; the second is {b} years old.',[fact('first','the first child',a+' years old',f'The first child is {a} years old.','age'),fact('second','the second child',b+' years old',f'The second child is {b} years old.','age')],binding=True,multiplicity=True)
    add(f,4,"The first child is eight years old. The second child's age is not stated.",'ages of children',"The first child is eight years old; the second child's age is unspecified.",[fact('first','the first child','eight years old','The first child is eight years old.','age')],uncertainty=True)
    add(f,5,'A child stands beside an eight-year-old tree.',c,'not_specified: The child age is not stated.',[],reason='Eight years describes the tree, not the child.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #4: Quantity. Explicit zero is answered; an unrelated numeral is not a count.
    f='counts';c='number of people'
    add(f,1,'There are no people in the room.',c,'There are zero people in the room.',[fact('people','people in the room','0','no people','count',count=0,support='necessary_inference',reason='Explicit absence entails a count of zero.')],multiplicity=True,negation=True)
    for i,a,b in((2,'Two','Three'),(3,'Three','Two')):
        p=f'{a} people are in the left group. {b} people are in the right group.';av=2 if a=='Two' else 3;bv=3 if b=='Three' else 2
        add(f,i,p,'number of people in each group',f'The left group has {av} people; the right group has {bv}.',[fact('left','people in the left group',str(av),f'{a} people are in the left group.','count',count=av),fact('right','people in the right group',str(bv),f'{b} people are in the right group.','count',count=bv)],binding=True,multiplicity=True)
    p='Three people sit beside several other people.'
    add(f,4,p,c,'At least five people are indicated; the exact total is unspecified.',[fact('all','all people mentioned','at least 5; exact total unspecified',p,'count',count=None,support='necessary_inference',reason='Three people plus the distinct unspecified plural other people gives a lower bound of five.',uncertainty='Exact total unspecified.')],multiplicity=True,uncertainty=True)
    add(f,5,'The number four is printed on a sign.',c,'not_specified: No people count is supplied.',[],reason='Four is text on a sign, not a count of people.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #5: Action/role. Subject assignments swap; a dog's action is not a person's.
    f='action_roles';c="person's action"
    add(f,1,'Mira carries a parcel.',c,'Mira carries a parcel.',[fact('mira','Mira','carries a parcel','Mira carries a parcel.','action')])
    for i,a,b in((2,'Mira','Teo'),(3,'Teo','Mira')):
        p=f'{a} follows {b} while {b} carries a parcel.'
        add(f,i,p,'actions of people',f'{a} follows {b}; {b} carries a parcel.',[fact(a.casefold(),a,'follows '+b,f'{a} follows {b}','action'),fact(b.casefold(),b,'carries a parcel',f'{b} carries a parcel.','action')],binding=True,multiplicity=True)
    add(f,4,'Mira carries a parcel; Teo is also present.','actions of people',"Mira carries a parcel; Teo's activity is unspecified.",[fact('mira','Mira','carries a parcel','Mira carries a parcel','action')],uncertainty=True)
    add(f,5,'A dog runs beside a closed door.',c,'not_specified: No person action is described.',[],reason='The stated action belongs to a dog.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #6: Spatial assignment and irrelevant-location distractors.
    f='spatial';c='location of lantern'
    add(f,1,'A lantern hangs above a desk.',c,'The lantern is above a desk.',[fact('lantern','the lantern','above a desk','A lantern hangs above a desk.','location')])
    for i,a,b in((2,'above a desk','below a shelf'),(3,'below a shelf','above a desk')):
        p=f'The left lantern is {a}. The right lantern is {b}.'
        add(f,i,p,'locations of lanterns',f'The left lantern is {a}; the right lantern is {b}.',[fact('left','the left lantern',a,f'The left lantern is {a}.','location'),fact('right','the right lantern',b,f'The right lantern is {b}.','location')],binding=True,multiplicity=True)
    add(f,4,"The left lantern is above a desk. The right lantern's location is not stated.",'locations of lanterns',"The left lantern is above a desk; the right lantern location is unspecified.",[fact('left','the left lantern','above a desk','The left lantern is above a desk.','location')],uncertainty=True)
    add(f,5,'The label above the desk mentions two lanterns.','locations of lanterns','not_specified: Neither lantern location is stated.',[],reason='Above the desk locates the label, not the lanterns.',multiplicity=True)
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #7: Explicit negative vs unknown, including necessary ellipsis resolution.
    f='presence_negation';c='presence of helmet on worker'
    add(f,1,'The worker is not wearing a helmet.',c,'The worker is explicitly not wearing a helmet.',[fact('worker','the worker','helmet','The worker is not wearing a helmet.','wearing',polarity='negative')],negation=True)
    p='The first worker wears a helmet. The second worker does not.'
    add(f,2,p,'presence of helmets on workers','The first worker wears a helmet; the second worker does not.',[fact('first','the first worker','helmet','The first worker wears a helmet.','wearing'),fact('second','the second worker','helmet','The second worker does not.','wearing',polarity='negative',support='necessary_inference',reason='Does not unambiguously omits wears a helmet from the preceding clause.')],binding=True,multiplicity=True,negation=True)
    p='The first worker does not wear a helmet. The second worker wears a helmet.'
    add(f,3,p,'presence of helmets on workers','The first worker does not wear a helmet; the second worker wears one.',[fact('first','the first worker','helmet','The first worker does not wear a helmet.','wearing',polarity='negative'),fact('second','the second worker','helmet','The second worker wears a helmet.','wearing')],binding=True,multiplicity=True,negation=True)
    add(f,4,"The first worker wears a helmet. Whether the second worker wears a helmet is not stated.",'presence of helmets on workers','The first worker wears a helmet; the second worker helmet status is unspecified.',[fact('first','the first worker','helmet','The first worker wears a helmet.','wearing')],uncertainty=True)
    add(f,5,'A helmet hangs beside a worker.',c,'not_specified: Whether the worker wears a helmet is not stated.',[],reason='A nearby helmet does not establish helmet use.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    #8: Requested scope and unresolved assignment, with bags excluded from clothing.
    f='scope_uncertainty';c='clothing worn'
    add(f,1,'Nora wears a coat and carries a suitcase.',c,'Nora wears a coat.',[fact('nora','Nora','coat','Nora wears a coat','wearing')])
    for i,a,b in((2,'coat','scarf'),(3,'scarf','coat')):
        p=f'Nora wears a {a}; Lian wears a {b}. Both carry bags.'
        add(f,i,p,'clothing worn by each person',f'Nora wears a {a}; Lian wears a {b}.',[fact('nora','Nora',a,f'Nora wears a {a}','wearing'),fact('lian','Lian',b,f'Lian wears a {b}.','wearing')],binding=True,multiplicity=True)
    p='Nora and Lian are two women; one of them wears a coat, but which one is unclear.'
    add(f,4,p,'clothing worn by each person','Ambiguous: one of Nora or Lian wears a coat, but the wearer is not identified.',[fact('one_of_two','one of Nora or Lian','coat','one of them wears a coat','wearing',support='necessary_inference',reason='Them refers to Nora and Lian; the statement leaves which woman unresolved.',uncertainty='Wearer is not identified.')],reason='The condition requests bindings by person, but two incompatible wearer assignments remain.',ambiguous=True,binding=True,uncertainty=True)
    add(f,5,'Nora carries a coat and a scarf.',c,'not_specified: No clothing is described as worn.',[],reason='Carrying clothing does not establish wearing it.')
    add(f,6,'',c,'not_specified: The passage is empty.',[],reason='No source information exists.')
    if len(cases)!=48 or sum(row['is_explicit_absent_target']for row in cases)!=16:raise ValueError('Canary plan counts differ')
    spec=importlib.util.spec_from_file_location('source_gold_validator',ROOT/'generate_gold.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    sources=[row['source']for row in cases];refs=[row['reference']for row in cases]
    module.validate({'references':refs},sources)
    OUT.mkdir();write(OUT/'sources.json',sources);write(OUT/'draft-reference-annotations.json',refs)
    write(OUT/'case-metadata.json',[{key:row[key]for key in('case_id','family','pattern','is_explicit_absent_target')}for row in cases])
    manifest={'status':'LOCKED_PROGRAMMATIC_MODEL_ASSISTED_CANARIES_AUDIT_PENDING','candidate_capture_authorized':False,'source_support_audit_completed':False,'seed':SEED,'sources':48,'families':8,'supported_or_supported_partial':32,'explicit_absent_targets':16,'ambiguity_cases':1,'source_explicit_zero_cases':1,'schema_inputs':['condition'],'adapter_authors_must_not_receive':['passages','gold','case-specific values'],'source_support':'Programmatically authored explicit controls with exact-quote validation; independent source-support audit still required. No human adjudication.','freeze_receipt_sha256':sha(freeze.read_bytes()),'generator_sha256':sha(Path(__file__).read_bytes()),'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':{name:sha((OUT/name).read_bytes())for name in('sources.json','draft-reference-annotations.json','case-metadata.json')}}
    write(OUT/'generation-manifest.json',manifest)
    for p in OUT.iterdir():p.chmod(0o444)
    print(json.dumps({'sources':48,'absent':16,'manifest_sha256':sha((OUT/'generation-manifest.json').read_bytes())}))


if __name__=='__main__':main()

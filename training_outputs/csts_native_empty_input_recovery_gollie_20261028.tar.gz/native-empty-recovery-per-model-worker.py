"""Seven first generations per model after mechanical empty-input validation repair; original48 untouched."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ROOT=TASK/'native-empty-input-recovery-v1-execution/native-empty-input-recovery-v1'
PROVIDER=Path('/tmp/jep-native-empty-first-generation-provider-v1-20261028')
PROTOCOL=Path('/tmp/jep-native-empty-first-generation-protocol-v2-20261028/protocol.json')
ENV=TASK/'environments/knowcoder-author-py310'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['knowcoder','gollie'],required=True);parser.add_argument('--protocol-sha256',required=True);args=parser.parse_args();model=args.model
    output=TASK/('results/native-empty-input-recovery-v1-'+model);receipt=TASK/('results/native-empty-input-recovery-v1-'+model+'-worker.json');log=TASK/('logs/native-empty-input-recovery-v1-'+model+'.log');archive=TASK/('results/native-empty-input-recovery-v1-'+model+'-execution.tar.gz')
    if any(path.exists() for path in [output,receipt,log,archive]):raise ValueError('Empty-input first-generation recovery exists; inspect, do not repeat')
    record={'status':'started','phase':'preflight','model':model,'started_at':time.time(),'sources_per_model':7,'maximum_model_calls':7,'first_generations_only':True,'automatic_retries':False,'original48_captures_unchanged':True,'fresh_count_quote_calls_authorized':False,'output_token_cap':512,'new_labeled_origin':'mechanical_empty_input_first_generation_recovery_v1'}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    selected=[]
    try:
        for previous_model in ['knowcoder','gollie']:
            previous=TASK/('results/final-native-48-v1-'+previous_model+'-worker.json')
            if json.loads(previous.read_text()).get('status')!='complete':raise RuntimeError('Original48 worker not complete')
        if model=='gollie':
            prior=TASK/'results/native-empty-input-recovery-v1-knowcoder-worker.json';deadline=time.monotonic()+1500
            record['phase']='waiting_for_recovery_know_exit';write(receipt,record)
            while not prior.exists() or json.loads(prior.read_text()).get('status') not in ('complete','failed'):
                if time.monotonic()>deadline:raise RuntimeError('Prior own seven-source recovery worker did not finish')
                time.sleep(2)
        proof_path=TASK/'empty-input-recovery-source-proof.json'
        if digest(proof_path)!='bfa2b4d39896aa98a92fc4fbec3acd49f58d47e23cd113a8fe2d3c3540e487f4':raise ValueError('Seven-source mechanical eligibility proof differs')
        proof=json.loads(proof_path.read_text())[model];selected=proof['sources']
        if len(selected)!=7 or len({s['id'] for s in selected})!=7:raise ValueError('Exactly seven unique first-generation sources required')
        original_sources=json.loads(Path('/tmp/jep-native-positive-diagnostic-job-v1-20261028/sources.json').read_text());original={s['id']:s for s in original_sources}
        original_root=TASK/'final-native-48-bridge-v1-execution'/model;manifest=json.loads((original_root/'manifest.json').read_text())
        for source in selected:
            if set(source)!={'id','passage','condition'} or source['passage']!='' or original.get(source['id'])!=source:raise ValueError('Recovery source is not an exact original empty public triple')
            capture=original_root/source['id']/'capture.json'
            if digest(capture)!=manifest['capture_artifact_sha256'][source['id']]:raise ValueError('Original zero-call capture changed')
            prior_record=json.loads(capture.read_text())
            if prior_record.get('runtime_status')!='error' or prior_record.get('model_calls')!=0 or prior_record.get('error')!='ValueError: A nonempty passage is required':raise ValueError('Generated or different original source cannot enter recovery')
        if digest(PROTOCOL)!=args.protocol_sha256:raise ValueError('Reviewed seven-only recovery protocol differs')
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if digest(setup)!='3ac4252a8f81be39bd713d70006fa13cd2dbf63f5876296ff1955f0728f25a94' or json.loads(setup.read_text()).get('status')!='ready_import_verified':raise ValueError('Canonical historical runtime differs')
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')];required=int(total*0.6)+8*1024 if model=='knowcoder' else 45*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: actual free GPU memory below reviewed budget')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONPATH=str(PROVIDER)+os.pathsep+str(ROOT),XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-empty-input-recovery'))
        if model=='gollie':
            driver_root=TASK/'environments/triton-driver-discovery-v2';driver_receipt=driver_root/'receipt.json';driver=json.loads(driver_receipt.read_text())
            if digest(driver_receipt)!='4e67a2813087b42714d618ad55f733645489450096c7af3a58f16cdd544dbbd7' or digest(driver_root/'bin/ldconfig')!=driver['wrapper_sha256'] or driver['status']!='ready_cpu_discovery_verified':raise ValueError('Reviewed Go driver-discovery differs')
            runtime['PATH']=str(driver_root/'bin')+os.pathsep+runtime.get('PATH','')
            audit=TASK/'results/gollie-pinned-artifact-audit-20261028.json'
            if digest(audit)!='8caeb672bc09a34767369c27a10eb6127791062f037f53cd2827a9f1b6095418' or json.loads(audit.read_text()).get('status')!='verified':raise ValueError('Verified Go primary-byte audit differs')
        command=[str(ENV/'bin/python'),'-m','run_empty_recovery','--model',model,'--protocol',str(PROTOCOL),'--output',str(output)]
        record.update(phase='model_capture',command=command,protocol_sha256=args.protocol_sha256,source_proof_sha256=digest(proof_path));write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        summary=json.loads((output/'summary.json').read_text()) if(output/'summary.json').exists() else None;record['summary']=summary
        if result.returncode or summary is None:raise RuntimeError('Seven-source recovery incomplete; all raw errors/unrun records retained')
        if summary.get('planned_sources',summary.get('sources'))!=7 or not 0<=summary.get('model_calls',8)<=7:raise RuntimeError('Recovery source/call budget differs')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=digest(log) if log.exists() else None);write(receipt,record)
        index={str(path.relative_to(TASK)):digest(path) for path in sorted(output.rglob('*')) if path.is_file()} if output.exists() else {}
        index_path=TASK/('results/native-empty-input-recovery-v1-'+model+'-execution-index.json');write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__),TASK/'native-empty-input-recovery-v1-launch.claim',TASK/'native-empty-input-recovery-dispatch-inputs.json',TASK/'native-empty-input-recovery-stage-dispatch.py',TASK/'empty-input-recovery-source-proof.json',TASK/'environments/knowcoder-author-setup-amendment02.json',TASK/'environments/triton-driver-discovery-v2/receipt.json',TASK/'results/gollie-pinned-artifact-audit-20261028.json']:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            for path in [ROOT,PROVIDER,PROTOCOL.parent]:
                if path.exists():tf.add(path,arcname='inputs/'+path.name)
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
            for source in selected:
                previous=TASK/'final-native-48-bridge-v1-execution'/model/source['id']
                if previous.exists():tf.add(previous,arcname='original48-zero-call/'+model+'/'+source['id'])
        write(TASK/('results/native-empty-input-recovery-v1-'+model+'-execution-archive.json'),{'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'status':record['status'],'capture_files':len(index)})
        print(json.dumps({key:value for key,value in record.items() if key!='traceback'}),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

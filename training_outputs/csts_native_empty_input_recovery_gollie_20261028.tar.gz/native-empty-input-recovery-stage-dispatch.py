__import__('os').mkdir('/content/jep-native-author-calibration-20261028/native-empty-input-recovery-v1-launch.claim')
if not __debug__:raise RuntimeError('Optimized Python is forbidden: reviewed authorization assertions must execute')
def _jep_empty_input_recovery_single_dispatch_20261028():
    from pathlib import Path,PurePosixPath
    import hashlib,json,os,subprocess,sys,tarfile,time,traceback
    task=Path('/content/jep-native-author-calibration-20261028');claim=task/'native-empty-input-recovery-v1-launch.claim';receipt=claim/'deployment.json'
    record={'status':'preparing','started_at':time.time(),'models':{},'sources_per_model':7,'maximum_calls_per_model':7,'first_generations_only':True,'automatic_retries':False,'original48_captures_unchanged':True,'exclusive_top_level_claim_acquired':True,'fresh_count_quote_calls_authorized':False}
    with receipt.open('x') as out:json.dump(record,out)
    try:
        metadata_path=task/'native-empty-input-recovery-dispatch-inputs.json';metadata=json.loads(metadata_path.read_text());record['dispatch_inputs_sha256']=hashlib.sha256(metadata_path.read_bytes()).hexdigest()
        worker_sha='17cedf842a52f3093a08af9586f53839d9b996e2211812d35a127bee4e41a1de';protocol_sha='553ab4a7c2ad5f82520a296d33dbd0c5af5908f2cbb7c02c5249c73954f56b89'
        assert metadata['worker_sha256']==worker_sha and metadata['protocol_sha256']==protocol_sha,'Reviewed recovery worker/protocol differs'
        proof=task/'empty-input-recovery-source-proof.json';assert hashlib.sha256(proof.read_bytes()).hexdigest()=='bfa2b4d39896aa98a92fc4fbec3acd49f58d47e23cd113a8fe2d3c3540e487f4','Independent seven-source proof differs'
        bundle=Path('/content/jep-native-empty-input-recovery-v1-combined-bundle-20261028.tar.gz');bundle_sha='1a4667f42db166e7cf535748f3b79511ea7df894b80872f50f422589ead1f3f3'
        assert hashlib.sha256(bundle.read_bytes()).hexdigest()==bundle_sha and metadata['bundle_sha256']==bundle_sha,'Combined reviewed recovery bundle differs'
        expected={'provider':'/tmp/jep-native-empty-first-generation-provider-v1-20261028','protocol':'/tmp/jep-native-empty-first-generation-protocol-v2-20261028','driver':str(task/'native-empty-input-recovery-v1-execution/native-empty-input-recovery-v1')}
        for model in ['knowcoder','gollie']:
            prior=task/('results/final-native-48-v1-'+model+'-worker.json');assert json.loads(prior.read_text())['status']=='complete','Original48 workers must be terminal'
        pending=[]
        with tarfile.open(bundle) as archive:
            manifest_bytes=archive.extractfile('combined-manifest.json').read();assert hashlib.sha256(manifest_bytes).hexdigest()=='9a7c736bfda75a6f84d2a8a38e77a4e7a321c7f32d7d1eb31a65523e90c50538','Reviewed component manifest differs'
            manifest=json.loads(manifest_bytes);assert set(manifest['components'])==set(expected),'Combined component roles differ'
            expected_members={'combined-manifest.json'}
            for role,destination in expected.items():
                component=manifest['components'][role];assert component['destination']==destination,'Exact reviewed stable destination differs'
                target=Path(destination);assert not target.exists(),'Fresh recovery root required; existing paths preserved'
                for relative,sha in component['files'].items():
                    rel=PurePosixPath(relative);assert not rel.is_absolute() and '..' not in rel.parts,'Unsafe reviewed member path'
                    name=component['archive_root']+'/'+relative;member=archive.getmember(name);assert member.isfile(),'Only regular reviewed component files are staged'
                    data=archive.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==sha,'Reviewed component file differs'
                    pending.append((target/relative,data));expected_members.add(name)
            assert {m.name for m in archive.getmembers() if m.isfile()}==expected_members,'Combined bundle has undeclared files'
        for destination in expected.values():Path(destination).mkdir(parents=True,exist_ok=False)
        for path,data in pending:
            path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb') as out:out.write(data)
        thin=Path(expected['driver']);protocol=Path(expected['protocol'])/'protocol.json';assert hashlib.sha256(protocol.read_bytes()).hexdigest()==protocol_sha,'Combined seven-only recovery protocol differs'
        selected=json.loads((thin/'sources.json').read_text());eligible=json.loads(proof.read_text())['knowcoder']['sources'];assert len(selected)==7 and {s['id']:s for s in selected}=={s['id']:s for s in eligible},'Only exact original seven empty source triples permitted'
        worker=task/'native-empty-recovery-per-model-worker.py';assert hashlib.sha256(worker.read_bytes()).hexdigest()==worker_sha,'Uploaded outer worker differs'
        record.update(bundle_sha256=bundle_sha,component_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest())
        for model in ['knowcoder','gollie']:
            dispatch=task/('native-empty-input-recovery-v1-'+model+'-dispatch.json');assert not dispatch.exists() and not(task/('results/native-empty-input-recovery-v1-'+model+'-worker.json')).exists(),'Seven-source recovery attempt exists'
            row={'status':'prepared','model':model,'worker_sha256':worker_sha,'protocol_sha256':protocol_sha,'sources':7,'maximum_model_calls':7,'first_generations_only':True,'automatic_retries':False}
            with dispatch.open('x') as out:json.dump(row,out)
            log=task/('logs/native-empty-input-recovery-v1-'+model+'-controller.log');command=[sys.executable,str(worker),'--model',model,'--protocol-sha256',protocol_sha]
            with log.open('x') as out:process=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,cwd=task,start_new_session=True,env=dict(os.environ))
            row.update(status='dispatched',pid=process.pid,log=str(log),model_worker_started=True);dispatch.write_text(json.dumps(row,indent=2)+'\n');record['models'][model]=row;receipt.write_text(json.dumps(record,indent=2)+'\n')
        record.update(status='dispatched',models_sequential=True)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({key:value for key,value in record.items() if key!='traceback'}),flush=True)
_jep_empty_input_recovery_single_dispatch_20261028()
del _jep_empty_input_recovery_single_dispatch_20261028

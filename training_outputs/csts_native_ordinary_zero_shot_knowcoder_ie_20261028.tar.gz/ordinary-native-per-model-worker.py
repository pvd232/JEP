"""One approved ordinary9 capture process, with independent per-model receipts."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ROOT=TASK/'ordinary-native-capture-v3-execution/ordinary-native-capture-v3'
ENV=TASK/'environments/knowcoder-author-py310'
def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['knowcoder_ie','gollie'],required=True);args=parser.parse_args();model=args.model
    output=TASK/('results/ordinary-native-v3-'+model)
    receipt=TASK/('results/ordinary-native-v3-'+model+'-worker.json')
    log=TASK/('logs/ordinary-native-v3-'+model+'.log')
    archive=TASK/('results/ordinary-native-v3-'+model+'-execution.tar.gz')
    if any(p.exists() for p in [receipt,output,log,archive]):raise ValueError('Per-model attempt already exists: inspect, do not repeat')
    record={'status':'started','phase':'preflight','started_at':time.time(),'model':model,'ordinary_cases':9,'reference_companions':2 if model=='knowcoder_ie' else 0,'output_token_cap':512,'no_counts_negatives_locked_or_fresh':True,'representative_quality_score':False,'primary_outputs_unchanged':True}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    try:
        prior_go_dispatch=TASK/'gollie-author-legacy-attempt03-dispatch.json'
        prior_go=TASK/'results/gollie-author-legacy-attempt03-worker.json'
        if prior_go_dispatch.exists():
            record['phase']='waiting_for_prior_go_exit';write(receipt,record)
            deadline=time.monotonic()+1500
            while not prior_go.exists() or json.loads(prior_go.read_text())['status'] not in ('complete','failed'):
                if time.monotonic()>deadline:raise RuntimeError('Prior Go worker did not finish; no overlapping model capture')
                time.sleep(2)
        if model=='gollie':
            preceding=TASK/'results/ordinary-native-v3-knowcoder_ie-worker.json'
            if (TASK/'ordinary-native-v3-knowcoder_ie-dispatch.json').exists():
                record['phase']='waiting_for_ordinary_know_exit';write(receipt,record)
                deadline=time.monotonic()+1500
                while not preceding.exists() or json.loads(preceding.read_text())['status'] not in ('complete','failed'):
                    if time.monotonic()>deadline:raise RuntimeError('Prior Know ordinary worker did not finish; no overlapping model capture')
                    time.sleep(2)
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if json.loads(setup.read_text())['status']!='ready_import_verified':raise ValueError('Verified historical environment not ready')
        if model=='knowcoder_ie':
            control=TASK/'results/knowcoder-legacy-author-attempt02-worker.json'
            snapshot=TASK/'checkpoints/knowcoder/models--golaxy--KnowCoder-7B-IE/snapshots/90ba076763dfb2e9efefd84a0e599f15ae533597'
        else:
            control=TASK/'results/gollie-author-legacy-attempt03-worker.json'
            from huggingface_hub.constants import HF_HUB_CACHE
            snapshot=Path(HF_HUB_CACHE)/'models--HiTZ--GoLLIE-7B/snapshots/d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9'
        if json.loads(control.read_text())['status']!='complete':raise ValueError('This model backend controls not complete')
        record['backend_controls_receipt_sha256']=hashlib.sha256(control.read_bytes()).hexdigest()
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')]
        required=int(total*0.6)+8*1024 if model=='knowcoder_ie' else 45*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True,'gpu_memory_utilization':0.6 if model=='knowcoder_ie' else None};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: insufficient actual free GPU memory')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-legacy-ordinary'),TOKENIZERS_PARALLELISM='false');runtime.pop('PYTHONPATH',None)
        if model=='gollie':
            driver_receipt=TASK/'environments/triton-driver-discovery-v2/receipt.json';driver=json.loads(driver_receipt.read_text());bins=Path(driver['path_prefix'])
            if driver['status']!='ready_cpu_discovery_verified' or bins!=TASK/'environments/triton-driver-discovery-v2/bin' or hashlib.sha256((bins/'ldconfig').read_bytes()).hexdigest()!=driver['wrapper_sha256']:raise ValueError('Reviewed driver discovery differs')
            runtime['PATH']=str(bins)+os.pathsep+runtime.get('PATH','');record['driver_discovery_receipt_sha256']=hashlib.sha256(driver_receipt.read_bytes()).hexdigest()
        command=[str(ENV/'bin/python'),str(ROOT/'run_capture.py'),'--model',model,'--snapshot',str(snapshot),'--output',str(output)]
        record.update(phase='model_capture',command=command);write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        complete=json.loads((output/'complete.json').read_text()) if (output/'complete.json').exists() else None
        record['completion']=complete
        if result.returncode or not complete or complete.get('status')!='completed':raise RuntimeError('Approved ordinary capture failed; exact log/raw partial outputs retained')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest() if log.exists() else None);write(receipt,record)
        index={str(p.relative_to(TASK)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(output.rglob('*')) if p.is_file()} if output.exists() else {}
        index_path=TASK/('results/ordinary-native-v3-'+model+'-execution-index.json');write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__)]:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():tf.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
        write(TASK/('results/ordinary-native-v3-'+model+'-execution-archive.json'),{'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

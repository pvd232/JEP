"""Fake-backend dispatch/provenance checks; no model capability claims."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

from native_adapter.schema import compile_condition,implementation_identity
from native_adapter.normalize import normalize_native,normalize_stages
import finite_count_capture as api
from run_count_gate import run

ROOT=Path(__file__).resolve().parent
PACKET=api.approved_packet()
GOLD={row['source_id']:row for row in json.loads((ROOT/'count_reference_fixture.json').read_text())['cases']}
TOKEN_COUNTS={request['prompt']:request['input_tokens'] for row in PACKET['items'] for request in row['requests']['knowcoder'].values()}


class FakeSession:
    malformed=False;truncated=False;raises=False;oversize=False
    def __init__(self):self.calls=0;self.metadata={'fake_backend':True};self.last_raw=None
    def count_tokens(self,prompt):return 9999 if self.oversize else TOKEN_COUNTS.get(prompt,100)
    def generate(self,bound):
        self.calls+=1
        if self.raises:
            self.last_raw={'text':'partial API response','token_ids':[99]};raise RuntimeError('fake backend failure')
        source=bound['finite_count_development']['source_id'];stage=bound['count_stage']
        payload=GOLD[source]['expected_native_stages'][bound['model']][stage]
        if self.malformed and stage=='mentions':payload='malformed['
        return {'payload':payload,'truncated':self.truncated and stage=='mentions',
                'input_token_ids':[1]*bound['input_tokens'],'output_token_ids':[99]}


class FakeRuntime:
    _LOCK=threading.RLock()
    compile_condition=staticmethod(compile_condition)
    implementation_identity=staticmethod(implementation_identity)
    normalize_native=staticmethod(normalize_native)
    normalize_stages=staticmethod(normalize_stages)
    def __init__(self):self.session=None;self.session_creations=0
    def _verify_support(self,cfg):
        if cfg['support_manifest_sha256']!='a'*64:raise ValueError('fake support seal mismatch')
    def _session(self,model,cfg):
        if self.session is None:self.session=FakeSession();self.session_creations+=1
        return self.session


def protocol(model='knowcoder'):
    return {'models':{model:{'handler':{'module':'finite_count_capture','callable':'capture_one','sha256':api.support_identity()['handler_sha256']},
        'max_model_calls_per_source':3,'native_capture':{
            'profile':'positive_anchor','max_new_tokens':512,'context_limit':2048 if model=='knowcoder' else 16384,
            'compiler_implementation_files':implementation_identity(),'compiler_implementation_sha256':api.digest(api.encoded(implementation_identity())),'support_manifest_sha256':'a'*64,
            'finite_count_development':api.authorization(),
            'generation':{'do_sample':False,'num_beams':1,'num_return_sequences':1,'gpu_memory_utilization':0.6,'max_num_seqs':4}}}}}


def source(index=0):
    row=PACKET['items'][index]
    return {'id':row['source_id'],'passage':row['passage'],'condition':row['condition']}


class FiniteCountTests(unittest.TestCase):
    def setUp(self):
        self.runtime=FakeRuntime();self.provider=patch.object(api,'RUNTIME_PROVIDER',lambda:self.runtime);self.provider.start();self.addCleanup(self.provider.stop)
        FakeSession.malformed=FakeSession.truncated=FakeSession.raises=FakeSession.oversize=False

    def test_exact_approved_source_runs_each_stage_once_and_preserves_lower_bound(self):
        result=api.capture_one(source(),'knowcoder',protocol())
        self.assertEqual(result['runtime_status'],'ok')
        self.assertEqual(result['model_calls'],3)
        self.assertEqual([r['stage'] for r in result['stage_outputs']],list(api.STAGES))
        self.assertTrue(result['bound_input_verified'])
        self.assertEqual(result['normalized_evidence']['quantity']['lower'],4)
        self.assertEqual(result['normalized_evidence']['quantity']['kind'],'lower_bound')
        self.assertFalse(result['model_quality_passed'])
        self.assertFalse(result['coverage_complete'])

    def test_go_uses_its_actual_counter_and_same_fixed_stage_allowlist(self):
        result=api.capture_one(source(),'gollie',protocol('gollie'))
        self.assertEqual(result['model_calls'],3);self.assertTrue(result['parse_valid'])
        self.assertEqual(result['prepared_inputs'][0]['context_limit'],16384)
        self.assertEqual(result['prepared_inputs'][0]['input_tokens'],100)

    def test_whitelist_text_authorization_and_helper_changes_make_zero_calls(self):
        variants=[]
        wrong=source();wrong['id']='new-or-locked-source';variants.append((wrong,protocol()))
        wrong=source();wrong['passage']+=' changed';variants.append((wrong,protocol()))
        wrong=protocol();wrong['models']['knowcoder']['native_capture']['finite_count_development']['production_count_dispatch_enabled']=True;variants.append((source(),wrong))
        wrong=protocol();wrong['models']['knowcoder']['native_capture']['compiler_implementation_files']['counts.py']='0'*64;variants.append((source(),wrong))
        for candidate,p in variants:
            with self.subTest(candidate=candidate,p=p):
                result=api.capture_one(candidate,'knowcoder',p)
                self.assertEqual(result['model_calls'],0);self.assertIsNone(result['raw_output'])
                self.assertFalse(result['route_supported']);self.assertEqual(len(result['stage_outputs']),3)
        self.assertEqual(self.runtime.session_creations,0)

    def test_actual_token_budget_and_request_assertion_checked_before_generation(self):
        FakeSession.oversize=True
        result=api.capture_one(source(),'knowcoder',protocol())
        self.assertEqual(result['model_calls'],0)
        self.assertIn('token budget',result['error'])
        FakeSession.oversize=False
        asserted=source();asserted['inference_requests']=[{'prompt':'injected'}]
        result=api.capture_one(asserted,'knowcoder',protocol())
        self.assertEqual(result['model_calls'],0)
        self.assertIn('assertions differ',result['error'])

    def test_parse_failure_does_not_retry_or_suppress_independent_remaining_stages(self):
        FakeSession.malformed=True
        result=api.capture_one(source(),'knowcoder',protocol())
        self.assertEqual(result['model_calls'],3)
        self.assertEqual([r['parse_valid'] for r in result['stage_outputs']],[False,True,True])
        self.assertIn('malformed[',result['raw_output'])
        self.assertIsNone(result['normalized_evidence'])

    def test_truncation_is_retained_and_independent_stages_continue(self):
        FakeSession.truncated=True
        result=api.capture_one(source(),'knowcoder',protocol())
        self.assertEqual(result['runtime_status'],'truncated');self.assertEqual(result['model_calls'],3)
        self.assertEqual(len(result['stage_outputs']),3);self.assertFalse(result['parse_valid'])

    def test_backend_error_has_no_retry_and_retains_unrun_stage_denominators(self):
        FakeSession.raises=True
        result=api.capture_one(source(),'knowcoder',protocol())
        self.assertEqual(result['model_calls'],1)
        self.assertEqual([r['runtime_status'] for r in result['stage_outputs']],['error','not_run','not_run'])
        self.assertEqual(result['stage_outputs'][0]['raw_backend_error_response']['token_ids'],[99])
        self.assertIsNone(result['raw_output'])

    def test_bound_tamper_is_rejected_without_general_count_enable(self):
        p=protocol();s=source();session=FakeSession()
        bound=api.bound_count_stage(s,'knowcoder',p,'mentions',session.count_tokens,self.runtime)
        bound['prompt']+=' changed'
        with self.assertRaisesRegex(ValueError,'binding changed'):
            api.verify_count_bound(bound,s,'knowcoder',p,session.count_tokens,self.runtime)
        from native_adapter.schema import bounded_input
        with self.assertRaisesRegex(ValueError,'dispatch is disabled'):
            bounded_input(compile_condition(s['condition']),'knowcoder',s['passage'],session.count_tokens,count_stage='mentions')

    def test_driver_runs_fixed_six_by_three_and_cannot_resume_or_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'capture'
            summary=run('knowcoder',protocol(),target)
            self.assertEqual(summary['model_calls'],18);self.assertEqual(summary['planned_stage_slots'],18)
            self.assertEqual(summary['valid_stage_slots'],18)
            self.assertFalse(summary['production_count_dispatch_enabled'])
            self.assertEqual(len(list(target.glob('*/attempt.json'))),6)
            with self.assertRaises(FileExistsError):run('knowcoder',protocol(),target)
            self.assertEqual(self.runtime.session.calls,18)

    def test_packet_byte_mutation_is_rejected_before_session(self):
        p=protocol();s=source()
        original=Path.read_bytes
        def changed(path):return original(path)+b' ' if path.name=='approved_count_inputs.json' else original(path)
        with patch.object(Path,'read_bytes',changed):
            result=api.capture_one(s,'knowcoder',p)
            self.assertEqual(result['model_calls'],0);self.assertIn('packet changed',result['error'])
        self.assertEqual(self.runtime.session_creations,0)


if __name__=='__main__':unittest.main()

# Finite exposed count-stage capture

This operator runs exactly the six reviewed exposed count cases, with three independent native tasks each: mentions/quantity phrases, quantity bindings, and identity. It does not enable production counting, grant a passed model-quality gate or read locked/fresh sources. The approved packet contains inputs/prompts only. References are a unit-test fixture and never read by the capture handler.

The package keeps all scope-v5 compiler bytes except the separately reviewed outer-whitespace parser amendment (normalizer SHA91ba2e447c35aee60b275c5cac5870d14dc1afcd1748da74c5bdda92947a2442). General bounded_input still rejects every count request. The finite handler verifies the exact approved packet SHA, six source IDs, original text/condition, plan, all helper bytes, fixed positive profile, three stages,512-token budget and actual backend tokenizer count. A bound request also identifies this finite handler, packet, source and stage. The Know count must equal the independently tokenized packet; Go receives its actual runtime count. No input truncation or semantic repair occurs.

Use the sealed `native_capture` runtime package from the native backend owner on PYTHONPATH. Its config still pins checkpoint/tokenizer/snapshot/backend/dtype/runtime receipts and support files. Configure `protocol.models[model]` as follows, retaining the actual native runtime config:

```python
identity = finite_count_capture.support_identity()
protocol = {"models": {model: {
    "handler": {"module": "finite_count_capture", "callable": "capture_one",
                "sha256": identity["handler_sha256"]},
    "max_model_calls_per_source": 3,
    "native_capture": {
        **sealed_runtime_config,
        "compiler_implementation_sha256": identity["compiler_implementation_sha256"],
        "compiler_implementation_files": identity["compiler_implementation_files"],
        "profile": "positive_anchor", "max_new_tokens": 512,
        "finite_count_development": finite_count_capture.authorization(),
    },
}}}
```

No count capability receipt is fabricated. The authorization is development-only and exact; source or stage overrides are rejected. The runtime package must contain the same whitespace-amended scope-v5 core. The handler calls only its verified support/session/backend primitives; it does not monkeypatch the general compiler or runtime.

```sh
python3 run_count_gate.py --model knowcoder --protocol frozen-count-protocol.json --output new-count-capture
python3 run_count_gate.py --model gollie --protocol frozen-count-protocol.json --output another-new-count-capture
```

Run one model per process. The output directory must be new, each source is durably claimed before capture, and overwrite/resume is refused. Each of the18 stage slots remains in the denominator. Parse failures and truncations retain raw output and do not suppress independent remaining tasks. Runtime/backend exceptions stop subsequent stages and retain unrun slots. There are no retries, companions, fallback outputs, or automatic replacement sources. The backend lazily loads weights only when its first actual request is generated.

Result fields match the general callback's operational contract, with development authorization and explicit unapproved-quality flags. Bound inputs/raw tokens, per-stage output/errors and backend metadata are retained. Final merging requires all three valid stages and keeps coverage/semantic support false. Proposed conditional lower bounds4/2/2/1/unknown/2 are not complete scene totals. Empirical fidelity and any later capability approval are separate from these operator tests.

CPU-only fake-backend tests: `python3 -m unittest discover -s . -p 'test_*.py' -q`. These tests establish whitelist/cap/binding/denominator behavior, not real model performance. No model was loaded or called during preparation.

"""Run the exact finite count gate once into a new durable output directory."""
import argparse
import json
from pathlib import Path

import finite_count_capture as capture


def write_once(path,value):
    with path.open('x') as handle:json.dump(value,handle,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False);handle.write('\n')


def run(model,protocol,output):
    # Preflight every source and all static identities before making any call.
    api=capture.RUNTIME_PROVIDER();packet=capture.approved_packet();sources=[]
    for row in packet['items']:
        source={'id':row['source_id'],'passage':row['passage'],'condition':row['condition']}
        capture._verify_configuration(source,model,protocol,api);sources.append(source)
    output=Path(output);output.mkdir(exist_ok=False)
    write_once(output/'protocol.json',protocol)
    write_once(output/'finite_authorization.json',capture.authorization())
    results=[]
    for index,source in enumerate(sources):
        folder=output/('%02d'%index+'-'+source['id']);folder.mkdir()
        write_once(folder/'attempt.json',{'source':source,'protocol_sha256':capture.digest(capture.encoded(protocol)),
                                        'source_claimed_once':True,'no_resume_or_retry':True})
        result=capture.capture_one(source,model,protocol);write_once(folder/'result.json',result);results.append(result)
    summary={'sources':6,'planned_stage_slots':18,'model_calls':sum(row['model_calls'] for row in results),
             'operationally_complete_sources':sum(row['runtime_status']=='ok' and row['parse_valid'] for row in results),
             'valid_stage_slots':sum(stage['parse_valid'] for row in results for stage in row['stage_outputs']),
             'failed_or_unrun_stage_slots':sum(not stage['parse_valid'] for row in results for stage in row['stage_outputs']),
             'model_quality_passed':False,'production_count_dispatch_enabled':False,'coverage_complete':False,
             'semantic_support_validated':False,'fixed_denominator':True}
    write_once(output/'summary.json',summary);return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=('knowcoder','gollie'),required=True)
    parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();protocol=json.loads(args.protocol.read_text())
    print(json.dumps(run(args.model,protocol,args.output),sort_keys=True))


if __name__=='__main__':main()

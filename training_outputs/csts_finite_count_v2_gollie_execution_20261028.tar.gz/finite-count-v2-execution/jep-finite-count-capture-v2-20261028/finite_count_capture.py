"""Inference-only handler for exactly six reviewed exposed count-stage canaries.

This does not enable production counts or assert a passed model capability. The
approved public packet contains inputs/prompts, never reference annotations.
Runtime loading/tokenization/generation comes from the separately sealed native
capture backend. This module adds a finite source/stage authorization boundary
without changing or monkeypatching the compiler's general count-dispatch block.
"""
from __future__ import annotations

import hashlib
import importlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PACKET_SHA256='f2b9b77008f724ba922e064bac2769c109cff48cf76e63eae0f96332f2960ac7'
NORMALIZER_WHITESPACE_SHA256='91ba2e447c35aee60b275c5cac5870d14dc1afcd1748da74c5bdda92947a2442'
STAGES=('mentions','quantity_bindings','identity')
SOURCE_IDS=(
 '0a7d36e084bd22ea9dc3c763c84b3c2bbbc7e37f7876d3971665079e307a0a9e',
 '11c0d8914453aec9c3b5364f1acb3f28293bdf2f727791568aa72df1f1a2d84e',
 '7507127642c646106a0ede6e36b0c349ae5c7ae184fbcc3ceb7fe8cda9a355be',
 'b2a6650564ccf6aa6ff9bca716fdbc30fab8a17c2848eb3446547d29ac22eb29',
 '3165c2eace681157890fd25ee5c9a441c2dbea2abc7fd49492a56f16f6803670',
 '929a87372d3bad3712d71e2e02cb9751f1f39e266c26222d1f0838ab9a140cd8',
)
RUNTIME_PROVIDER=lambda:importlib.import_module('native_capture')


def digest(value):return hashlib.sha256(value).hexdigest()
def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def authorization():
    return {'purpose':'six_exposed_count_stage_canaries_v1','packet_sha256':PACKET_SHA256,
            'source_ids':list(SOURCE_IDS),'stage_order':list(STAGES),
            'model_calls_per_source':3,'planned_stage_slots_per_model':18,
            'model_quality_passed':False,'production_count_dispatch_enabled':False,
            'coverage_complete':False,'parser_amendment':'outer_whitespace_v1',
            'normalizer_sha256':NORMALIZER_WHITESPACE_SHA256}


def approved_packet():
    raw=(ROOT/'approved_count_inputs.json').read_bytes()
    if digest(raw)!=PACKET_SHA256:raise ValueError('Reviewed finite count input packet changed')
    packet=json.loads(raw)
    if tuple(item['source_id'] for item in packet['items'])!=SOURCE_IDS:
        raise ValueError('Finite count source inventory changed')
    return packet


def support_identity():
    packet=approved_packet()
    compiler=dict(packet['items'][0]['requests']['knowcoder']['mentions']['implementation_sha256'])
    compiler['normalize.py']=NORMALIZER_WHITESPACE_SHA256
    return {'handler_sha256':digest(Path(__file__).read_bytes()),'packet_sha256':PACKET_SHA256,
            'compiler_implementation_files':compiler,'compiler_implementation_sha256':digest(encoded(compiler)),
            'authorization':authorization()}


def _approved_source(source):
    if not isinstance(source,dict) or set(source)-{'id','passage','condition','plan','inference_requests'}:
        raise ValueError('Finite count handler accepts only the source projection/assertions')
    rows={row['source_id']:row for row in approved_packet()['items']}
    if source.get('id') not in rows:raise ValueError('Source is outside the six exposed count canaries')
    row=rows[source['id']]
    if any(source.get(key)!=row[key] for key in ('passage','condition')):
        raise ValueError('Approved count source text or condition changed')
    if 'plan' in source and source['plan']!=row['plan']:raise ValueError('Supplied count plan differs')
    return row


def _verify_configuration(source,model,protocol,api):
    row=_approved_source(source)
    if model not in {'knowcoder','gollie'}:raise ValueError('Unknown native grammar')
    descriptor=protocol['models'][model];cfg=descriptor['native_capture']
    handler=descriptor['handler']
    if handler!={'module':'finite_count_capture','callable':'capture_one','sha256':digest(Path(__file__).read_bytes())}:
        raise ValueError('Finite handler identity differs')
    if descriptor['max_model_calls_per_source']!=3 or type(descriptor['max_model_calls_per_source']) is not int:
        raise ValueError('Finite count protocol requires exactly three stage slots per source')
    if cfg.get('finite_count_development')!=authorization():raise ValueError('Finite count authorization differs')
    if cfg['profile']!='positive_anchor' or cfg['max_new_tokens']!=512 or type(cfg['max_new_tokens']) is not int:
        raise ValueError('Count canary profile/budget differs')
    if cfg['context_limit']!=(2048 if model=='knowcoder' else 16384):raise ValueError('Context bound differs')
    if cfg.get('stage_overrides') not in (None,{}):raise ValueError('Finite count stages have no output/profile overrides')
    expected=dict(row['requests'][model]['mentions']['implementation_sha256'])
    expected['normalize.py']=NORMALIZER_WHITESPACE_SHA256
    if api.implementation_identity()!=expected or cfg['compiler_implementation_files']!=expected or cfg['compiler_implementation_sha256']!=digest(encoded(expected)):
        raise ValueError('Approved count compiler/helper bytes changed')
    api._verify_support(cfg)
    plan=api.compile_condition(source['condition'])
    if plan!=row['plan'] or list(plan['aggregation']['stages'])!=list(STAGES):
        raise ValueError('Condition-only count plan changed')
    expected_generation={'do_sample':False,'num_beams':1,'num_return_sequences':1}
    if any(cfg['generation'].get(key)!=value for key,value in expected_generation.items()):
        raise ValueError('Count canary requires one greedy native sequence')
    if model=='knowcoder' and (cfg['generation'].get('gpu_memory_utilization')!=0.6 or cfg['generation'].get('max_num_seqs')!=4):
        raise ValueError('Know resource controls differ')
    return row,plan,cfg


def bound_count_stage(source,model,protocol,stage,count_tokens,api=None):
    """Bind one exact authorized stage using the backend's actual tokenizer."""
    api=api or RUNTIME_PROVIDER();row,plan,cfg=_verify_configuration(source,model,protocol,api)
    if stage not in STAGES:raise ValueError('Unknown finite count stage')
    request=row['requests'][model][stage]
    # Import through the actual runtime package, so no second compiler can be
    # accidentally used alongside the runtime's sealed implementation.
    native_schema=importlib.import_module(api.compile_condition.__module__)
    prompt=native_schema.native_prompt(plan,model,source['passage'],count_stage=stage,profile='positive_anchor')
    if prompt!=request['prompt'] or digest(prompt.encode())!=request['prompt_sha256']:
        raise ValueError('Approved count prompt changed')
    tokens=count_tokens(prompt)
    if type(tokens) is not int or tokens<1 or tokens+512>cfg['context_limit']:
        raise ValueError('Actual count-stage token budget invalid; no truncation')
    if model=='knowcoder' and tokens!=request['input_tokens']:
        raise ValueError('Actual Know tokenizer count differs from reviewed count packet')
    return {'prompt':prompt,'model':model,'count_stage':stage,'task_stage':None,
            'profile':'positive_anchor','input_tokens':tokens,'max_new_tokens':512,
            'context_limit':cfg['context_limit'],'plan_sha256':request['plan_sha256'],
            'prompt_sha256':request['prompt_sha256'],'implementation_sha256':api.implementation_identity(),
            'finite_count_development':{'packet_sha256':PACKET_SHA256,'source_id':source['id'],
                'stage':stage,'handler_sha256':digest(Path(__file__).read_bytes())}}


def verify_count_bound(bound,source,model,protocol,count_tokens,api=None):
    expected=bound_count_stage(source,model,protocol,bound['count_stage'],count_tokens,api)
    if bound!=expected:raise ValueError('Frozen finite count binding changed')
    return True


def capture_one(source,model,protocol):
    """Capture three fixed independent stages once; never retry a failed stage.

    The executable driver atomically claims each source. Runtime exceptions stop
    the remaining stages and retain their unrun slots; parse errors/truncation do
    not select a replacement and do not suppress independent remaining stages.
    """
    result={'id':source.get('id') if isinstance(source,dict) else None,'model':model,
            'protocol_sha256':digest(encoded(protocol)),'route_supported':False,
            'route_production_approved':False,'development_authorized':False,
            'model_quality_passed':False,'runtime_status':'not_run','parse_valid':False,
            'truncated':False,'coverage_complete':False,'semantic_support_validated':False,
            'raw_output':None,'normalized_evidence':None,'error':'','model_calls':0,
            'bound_inputs':[],'bound_input_verified':False,'stage_outputs':[],
            'automatic_retries':False,'automatic_companion_cases':False,'planned_stage_slots':3}
    session=None;before=0;prepared=[];api=None
    try:
        api=RUNTIME_PROVIDER();row,plan,cfg=_verify_configuration(source,model,protocol,api)
        result.update(route_supported=True,development_authorized=True,plan_sha256=row['plan_sha256'])
        with api._LOCK:
            session=api._session(model,cfg);before=session.calls
            prepared=[bound_count_stage(source,model,protocol,stage,session.count_tokens,api) for stage in STAGES]
            if 'inference_requests' in source and source['inference_requests']!=prepared:
                raise ValueError('Supplied finite inference request assertions differ')
            result['prepared_inputs']=prepared
            fatal=None;payloads={}
            for stage,bound in zip(STAGES,prepared):
                entry={'stage':stage,'count_stage':stage,'task_stage':None,'profile':'positive_anchor',
                       'runtime_status':'not_run','parse_valid':False,'generated':None,'error':'','model_calls':0}
                result['stage_outputs'].append(entry)
                if fatal is not None:
                    entry['error']='Not run after backend error: '+fatal;continue
                verify_count_bound(bound,source,model,protocol,session.count_tokens,api)
                calls_before=session.calls
                try:
                    session.last_raw=None
                    generated=session.generate(bound)
                    entry.update(generated=generated,runtime_status='truncated' if generated['truncated'] else 'ok')
                    payloads[stage]=generated['payload']
                    if generated['truncated']:
                        result['truncated']=True;entry['error']='Output budget exhausted'
                    else:
                        try:
                            api.normalize_native(generated['payload'],plan,model,source['passage'],
                                coverage_complete=False,count_stage=stage,profile='positive_anchor')
                            entry['parse_valid']=True
                        except (ValueError,TypeError,RecursionError) as error:
                            entry.update(runtime_status='error',error='Native parse: '+str(error))
                except Exception as error:
                    fatal=type(error).__name__+': '+str(error)
                    entry.update(runtime_status='error',error=fatal)
                    if getattr(session,'last_raw',None) is not None:entry['raw_backend_error_response']=session.last_raw
                finally:
                    delta=session.calls-calls_before
                    if delta not in (0,1):raise ValueError('Undeclared count request count')
                    entry['model_calls']=delta
                    if delta:result['bound_inputs'].append(bound)
            result['raw_output']=json.dumps(payloads,ensure_ascii=False,sort_keys=True) if payloads else None
            result['backend_metadata']=session.metadata
            if len(payloads)==3 and all(entry['parse_valid'] for entry in result['stage_outputs']):
                evidence=api.normalize_stages(payloads,plan,model,source['passage'],coverage_complete=False,profile='positive_anchor')
                result.update(runtime_status='ok',parse_valid=True,normalized_evidence=evidence)
            else:
                result.update(runtime_status='truncated' if result['truncated'] else 'error',
                              error='; '.join(entry['stage']+': '+entry['error'] for entry in result['stage_outputs'] if entry['error']))
    except Exception as error:
        result.update(runtime_status='error',error=type(error).__name__+': '+str(error))
    finally:
        if session is not None:
            result['model_calls']=session.calls-before
            try:
                result['bound_input_verified']=bool(result['bound_inputs']) and all(verify_count_bound(bound,source,model,protocol,session.count_tokens,api) for bound in result['bound_inputs'])
            except Exception as error:
                result.update(bound_input_verified=False,runtime_status='error',error='Post-capture binding verification: '+str(error))
        # Every failed source still contributes exactly three stage slots.
        while len(result['stage_outputs'])<3:
            stage=STAGES[len(result['stage_outputs'])]
            result['stage_outputs'].append({'stage':stage,'count_stage':stage,'task_stage':None,
                'profile':'positive_anchor','runtime_status':'not_run','parse_valid':False,
                'generated':None,'model_calls':0,'error':'Not run: '+result['error']})
    return result

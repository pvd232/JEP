"""Build exact six-source development-only protocols; no models are imported."""
from pathlib import Path
import hashlib
import json
import sys

PROVIDER=Path('/tmp/jep-native-general-capture-20261028')
FINITE=Path('/tmp/jep-finite-count-capture-v2-20261028')
sys.path[:0]=[str(PROVIDER),str(FINITE)]
from build_protocol import runtime_config
import native_capture
import finite_count_capture

ROOT=Path(__file__).resolve().parent
TASK=Path('/content/jep-native-author-calibration-20261028')
DEPLOY=TASK/'finite-count-v2-execution'
READY=Path('/tmp/jep-gollie-author-legacy-attempt03-audit-20261028/environments/knowcoder-author-setup-amendment02.json')
DRIVER=Path('/tmp/jep-gollie-author-legacy-attempt03-audit-20261028/environments/triton-driver-discovery-v2/receipt.json')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    for model in ('knowcoder','gollie'):
        if model=='knowcoder':
            snapshot=TASK/'checkpoints/knowcoder/models--golaxy--KnowCoder-7B-IE/snapshots/90ba076763dfb2e9efefd84a0e599f15ae533597'
        else:snapshot=Path('/root/.cache/huggingface/hub/models--HiTZ--GoLLIE-7B/snapshots/d3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9')
        cfg=runtime_config(model,snapshot,READY)
        cfg['runtime_manifest_path']=str(TASK/'environments/knowcoder-author-setup-amendment02.json')
        cfg['support_manifest_path']=str(DEPLOY/'provider/native-general-capture/support-seal.json')
        cfg['finite_count_development']=finite_count_capture.authorization()
        if model=='gollie':
            cfg['runtime_shim']={'path':str(DEPLOY/'runtime/driver_runtime_shim.py'),'sha256':sha(ROOT/'driver_runtime_shim.py'),
                'callable':'activate','kwargs':{'receipt_path':str(TASK/'environments/triton-driver-discovery-v2/receipt.json'),'receipt_sha256':sha(DRIVER)}}
        protocol={'status':'FROZEN_FINITE_EXPOSED_COUNT_DEVELOPMENT_V2','scope':'Exactly six already-exposed sources and three stages, one attempt per stage; no passed quality/production gate.',
            'model_quality_passed':False,'production_count_dispatch_enabled':False,
            'shared_gpu':True,'timing_isolated':False,
            'models':{model:{'handler':{'module':'finite_count_capture','callable':'capture_one','sha256':finite_count_capture.support_identity()['handler_sha256']},
                'max_model_calls_per_source':3,'native_capture':cfg}}}
        raw=finite_count_capture.encoded(protocol)
        (ROOT/('protocol-'+model+'.json')).write_bytes(raw)
        # Static exact source/plan/config proofs. Tokenization/model loading not invoked.
        for item in finite_count_capture.approved_packet()['items']:
            source={'id':item['source_id'],'passage':item['passage'],'condition':item['condition']}
            finite_count_capture._verify_configuration(source,model,protocol,native_capture)
        print(model,hashlib.sha256(raw).hexdigest())

if __name__=='__main__':main()

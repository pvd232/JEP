from pathlib import Path
import hashlib
import json
import os
import tempfile
import unittest
from unittest.mock import patch
from driver_runtime_shim import activate


class ShimTests(unittest.TestCase):
    def test_only_path_prefix_changes_after_all_identity_checks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);prefix=root/'bin';prefix.mkdir()
            wrapper=prefix/'ldconfig';wrapper.write_bytes(b'not executed')
            driver=root/'libcuda.so';driver.write_bytes(b'not loaded')
            sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
            receipt=root/'receipt.json'
            receipt.write_text(json.dumps({'status':'ready_cpu_discovery_verified',
                'global_cache_or_symlinks_modified':False,'path_prefix':str(prefix),
                'wrapper_sha256':sha(wrapper),'driver':str(driver),'driver_resolved':str(driver.resolve()),
                'driver_sha256':sha(driver)}))
            before={p:p.read_bytes() for p in (wrapper,driver,receipt)}
            with patch.dict(os.environ,{'PATH':'original'},clear=False):
                activate(str(receipt),sha(receipt))
                self.assertEqual(os.environ['PATH'],str(prefix)+os.pathsep+'original')
                self.assertEqual(before,{p:p.read_bytes() for p in before})
                driver.write_bytes(b'changed')
                os.environ['PATH']='original'
                with self.assertRaises(ValueError):activate(str(receipt),sha(receipt))
                self.assertEqual(os.environ['PATH'],'original')

if __name__=='__main__':unittest.main()

# General native capture callback

This prepared package exposes `native_capture.capture_one(source, model, protocol)`.
It is separate from the immutable fixed-nine development runner. No model was
loaded or run while preparing it, and no locked or fresh source file was read.

Run one model per process. The outer driver must atomically claim a source before
calling the handler; repeated attempts, automatic companions and fallback empty
lists are absent. One backend/tokenizer session is reused across sources. Every
model request gets a verified nativecore binding, raw token IDs and a stage record.
Unsupported or ungated routes make zero calls and return no invented output.

The `source` argument requires `id`, `passage` and `condition`. Optional `plan`
and `inference_requests` are assertions checked against condition-only compilation
and actual tokenizer bindings, rather than alternative instructions. The handler
does not open the outer job manifest. Coverage remains false until external
semantic completeness validation.

`protocol.models[model]` requires:

- `handler: {module: "native_capture", callable: "capture_one", sha256: ...}`
- `max_model_calls_per_source`
- `native_capture`, as illustrated in `protocol-template.json`

The configuration pins checkpoint, tokenizer, snapshot, backend, dtype, runtime
receipt, compiler/helper bytes, greedy settings, capability profile, stage and
token budgets. `support_identity()` reports the public hashes without reading
sources. A task-local runtime shim is optional but must supply its exact path,
SHA256, callable and JSON arguments; this supports the recorded real-driver
discovery repair without global library edits.

Capability receipts are keyed by the exact condition-only native schema:
`native_task/profile/stage/sorted_constructor_names`. Use `gate_key()` to derive
them. A receipt must explicitly bind its actual bytes and reviewed capability decision. The
template contains no passed gate. This prevents a Food control from silently
qualifying Animal, Color, scope or count extraction.

Compiler-declared stages are enabled only with `allow_compiler_stages: true`
and within the per-source call cap. All stage capabilities are checked before
any generation; the complete declared set is fixed before model outputs. Count
and scope merges call the nativecore literal-union normalizer and make no missing
facts or completeness claims.

Required result fields are `route_supported`, `runtime_status`, `parse_valid`,
`truncated`, `coverage_complete`, `raw_output`, `normalized_evidence`, `error`,
`model_calls`, `bound_inputs` and `bound_input_verified`. Raw stage outputs and
backend metadata are additional audit fields. Here model_calls counts native
extraction requests, including failed requests, rather than individual cached
forward passes. The outer driver owns durable raw-output saving and timeouts.

Known backend settings are preserved: historical KnowCoder vLLM0.2.2/cu118,
FP16, greedy, max_num_seqs4, explicit gpu_memory_utilization0.6, author triple-quote
stop; pinned original GoLLIE Flash code, BF16 and the reviewed manual greedy cache
loop. All actual selected weight shard bytes are checked against primary LFS
SHA256, including Go's two current shards; obsolete three-shard files are ignored.
Shared GPU execution makes no isolated timing claim.

This is implementation tooling. Fake-backend unit tests establish dispatch and
recording behavior, not native extraction quality. The packaged compiler is reviewed infrastructure, while each native schema/model
requires its own empirical capability decision before an evaluation protocol can
freeze it as operational.

The prepared provider now contains the reviewed scope-v5 compiler, with only the
approved whitespace-envelope parser fix (normalizer SHA256
`91ba2e447c35aee60b275c5cac5870d14dc1afcd1748da74c5bdda92947a2442`).
`compiler_implementation_files` is its complete identity mapping;
`compiler_implementation_sha256` is SHA256 of UTF8 compact canonical JSON of that
mapping (`ensure_ascii=False`, sorted keys, separators `(',', ':')`, no newline).
Bound-input `implementation_sha256` remains the full mapping.

`build_protocol.py --model ... --snapshot ... --runtime-manifest ... --output ...`
prepares exact compact canonical protocol bytes with no newline. The resulting
protocol has no passed capabilities and cannot invoke any native model. The
caller must freeze and review its selected capability receipts and call/stage
limits before dispatch. There is no legitimate operational zero-call success
route in this native provider. `protocol_canonical_sha256` is the callback's
canonical-object digest; the outer driver owns `protocol_sha256` for file bytes.
Requiring canonical protocol file bytes makes these digests equal without
substituting one field for the other.

A passed capability entry now requires `receipt_path` and `receipt_sha256` for an
existing JSON receipt. The bytes must match, and its content must bind
`status: 'PASSED_NATIVE_CAPABILITY_GATE'`, `gate_key`, `model_id`, `revision`,
`runtime_manifest_sha256`, `compiler_implementation_sha256`,
`support_manifest_sha256`, and `prompt_profile`. This checks the identity of the
external reviewed quality decision; it does not derive a quality decision from
model output. The template/builder never writes a passed quality receipt.

`verify_normalize_record(source, model, protocol, record)` is an inert CPU verifier
using only the packaged pinned tokenizer JSON and AST normalizer. It checks
actual input/output IDs, decode, budget, generation options, checkpoint/runtime
metadata, selected-shard identity proof and recomputed claims. It returns the
recomputed evidence object or rejects mismatches. It does not import torch,
Transformers or a model backend session. Before calling it, the outer driver
must verify its retained started/manifest/request/handler-return/capture hash
chain, the exact public source/model/protocol, and every custom support artifact
before importing the handler. Saved booleans and normalized claims alone are not
an admissible capture. Runtime/backend error records remain failures.

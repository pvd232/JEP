"""CPU-only callback contract tests with fake backends; no models or held-out data."""
from pathlib import Path
import hashlib
import json
import unittest
import tempfile

import native_capture as api
from native_adapter.schema import compile_condition,implementation_identity


class FakeBackend:
    instances=0
    payload='results = [Food("sandwich"), Food("pickle")]'
    truncated=False
    raises=False
    def __init__(self,model,cfg):
        type(self).instances+=1
        self.calls=0
        self.metadata={"fake_backend":True}
        self.last_raw=None
    def count_tokens(self,prompt):
        return 20
    def generate(self,bound):
        self.calls+=1
        if self.raises:
            self.last_raw={"token_ids":[42],"text":"partial"}
            raise RuntimeError("fake API failure")
        return {"payload":self.payload,"truncated":self.truncated,
            "input_token_ids":[1]+[3]*19,"output_token_ids":[42,2]}


def protocol():
    identity=api.support_identity()
    spec={"profile":"positive_anchor","max_new_tokens":512,"count_stage":None,"task_stage":None}
    key=api.gate_key(compile_condition("type of food"),"knowcoder",spec)
    cfg={
        "model_id":"golaxy/KnowCoder-7B-IE","revision":"90ba076763dfb2e9efefd84a0e599f15ae533597",
        "tokenizer_id":"golaxy/KnowCoder-7B-IE","tokenizer_revision":"90ba076763dfb2e9efefd84a0e599f15ae533597",
        "snapshot":"/fake/pinned-snapshot","backend":"author_vllm_0.2.2_cu118","dtype":"float16",
        "runtime_manifest_path":"/fake/receipt.json","runtime_manifest_sha256":"b"*64,
        "support_manifest_sha256":identity["support_manifest_sha256"],
        "compiler_implementation_sha256":identity["compiler_implementation_sha256"],
        "compiler_implementation_files":implementation_identity(),
        "context_limit":2048,"max_new_tokens":512,"profile":"positive_anchor",
        "allow_compiler_stages":False,
        "generation":{"do_sample":False,"num_beams":1,"num_return_sequences":1,
                      "gpu_memory_utilization":0.6,"max_num_seqs":4},
        "capability_gates":{},
    }
    receipt={"status":"PASSED_NATIVE_CAPABILITY_GATE","gate_key":key,
        **{name:cfg[name] for name in ("model_id","revision","runtime_manifest_sha256",
        "compiler_implementation_sha256","support_manifest_sha256")},
        "prompt_profile":"native_zero_shot_v1"}
    path=Path(tempfile.mkdtemp(prefix="native-fake-gate-"))/"receipt.json"
    path.write_bytes(api._canonical(receipt))
    cfg["capability_gates"][key]={"status":"passed","receipt_path":str(path),"receipt_sha256":api._digest(path.read_bytes())}
    return {"models":{"knowcoder":{"handler":{"module":"native_capture","callable":"capture_one",
        "sha256":identity["handler_sha256"]},"max_model_calls_per_source":1,"native_capture":cfg}}}


class PublicCallbackTests(unittest.TestCase):
    def setUp(self):
        api._SESSIONS.clear()
        api.BACKEND_FACTORY=FakeBackend
        FakeBackend.instances=0
        FakeBackend.payload='results = [Food("sandwich"), Food("pickle")]'
        FakeBackend.truncated=FakeBackend.raises=False
        self.source={"id":"synthetic-food","condition":"type of food","passage":"A sandwich and a pickle are on the tray."}

    def test_ungated_route_has_zero_calls_and_no_fake_empty_output(self):
        p=protocol()
        p["models"]["knowcoder"]["native_capture"]["capability_gates"]={}
        result=api.capture_one(self.source,"knowcoder",p)
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertIsNone(result["raw_output"])
        self.assertEqual(FakeBackend.instances,0)

    def test_supported_source_has_one_verified_call_without_companions(self):
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"ok")
        self.assertTrue(result["parse_valid"])
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(len(result["bound_inputs"]),1)
        self.assertTrue(result["bound_input_verified"])
        self.assertFalse(result["coverage_complete"])
        self.assertFalse(result["automatic_companion_cases"])

    def test_cached_session_reused_but_call_counts_are_per_source(self):
        p=protocol()
        first=api.capture_one(self.source,"knowcoder",p)
        second=api.capture_one(dict(self.source,id="another-source"),"knowcoder",p)
        self.assertEqual(FakeBackend.instances,1)
        self.assertEqual([first["model_calls"],second["model_calls"]],[1,1])

    def test_malformed_native_code_keeps_raw_and_actual_call(self):
        FakeBackend.payload="__import__('os').system('false')"
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertFalse(result["parse_valid"])
        self.assertIn("__import__",result["raw_output"])
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(len(result["bound_inputs"]),1)

    def test_api_error_retains_raw_backend_receipt(self):
        FakeBackend.raises=True
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(result["raw_backend_error_response"]["token_ids"],[42])

    def test_truncation_is_not_an_empty_list_fallback(self):
        FakeBackend.payload="results = ["
        FakeBackend.truncated=True
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"truncated")
        self.assertEqual(result["raw_output"],"results = [")
        self.assertFalse(result["parse_valid"])

    def test_frozen_prompt_drift_fails_before_generation(self):
        source=dict(self.source,inference_requests=[{"prompt":"changed"}])
        result=api.capture_one(source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(result["bound_inputs"],[])

    def test_multistage_budget_rejected_before_backend_creation(self):
        p=protocol()
        p["models"]["knowcoder"]["native_capture"]["allow_compiler_stages"]=True
        source={"id":"synthetic-count","condition":"number of people","passage":"Three people wait."}
        result=api.capture_one(source,"knowcoder",p)
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(FakeBackend.instances,0)

    def test_other_constructor_does_not_inherit_food_capability(self):
        source={"id":"synthetic-animal","condition":"type of animal","passage":"An otter swims."}
        result=api.capture_one(source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(FakeBackend.instances,0)


if __name__=="__main__":
    unittest.main()

"""CPU-only full-binding proofs, using pinned tokenizer JSON and frozen exposed sources."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from tokenizers import Tokenizer
import run_capture as capture


class PinnedTokenizer:
    eos_token_id=2
    def __init__(self,model):
        path=(capture.ROOT/'tokenizer-proof/gollie-tokenizer.json' if model=='gollie' else capture.ROOT/'legacy_support/pinned-metadata/ie/tokenizer.json')
        self.tokenizer=Tokenizer.from_file(str(path));self.model=model
    def encode(self,text,add_special_tokens=True):
        ids=self.tokenizer.encode(text,add_special_tokens=add_special_tokens).ids
        if self.model=='gollie' and add_special_tokens and (not ids or ids[-1]!=2):ids.append(2)
        return ids


class BindingTests(unittest.TestCase):
    def test_actual_pinned_tokenizer_binds_nine_new_recipes_both_models(self):
        for model in ('knowcoder_ie','gollie'):
            cases=capture.build_cases(model,PinnedTokenizer(model))
            self.assertEqual(len(cases),9)
            self.assertEqual(len({c['source_id'] for c in cases}),9)
            self.assertTrue(all(c['binding']['contract_recipe']==capture.RECIPE for c in cases))
            self.assertTrue(all(c['binding']['max_new_tokens']==512 for c in cases))
            self.assertTrue(all(c['binding']['input_tokens']+512<=c['binding']['context_limit'] for c in cases))
    def test_changed_source_is_rejected_before_inference(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for name in ('ordinary-requests.json','task-contract-requests.json'):(root/name).write_bytes((capture.ROOT/name).read_bytes())
            packet=json.loads((root/'task-contract-requests.json').read_bytes());packet['items'][0]['passage']+=' changed'
            (root/'task-contract-requests.json').write_text(json.dumps(packet))
            tok=PinnedTokenizer('knowcoder_ie')
            with patch.object(capture,'ROOT',root),self.assertRaises(ValueError):capture.build_cases('knowcoder_ie',tok)
    def test_go_helper_binding_cannot_drift_under_identical_prompt(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for name in ('ordinary-requests.json','task-contract-requests.json'):(root/name).write_bytes((capture.ROOT/name).read_bytes())
            packet=json.loads((root/'task-contract-requests.json').read_bytes());packet['items'][0]['requests']['gollie']['implementation_sha256']['normalize.py']='0'*64
            (root/'task-contract-requests.json').write_text(json.dumps(packet))
            tok=PinnedTokenizer('gollie')
            with patch.object(capture,'ROOT',root),self.assertRaises(ValueError):capture.build_cases('gollie',tok)

if __name__=='__main__':unittest.main()

# Same-nine fixed task-contract development capture

This capsule preserves the same nine source IDs, passages and conditions. It
runs one explicitly declared condition-only recipe, retaining the earlier
zero-shot, fixed-family one-shot and EE-frame results as separate experiments.
No target answer or reference annotation is included in a model request.

The recipe intentionally changes task/schema/query bytes for spatial predicates,
ActionDescription relation extraction and Go Food NER. It retains narrowly
verified zero-shot NER and fixed Color recipes where declared by the compiler.
It does not assert that all18 old target schemas/queries remain unchanged, or
that gains isolate one causal change. Source identity is checked separately from
the new frozen plan, prompt, profile, tokenizer budget and implementation bytes.

The backend/weight identities, original Go model implementation, historical
runtime and greedy decoding are the previously reviewed ones. KnowCoder uses the
separately named pinned IE checkpoint, FP16 author vLLM,0.6 resource cap and512
output budget. Go uses the pinned original Flash model, BF16 and the same manual
greedy/cache loop with512. Its actual tokenizer budget is checked before load.
The outer operator binds the verified Go snapshot and task-local driver-discovery
receipt; shared GPU execution makes no isolated timing claim.

Exactly nine source requests/model are planned, with zero companion cases. No
counts, negative sources, locked/fresh sources, alternative recipe grid, retries,
forced nonempty output or semantic output repair are implemented. AST parsing
and literal span grounding retain empty, malformed, truncated and semantically
unreviewed outputs separately. Source support and transfer require later checks.

Run with a fresh output directory in one model process at a time:

```
HISTORICAL_PYTHON run_capture.py --model knowcoder_ie --snapshot PINNED_IE --output NEW_OUTPUT
HISTORICAL_PYTHON run_capture.py --model gollie --snapshot PINNED_GO --output ANOTHER_NEW_OUTPUT
```

Each output retains full prompts/bindings, raw input/output IDs, native output,
backend metadata and classification; its archive/index is produced even if a
runtime error occurs. No inference was performed while preparing this capsule.

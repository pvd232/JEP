"""Verify native runs, restore small sealed artifacts, and package the results."""

import datetime
import fcntl
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

import yaml
from google.cloud import storage
from viper import api
from viper._source import RunFetcher
from viper.storage import LocalArtifactStore
from viper.gcs import GcsProvider
from viper.references import GcsFileRef
from viper.repository import read_source

repo = Path("/home/machina/jep-csts-tranche1-20261023")
control = Path("/home/machina/jep-tranche1-control-20261023")
destination = control / "collected"
destination.mkdir(exist_ok=True)
lock = (control / "collect.lock").open("a+")
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
summary = json.loads((repo / "convergence_results/summary.json").read_text())
assert summary["status"] == "complete", summary.get("failure", summary["status"])
assert 8 <= len(summary["runs"]) <= 10
assert len(summary["test"]) == 4
assert all(run["status"] == "succeeded" for run in summary["runs"])
source = read_source(repo)
assert summary["source_commit"] == "e2545bbc8e509d12b01e12ce43435b897bcb410f"
assert source.commit == summary["evaluation_source_commit"] == "182cfc35e5ab528e1239668b881c1779ffba0437"
trusted = frozenset({str(source.repository)})
# One immutable completed graph: reuse native verified-object and producer caches.
verification_fetcher = RunFetcher(repo, LocalArtifactStore(repo), str(source.repository))
providers = {}
client = storage.Client(project="mantra-477901")


def fetch(reference, digest, size):
    bucket = reference["bucket"]
    if bucket not in providers:
        providers[bucket] = GcsProvider(destination, bucket, client=client)
    raw = providers[bucket].fetch(GcsFileRef.model_validate(reference))
    assert len(raw) == size
    assert hashlib.sha256(raw).hexdigest() == digest
    return raw


receipts = []
for run in summary["runs"]:
    record = destination / "records" / run["name"]
    record.mkdir(parents=True, exist_ok=True)
    verification_path = record / "verification.json"
    if verification_path.exists():
        verification = json.loads(verification_path.read_text())
        assert verification["reference_sha256"] == run["reference"]["sha256"]
    else:
        verified = api.verify_run(api.VerifyRunRequest(root=repo, path=Path(run["path"]), trusted_source_repositories=trusted), fetcher=verification_fetcher)
        verification = {"measurement_count": verified.measurement_count, "reference_sha256": run["reference"]["sha256"]}
        verification_path.write_text(json.dumps(verification, indent=2) + "\n")
    native = run["reference"]
    (record / "resolved.yaml").write_bytes(fetch(native["stored_at"], native["sha256"], native["bytes"]))
    attempt_path = Path(run["path"]).parent / "attempts/1/resolved.yaml"
    attempt = yaml.safe_load(attempt_path.read_text())
    shutil.copyfile(attempt_path, record / "attempt-resolved.yaml")
    stages = []
    for stage in attempt["resolved_stages"]:
        snapshot = stage["snapshot"]
        identity = stage["resolved_spec"]
        spec_reference = dict(snapshot, path=identity["path"])
        raw = fetch(spec_reference, identity["sha256"], identity["bytes"])
        spec = yaml.safe_load(raw)
        (record / (stage["stage_id"] + "-spec.yaml")).write_bytes(raw)
        artifacts = {}
        for artifact_name, item in spec["artifacts"].items():
            identity = item["file"]
            reference = dict(snapshot, path=identity["path"])
            restore = artifact_name not in {"model", "prefix_model", "last_model", "resume_state"}
            if restore:
                raw = fetch(reference, identity["sha256"], identity["bytes"])
                (record / (artifact_name + Path(identity["path"]).suffix)).write_bytes(raw)
            artifacts[artifact_name] = {"sha256": identity["sha256"], "bytes": identity["bytes"], "stored_at": reference,
                                        "restored_and_checksum_verified": restore}
        stages.append({"stage_id": stage["stage_id"], "artifacts": artifacts, "snapshot": snapshot})
    # Keep the native metric events and independent worker receipts reviewable.
    native_directory = Path(run["path"]).parent
    for relative in ("spec.yaml", "resolved.ref.yaml"):
        shutil.copyfile(native_directory / relative, record / relative)
    for folder in ("measurements", "metric_verification", "logs"):
        source_directory = native_directory / "attempts/1" / folder
        if source_directory.exists():
            shutil.copytree(source_directory, record / folder, dirs_exist_ok=True)
    receipts.append({"name": run["name"], "reference": native, "verification": verification, "stages": stages})
    (destination / "native_verification.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print("Verified and restored " + run["name"], flush=True)

# Preserve the failed graph and its original prediction/metric evidence separately.
failed_receipts = []
for failed in summary.get("failed_evaluations", []):
    original = Path(failed["path"]).parent
    record = destination / "failed_evaluations" / original.name
    record.mkdir(parents=True, exist_ok=True)
    reference = yaml.safe_load((original / "resolved.ref.yaml").read_text())
    raw = fetch(reference["stored_at"], reference["sha256"], reference["bytes"])
    assert raw == (original / "resolved.yaml").read_bytes()
    assert yaml.safe_load(raw)["status"] == "failed"
    (record / "resolved.yaml").write_bytes(raw)
    for file in original.rglob("*"):
        if file.is_file() and file.suffix in {".yaml", ".json", ".jsonl", ".log"}:
            target = record / file.relative_to(original)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, target)
    failed_receipts.append({"name": failed["name"], "reference": reference,
                            "status": "failed", "resolved_roundtrip_verified": True,
                            "scope": "Original failed graph and outputs; excluded from successful run counts."})
(destination / "failed_evaluations.json").write_text(json.dumps(failed_receipts, indent=2) + "\n")

results = destination / "results"
results.mkdir(exist_ok=True)
for path in sorted((repo / "convergence_results").glob("*.json")):
    shutil.copyfile(path, results / path.name)
for name in ("preflight.json", "preflight-tests.log", "launcher.json", "training.log", "evaluation-recovery-launcher.json", "evaluation-recovery-checks.log"):
    shutil.copyfile(control / name, destination / name)
shutil.copyfile(repo / "configs/csts-tranche-1.json", destination / "settings.json")
manifest = {str(path.relative_to(destination)): {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}
            for path in destination.rglob("*") if path.is_file() and path.name != "files.json"}
(destination / "files.json").write_text(json.dumps(manifest, indent=2) + "\n")
archive = control / "results.tar.gz"
with tarfile.open(archive, "w:gz") as stream:
    for path in sorted(destination.rglob("*")):
        if path.is_file():
            stream.add(path, arcname=str(path.relative_to(destination)))
receipt = {"source_commit": summary["source_commit"], "evaluation_source_commit": source.commit, "failed_evaluations_preserved": len(failed_receipts), "collected_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "native_runs": len(receipts), "measurements_verified": sum(r["verification"]["measurement_count"] for r in receipts),
           "archive": str(archive), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "bytes": archive.stat().st_size,
           "files": len(manifest), "checkpoint_policy": "Exact sealed model and resume references retained; large bytes preserved in native storage and on the pilot disk."}
(control / "collection_receipt.json").write_text(json.dumps(receipt) + "\n")
print(json.dumps(receipt), flush=True)

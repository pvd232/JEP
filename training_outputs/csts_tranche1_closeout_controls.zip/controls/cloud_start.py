"""Start the existing Seoul pilot and record its task-scoped egress."""

import datetime
import fcntl
import json
import subprocess
import sys
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1] / "tmp/jep-gpu/run_with_session.py"
name = "jep-csts-format-20261021"
zone = "asia-northeast3-a"
region = "asia-northeast3"
expected_id = "8646910299736412654"


def cloud(*arguments):
    result = subprocess.run(
        [sys.executable, str(helper), "gcloud", *arguments, "--format=json"],
        text=True, capture_output=True, timeout=300,
    )
    if result.returncode:
        raise RuntimeError(result.stderr[-3000:])
    return json.loads(result.stdout) if result.stdout.strip() else None


def save(filename, value):
    path = directory / filename
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


with (directory / "cloud.lock").open("a+") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    pilot = cloud("compute", "instances", "describe", name, "--zone=" + zone)
    original = cloud("compute", "instances", "describe", "rico-source-l4-uswest4c", "--zone=us-west4-c")
    assert original["status"] == "TERMINATED"
    assert pilot["id"] == expected_id and pilot["status"] == "TERMINATED"
    assert pilot["machineType"].endswith("/g2-standard-4")
    assert len(pilot["guestAccelerators"]) == 1
    assert pilot["guestAccelerators"][0]["acceleratorCount"] == 1
    assert pilot["guestAccelerators"][0]["acceleratorType"].endswith("/nvidia-l4")
    assert len(pilot["networkInterfaces"]) == 1
    interface = pilot["networkInterfaces"][0]
    assert interface["subnetwork"].endswith("/" + name)
    assert not interface.get("accessConfigs")
    router = cloud("compute", "routers", "describe", name, "--region=" + region)
    assert router["network"].endswith("/networks/default")
    existing = [nat for nat in router.get("nats", []) if nat["name"] == name]
    assert not existing, "Reconcile existing pilot NAT before starting."
    egress = {"router": name, "nat": name, "region": region, "subnet": name, "new_nat_created": False, "phase": "create_intent"}
    save("egress.json", egress)
    cloud("compute", "routers", "nats", "create", name,
          "--router=" + name, "--region=" + region,
          "--nat-custom-subnet-ip-ranges=" + name,
          "--auto-allocate-nat-external-ips")
    router = cloud("compute", "routers", "describe", name, "--region=" + region)
    nat = next(item for item in router["nats"] if item["name"] == name)
    assert nat["sourceSubnetworkIpRangesToNat"] == "LIST_OF_SUBNETWORKS"
    assert len(nat["subnetworks"]) == 1 and nat["subnetworks"][0]["name"] == interface["subnetwork"]
    egress.update(new_nat_created=True, phase="verified", configuration=nat)
    save("egress.json", egress)
    save("cloud_state.json", {"phase": "start_intent", "id": expected_id, "name": name, "zone": zone})
    cloud("compute", "instances", "start", name, "--zone=" + zone)
    pilot = cloud("compute", "instances", "describe", name, "--zone=" + zone)
    assert pilot["id"] == expected_id and pilot["status"] == "RUNNING"
    receipt = {"phase": "running", "id": pilot["id"], "name": name, "zone": zone,
               "status": pilot["status"], "machine_type": "g2-standard-4", "gpu": "NVIDIA L4",
               "last_start": pilot.get("lastStartTimestamp"), "original_status": original["status"],
               "confirmed_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save("cloud_state.json", receipt)
    print(json.dumps(receipt), flush=True)

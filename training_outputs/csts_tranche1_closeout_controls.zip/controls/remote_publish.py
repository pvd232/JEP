"""Publish a fixed report bundle through the existing pinned CPU runtime."""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

repo=Path('/home/machina/jep-csts-tranche1-20261023')
control=Path('/home/machina/jep-tranche1-control-20261023')
commit='REPORT_COMMIT_PLACEHOLDER'
def command(args,**kwargs):
    return subprocess.run(args,text=True,capture_output=True,check=True,**kwargs).stdout
with (control/'report-publication.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    summary=json.loads((repo/'convergence_results/summary.json').read_text())
    assert summary['status']=='complete' and not summary.get('in_flight')
    assert not command(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader']).strip()
    receipt=repo/'training_outputs/csts_tranche1_report_publication.json'
    if receipt.exists():
        value=json.loads(receipt.read_text())
        assert value['source_commit']==commit and value['artifact']['restored_and_checksum_verified'] is True
        assert value['artifact']['sha256']==hashlib.sha256((control/'report.zip').read_bytes()).hexdigest()
        print(json.dumps(value),flush=True)
    else:
        assert not command(['git','-C',str(repo),'status','--porcelain','--untracked-files=no']).strip()
        previous=command(['git','-C',str(repo),'rev-parse','HEAD']).strip()
        assert previous==summary['evaluation_source_commit']
        command(['git','-C',str(repo),'fetch',str(control/'report.bundle'),'HEAD'])
        command(['git','-C',str(repo),'merge-base','--is-ancestor',previous,commit])
        command(['git','-C',str(repo),'checkout','--detach',commit])
        assert not list((repo/'experiments').glob('csts_tranche1_report_20261023_'+commit[:12]))
        shutil.copyfile(control/'report.zip',repo/'csts_data/tranche1_report.zip')
        environment=os.environ.copy()
        environment.update(PYTHONPATH=str(repo),PYTHONUNBUFFERED='1',HF_HOME='/home/machina/jep-model-cache',
                           TMPDIR='/home/machina/jep-worker-scratch',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
        process=subprocess.run(['/home/machina/jep-format-env/bin/python','-m','csts_pilot.convergence_publication'],
                               cwd=repo,env=environment,text=True,capture_output=True,timeout=1000)
        (control/'report-publication.log').write_text(process.stdout+process.stderr)
        assert process.returncode==0,process.stdout[-3000:]+process.stderr[-2000:]
        value=json.loads(receipt.read_text())
        assert value['source_commit']==commit and value['status']=='succeeded'
        print(json.dumps(value),flush=True)

"""Push the reviewed report, publish its fixed native bundle, and stop the pilot."""
import datetime
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

directory=Path(__file__).resolve().parent
repo=directory.parent/'csts-tranche1-plan-20261021'
branch='plan/csts-tranche-1-loss-convergence-20261021'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
with (directory/'closeout.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert json.loads((directory/'report_reviewed.json').read_text())['reviewed'] is True
    assert not git('status','--porcelain')
    current=git('rev-parse','HEAD')
    subprocess.run(['git','-C',str(repo),'fetch','origin',branch],check=True)
    assert git('rev-parse','origin/'+branch) in {'182cfc35e5ab528e1239668b881c1779ffba0437',current}
    subprocess.run(['git','-C',str(repo),'push','origin','HEAD:'+branch],check=True)
    remote=git('ls-remote','--heads','origin',branch).split()[0]
    assert remote==current
    value={'verified_remote_sha':remote,'branch':branch,'repository':'pvd232/JEP',
           'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (directory/'github_publication.json').write_text(json.dumps(value,indent=2)+'\n')
    subprocess.run(['git','-C',str(repo),'bundle','create',str(directory/'report.bundle'),
                    'HEAD','^182cfc35e5ab528e1239668b881c1779ffba0437'],check=True)
    with zipfile.ZipFile(directory/'report.zip','w',compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted((repo/'training_outputs').glob('csts_tranche1*')):
            bundle.write(path,str(path.relative_to(repo)))
        for path in sorted((repo/'csts_pilot').glob('convergence*.py')):
            bundle.write(path,str(path.relative_to(repo)))
        for name in ('plans/csts-tranche-1.md','plans/csts-tranche-1-code-review.md',
                     'configs/csts-tranche-1.json','training_outputs/csts_sol61_max_label_audit.json'):
            bundle.write(repo/name,name)
        for path in sorted(directory.glob('*.py')):
            bundle.write(path,'controls/'+path.name)
        bundle.write(directory/'report_reviewed.json','controls/report_reviewed.json')
    (directory/'active_operator.json').write_text(json.dumps({'pid':os.getpid(),'command':sys.argv,
          'report_commit':current,'bundle_sha256':hashlib.sha256((directory/'report.zip').read_bytes()).hexdigest()},indent=2)+'\n')
    (directory/'closeout_state.json').write_text(json.dumps({'phase':'publishing_native_report_then_stopping',
          'pid':os.getpid(),'report_commit':current},indent=2)+'\n')
subprocess.run([sys.executable,str(directory/'publish.py')],check=True)
(directory/'closeout_state.json').write_text(json.dumps({'phase':'published_and_stopped','pid':os.getpid(),
      'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('Reviewed report published; cloud shutdown and scoped NAT removal confirmed.',flush=True)

"""Publish the fixed report on the Mac CPU using the existing session in memory."""
import fcntl
import json
import os
import runpy
import shutil
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import google.auth
from google.oauth2.credentials import Credentials

directory=Path(__file__).resolve().parent
root=directory.parents[1]
repo=directory.parent/'csts-tranche1-plan-20261021'
helper=root/'tmp/jep-gpu/run_with_session.py'
with (directory/'closeout.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert json.loads((directory/'report_reviewed.json').read_text())['reviewed'] is True
    assert not (directory/'report_publication.json').exists()
    github=json.loads((directory/'github_publication.json').read_text())
    assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==github['verified_remote_sha']
    # The unchanged helper obtains the same account's normal CLI session token.
    # Capture it only in memory; credentials are excluded from outputs and files.
    session=subprocess.run([sys.executable,str(helper),'gcloud','auth','print-access-token'],
                           text=True,capture_output=True,timeout=90)
    if session.returncode:
        raise RuntimeError('Existing session access failed: '+session.stderr[-1000:])
    token=session.stdout.strip()
    assert token and '\n' not in token
    credentials=Credentials(token=token)
    del token, session
    source=directory.parent/'csts-tranche1-support/src'
    sys.path[:0]=[str(repo),str(source)]
    os.environ['PYTHONPATH']=str(repo)+os.pathsep+str(source)
    os.chdir(repo)
    data=repo/'csts_data'
    data.mkdir(exist_ok=True)
    shutil.copyfile(directory/'report.zip',data/'tranche1_report.zip')
    assert not list((repo/'experiments').glob('csts_tranche1_report_20261023_'+github['verified_remote_sha'][:12]))
    with patch.object(google.auth,'default',return_value=(credentials,'mantra-477901')):
        runpy.run_module('csts_pilot.convergence_publication',run_name='__main__')
    receipt=json.loads((repo/'training_outputs/csts_tranche1_report_publication.json').read_text())
    assert receipt['status']=='succeeded' and receipt['artifact']['restored_and_checksum_verified'] is True
    assert receipt['source_commit']==github['verified_remote_sha']
    (directory/'report_publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Native CPU report published and exact restored bytes verified.',flush=True)

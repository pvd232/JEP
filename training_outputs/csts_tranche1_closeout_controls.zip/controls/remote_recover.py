"""Advance only the task checkout and start the evaluation-only recovery once."""
import datetime
import fcntl
import json
import os
import subprocess
import time
from pathlib import Path

repo = Path('/home/machina/jep-csts-tranche1-20261023')
control = Path('/home/machina/jep-tranche1-control-20261023')
commit = '182cfc35e5ab528e1239668b881c1779ffba0437'
python = '/home/machina/jep-format-env/bin/python'

def command(args, **kwargs):
    return subprocess.run(args, text=True, capture_output=True, check=True, **kwargs).stdout

with (repo/'convergence_results/run.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    summary = json.loads((repo/'convergence_results/summary.json').read_text())
    assert summary['status'] == 'failed' and summary['current_stage'] == 'test_mse_prefix'
    assert not (control/'evaluation-recovery-launcher.json').exists(), 'Inspect existing recovery owner.'
    assert not command(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader']).strip()
    assert not command(['git','-C',str(repo),'status','--porcelain','--untracked-files=no']).strip()
    assert command(['git','-C',str(repo),'rev-parse','HEAD']).strip() == summary['source_commit']
    command(['git','-C',str(repo),'fetch',str(control/'recovery.bundle'),'HEAD'])
    command(['git','-C',str(repo),'merge-base','--is-ancestor',summary['source_commit'],commit])
    command(['git','-C',str(repo),'checkout','--detach',commit])
    assert command(['git','-C',str(repo),'rev-parse','HEAD']).strip() == commit
    environment = os.environ.copy()
    environment.update(HF_HOME='/home/machina/jep-model-cache',TMPDIR='/home/machina/jep-worker-scratch',
                       PYTHONPATH=str(repo),PYTHONUNBUFFERED='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    checks = subprocess.run([python,'-m','pytest','-q','tests/test_csts_convergence.py','-k',
                             'checkpoint_handoff or prefix_handoff or evaluation_recovery'],
                            text=True,capture_output=True,cwd=repo,env=environment,timeout=120)
    (control/'evaluation-recovery-checks.log').write_text(checks.stdout+checks.stderr)
    assert checks.returncode == 0, checks.stdout[-4000:]+checks.stderr[-1000:]
with (control/'training.log').open('ab',buffering=0) as output:
    argv = [python,'-m','csts_pilot.convergence_evaluate','--execute']
    child = subprocess.Popen(argv,cwd=repo,env=environment,stdin=subprocess.DEVNULL,
                             stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
time.sleep(0.2)
assert child.poll() is None
receipt = {'pid':child.pid,'command':argv,'cwd':str(repo),'evaluation_source_commit':commit,
           'training_source_commit':summary['source_commit'],'selection_sha256':summary['selection_sha256'],
           'gpu_seconds_before_recovery':summary['gpu_stage_seconds'],
           'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(control/'evaluation-recovery-launcher.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)

"""Publish the reviewed report through VIPER, then close the existing pilot."""
import fcntl
import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path

directory = Path(__file__).resolve().parent
repo = directory.parent/'csts-tranche1-plan-20261021'
helper = directory.parents[1]/'tmp/jep-gpu/run_with_session.py'
def remote(command, **kwargs):
    return subprocess.run([sys.executable,str(helper),'ssh','jep-csts-format-20261021',
                           'asia-northeast3-a',command],capture_output=True,timeout=1200,**kwargs)
def send(path, destination):
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    code='import hashlib,pathlib,sys; raw=sys.stdin.buffer.read(); assert hashlib.sha256(raw).hexdigest()=='+repr(digest)+'; pathlib.Path('+repr(destination)+').write_bytes(raw)'
    with path.open('rb') as stream:
        result=remote('python3 -c '+shlex.quote(code),stdin=stream)
    assert result.returncode==0,result.stderr.decode(errors='replace')[-2000:]

with (directory/'closeout.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert json.loads((directory/'report_reviewed.json').read_text())['reviewed'] is True
    github=json.loads((directory/'github_publication.json').read_text())
    commit=github['verified_remote_sha']
    receipt_path=directory/'report_publication.json'
    if not receipt_path.exists():
        send(directory/'report.bundle','/home/machina/jep-tranche1-control-20261023/report.bundle')
        send(directory/'report.zip','/home/machina/jep-tranche1-control-20261023/report.zip')
        code=(directory/'remote_publish.py').read_text().replace('REPORT_COMMIT_PLACEHOLDER',commit)
        result=remote('/home/machina/jep-format-env/bin/python -c '+shlex.quote(code))
        (directory/'native-report-publication.log').write_bytes(result.stdout+result.stderr)
        assert result.returncode==0,result.stdout.decode(errors='replace')[-4000:]+result.stderr.decode(errors='replace')[-2000:]
        receipt=json.loads(result.stdout.decode().splitlines()[-1])
        assert receipt['source_commit']==commit and receipt['artifact']['restored_and_checksum_verified'] is True
        receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
        (repo/'training_outputs/csts_tranche1_report_publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
    subprocess.run([sys.executable,str(directory/'cloud_stop.py')],check=True)

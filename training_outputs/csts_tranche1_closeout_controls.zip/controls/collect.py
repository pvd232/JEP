"""Collect only completed measurements and verify every transferred file."""

import hashlib
import json
import shlex
import subprocess
import sys
import tarfile
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1] / "tmp/jep-gpu/run_with_session.py"
prefix = [sys.executable, str(helper), "ssh", "jep-csts-format-20261021", "asia-northeast3-a"]
code = (directory / "collect_remote.py").read_text()
result = subprocess.run([*prefix, "/home/machina/jep-format-env/bin/python -c " + shlex.quote(code)], text=True, capture_output=True, timeout=1200)
(directory / "collection-remote.log").write_text(result.stdout + result.stderr)
if result.returncode:
    raise RuntimeError(result.stdout[-3000:] + result.stderr[-3000:])
receipt = json.loads(result.stdout.splitlines()[-1])
(directory / "collection_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
archive = directory / "results.tar.gz"
with archive.open("wb") as destination:
    process = subprocess.run([*prefix, "cat " + shlex.quote(receipt["archive"])], stdout=destination, stderr=subprocess.PIPE, timeout=300)
if process.returncode:
    raise RuntimeError(process.stderr.decode(errors="replace")[-3000:])
assert archive.stat().st_size == receipt["bytes"]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["sha256"]
collected = directory / "collected"
collected.mkdir(exist_ok=True)
with tarfile.open(archive, "r:gz") as stream:
    stream.extractall(collected, filter="data")
manifest = json.loads((collected / "files.json").read_text())
for name, identity in manifest.items():
    path = collected / name
    assert path.stat().st_size == identity["bytes"], name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == identity["sha256"], name
receipt["local_archive_and_files_verified"] = True
(directory / "collection_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)

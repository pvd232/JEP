"""Observe the single native runner, its current traces, and GPU activity."""

import json
import shlex
import subprocess
import sys
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1] / "tmp/jep-gpu/run_with_session.py"
code = r'''
import datetime,json,os,subprocess
from pathlib import Path
repo=Path('/home/machina/jep-csts-tranche1-20261023')
control=Path('/home/machina/jep-tranche1-control-20261023')
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for filename in ('preflight.json','launcher.json'):
 p=control/filename
 if p.exists():result[filename]=json.loads(p.read_text())
summary_path=repo/'convergence_results/summary.json'
if summary_path.exists():
 s=json.loads(summary_path.read_text())
 result['summary']={k:s.get(k) for k in ('status','current_stage','source_commit','gpu_stage_seconds','provisional_loss','failure','in_flight','evaluation_source_commit')}
 result['summary']['runs']=[{'name':x['name'],'status':x['status'],'path':x['path']} for x in s['runs']]
result['traces']=[]
for base in (repo/'experiments',repo/'.viper'):
 if not base.exists():continue
 for p in base.rglob('trace.json'):
  try:
   t=json.loads(p.read_text())
   if 'rating_objective' not in t.get('config',{}):continue
   e=t.get('epochs',[])
   result['traces'].append({'path':str(p),'status':t.get('status'),'arm':t['config']['rating_objective'],'completed_epochs':len(e),'latest':e[-1] if e else None,'selected':t.get('selected'),'failure':t.get('failure')})
  except (OSError,ValueError):pass
result['runner_processes']=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:argv=proc.joinpath('cmdline').read_bytes().split(b'\0')
 except OSError:continue
 if any(name in argv for name in (b'csts_pilot.convergence_run', b'csts_pilot.convergence_evaluate')):result['runner_processes'].append({'pid':int(proc.name),'argv':[a.decode(errors='replace') for a in argv if a]})
for filename in ('training.log','preflight-tests.log'):
 p=control/filename
 if p.exists():result[filename]=p.read_text(errors='replace')[-5000:]
result['gpu']=subprocess.run(['nvidia-smi','--query-gpu=name,utilization.gpu,memory.used','--format=csv,noheader'],text=True,capture_output=True).stdout.strip()
result['gpu_processes']=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True,capture_output=True).stdout.strip()
result['gpu_workers']=[]
for line in result['gpu_processes'].splitlines():
 pid=line.split(',',1)[0].strip()
 if not pid.isdigit():continue
 try:
  cwd=Path('/proc',pid,'cwd').resolve(strict=True)
  result['gpu_workers'].append({'pid':int(pid),'cwd':str(cwd)})
  if str(cwd).startswith('/home/machina/jep-worker-scratch/'):
   for p in cwd.parent.rglob('trace.json'):
    try:
     t=json.loads(p.read_text())
     if 'rating_objective' not in t.get('config',{}):continue
     e=t.get('epochs',[])
     result['traces'].append({'path':str(p),'status':t.get('status'),'arm':t['config']['rating_objective'],'completed_epochs':len(e),'latest':e[-1] if e else None,'selected':t.get('selected'),'failure':t.get('failure')})
    except (OSError,ValueError):pass
 except OSError:pass
print(json.dumps(result))
'''
process = subprocess.run([sys.executable, str(helper), "ssh", "jep-csts-format-20261021", "asia-northeast3-a", "python3 -c " + shlex.quote(code)], capture_output=True, text=True, timeout=120)
if process.returncode:
    raise RuntimeError(process.stderr[-3000:])
result = json.loads(process.stdout)
(directory / "latest_status.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)

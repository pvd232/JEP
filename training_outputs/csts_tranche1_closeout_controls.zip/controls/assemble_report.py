"""Match independent CPU results to native receipts and prepare the reviewed report."""
import datetime
import hashlib
import json
import math
import shutil
from pathlib import Path

directory=Path(__file__).resolve().parent
repo=directory.parent/'csts-tranche1-plan-20261021'
out=repo/'training_outputs'
def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
receipt=read(directory/'collection_receipt.json')
assert receipt['local_archive_and_files_verified'] is True
summary=read(directory/'collected/results/summary.json')
assert summary['status']=='complete'
for name in read(directory/'preview_results/preview_manifest.json'):
    assert (directory/'preview_results'/name).read_bytes()==(directory/'collected/results'/name).read_bytes(),name
report=read(out/'csts_tranche1_results.json')
scalar=read(directory/'scalar_snapshot.json')
for name,candidate in report['candidates'].items():
    values=scalar['candidates'][name]['metrics']
    for metric,field in (('test_mse','mse_0_1'),('test_spearman','spearman')):
        assert math.isclose(candidate['raw'][field],values[metric][-1]['value'],rel_tol=0,abs_tol=1e-12)
    model=next(x for x in summary['test'] if x['candidate']==name)
    native=directory/'collected/records'/model['run']['name']/'measurements'
    for metric in ('test_mse','test_spearman'):
        assert [json.loads(line) for line in (native/('test.'+metric+'.jsonl')).read_text().splitlines()]==values[metric]
assert report['paired_intervals']['groups']==1241 and report['paired_intervals']['draws']==2000
assert read(directory/'prefix_recovery_check.json')['bytes_identical'] is True
copies={
    'native_verification.json':'native_verification.json',
    'failed_evaluations.json':'failed_evaluations.json',
}
for source,target in copies.items():shutil.copyfile(directory/'collected'/source,out/('csts_tranche1_'+target))
for source,target in (('collection_receipt.json','collection.json'),('execution_manifest.json','execution.json'),
                      ('prefix_recovery_check.json','recovery.json'),('scalar_snapshot.json','native_scores.json')):
    shutil.copyfile(directory/source,out/('csts_tranche1_'+target))
shutil.copyfile(directory/'results.tar.gz',out/'csts_tranche1_evidence.tar.gz')
timing={
    'definition':'Prediction loop timing comes from sealed native artifacts. Stage envelopes use cumulative runner counters observed after each invocation, including publication and verification.',
    'native_gpu_counter_after_training':1106.611492177,
    'native_gpu_counter_after_failed_eval':1240.1908378680002,
    'native_gpu_counter_after_mse_prefix':1355.0953793540004,
    'native_gpu_counter_after_mse_full':1465.1893430510006,
    'native_gpu_counter_after_pearson_prefix':1572.149241929001,
    'native_gpu_counter_after_pearson_full':summary['gpu_stage_seconds'],
    'successful_prediction_loop_seconds':sum(x['timing']['prediction_seconds'] for x in scalar['candidates'].values()),
    'successful_native_eval_envelopes_seconds':summary['gpu_stage_seconds']-1240.1908378680002,
    'failed_native_eval_envelope_seconds':1240.1908378680002-1106.611492177,
    'candidates':{n:x['timing'] for n,x in scalar['candidates'].items()},
}
write(out/'csts_tranche1_evaluation_timing.json',timing)
path=out/'csts_tranche1_report.md'
text=path.read_text()
if 'The four successful prediction loops' not in text:
    text+=f"\nThe four successful prediction loops took **{timing['successful_prediction_loop_seconds']:.2f} seconds total**. Their complete native evaluation envelopes took **{timing['successful_native_eval_envelopes_seconds']/60:.2f} minutes**, including startup, input handling, publication and verification. The initial failed evaluation added {timing['failed_native_eval_envelope_seconds']/60:.2f} minutes; CPU handoffs, repair and separate collection add wall time outside these GPU-stage counters. This overhead is excessive for the inference workload. Exact counters and per-checkpoint loop times are in [evaluation timing](csts_tranche1_evaluation_timing.json).\n"
    text+="\nThe independent CPU metrics match VIPER's saved metric events within 1e-12. The transferred archive and every manifest file passed size and SHA-256 checks. [Native verification](csts_tranche1_native_verification.json) · [Evidence archive](csts_tranche1_evidence.tar.gz) · [Collection receipt](csts_tranche1_collection.json).\n"
    text+="\nThe provisional choice remains MSE. Its test ranking advantage is smaller than the predeclared 0.02 practical target; continued training provides the larger observed gain. Pearson has lower raw MSE, while validation-fitted calibration brings the numerical errors close together. These conclusions apply to this seed and the existing benchmark.\n"
    path.write_text(text)
review={'reviewed':True,'reviewer':'assistant','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'native_metrics_match_independent_cpu_within':1e-12,'preview_matches_verified_collection':True,
        'rendered_curves_inspected':True,'archive_sha256':receipt['sha256'],
        'report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'collaborative_code_walkthrough':'open; execution was separately authorized'}
write(directory/'report_reviewed.json',review)
write(out/'csts_tranche1_report_review.json',review)
print(json.dumps({'reviewed':True,'native_runs':receipt['native_runs'],'measurements':receipt['measurements_verified']}))

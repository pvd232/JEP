"""Transfer the frozen source, verify it, and invoke the guarded remote launcher."""

import hashlib
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1] / "tmp/jep-gpu/run_with_session.py"
vm = "jep-csts-format-20261021"
zone = "asia-northeast3-a"


def remote(command, **kwargs):
    return subprocess.run([sys.executable, str(helper), "ssh", vm, zone, command],
                          capture_output=True, timeout=300, **kwargs)


deadline = time.monotonic() + 300
while True:
    result = remote("true")
    if result.returncode == 0:
        break
    if time.monotonic() > deadline:
        raise RuntimeError(result.stderr.decode(errors="replace")[-2000:])
    time.sleep(10)

bundle = directory / "source.bundle"
digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
receive = "import hashlib,pathlib,sys; d=pathlib.Path('/home/machina/jep-tranche1-control-20261023'); d.mkdir(exist_ok=True); p=d/'source.bundle.part'; raw=sys.stdin.buffer.read(); assert hashlib.sha256(raw).hexdigest()==" + repr(digest) + "; p.write_bytes(raw); p.replace(d/'source.bundle'); print('Frozen source transfer verified.')"
with bundle.open("rb") as stream:
    result = remote("python3 -c " + shlex.quote(receive), stdin=stream)
if result.returncode:
    raise RuntimeError(result.stderr.decode(errors="replace")[-2000:])
print(result.stdout.decode().strip(), flush=True)
prepare = (directory / "remote_prepare.py").read_text()
result = remote("/home/machina/jep-format-env/bin/python -c " + shlex.quote(prepare))
(directory / "remote-prepare.log").write_bytes(result.stdout + result.stderr)
if result.returncode:
    raise RuntimeError(result.stdout.decode(errors="replace")[-4000:] + result.stderr.decode(errors="replace")[-3000:])
receipt = json.loads(result.stdout.decode().splitlines()[-1])
(directory / "launcher.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)

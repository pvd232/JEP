"""Stop the exact completed pilot, verify both VM states, and remove owned NAT."""

import datetime
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1] / "tmp/jep-gpu/run_with_session.py"
name = "jep-csts-format-20261021"
zone = "asia-northeast3-a"
region = "asia-northeast3"
receipt = json.loads((directory / "collection_receipt.json").read_text())
assert receipt["local_archive_and_files_verified"] is True
summary = json.loads((directory / "collected/results/summary.json").read_text())
assert summary["status"] == "complete"
assert summary["source_commit"] == "e2545bbc8e509d12b01e12ce43435b897bcb410f"
deferred_cpu = "--defer-cpu-publication" in sys.argv
publication = None
github = json.loads((directory / "github_publication.json").read_text())
if deferred_cpu:
    failure_log = (directory / "publish-and-stop.log").read_text()
    assert "pam_nologin" in failure_log and "send(directory/'report.zip'" in failure_log
    assert not (directory / "native-report-publication.log").exists()
    assert not (directory / "report_publication.json").exists()
    assert json.loads((directory / "report_reviewed.json").read_text())["reviewed"] is True
else:
    publication = json.loads((directory / "report_publication.json").read_text())
    assert publication["status"] == "succeeded"
    assert publication["artifact"]["restored_and_checksum_verified"] is True
    assert github["verified_remote_sha"] == publication["source_commit"]
verification = json.loads((directory / "collected/native_verification.json").read_text())
assert len(verification) == len(summary["runs"])


def cloud(*arguments):
    process = subprocess.run([sys.executable, str(helper), "gcloud", *arguments, "--format=json"],
                             text=True, capture_output=True, timeout=300)
    if process.returncode:
        raise RuntimeError(process.stderr[-3000:])
    return json.loads(process.stdout) if process.stdout.strip() else None


original = cloud("compute", "instances", "describe", "rico-source-l4-uswest4c", "--zone=us-west4-c")
assert original["status"] == "TERMINATED"
pilot = cloud("compute", "instances", "describe", name, "--zone=" + zone)
assert pilot["id"] == "8646910299736412654"
assert pilot["status"] in {"RUNNING", "TERMINATED"}
if pilot["status"] == "RUNNING":
    if deferred_cpu:
        observed = json.loads((directory / "latest_status.json").read_text())
        assert observed["summary"]["status"] == "complete"
        assert observed["gpu_processes"] == ""
        proof = {"status": "complete", "last_observed_at": observed["observed_at"],
                 "gpu_processes_at_last_observation": "", "collection_verified": True,
                 "ssh_access": "pam_nologin ahead of safety shutdown",
                 "native_cpu_publication": "moved to Mac; remote publication command never launched"}
    else:
        code = "import json,subprocess; from pathlib import Path; s=json.loads(Path('/home/machina/jep-csts-tranche1-20261023/convergence_results/summary.json').read_text()); assert s['status']=='complete'; p=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True,capture_output=True,check=True); assert not p.stdout.strip(),p.stdout; print(json.dumps({'status':s['status'],'gpu_processes':p.stdout.strip()}))"
        guard = subprocess.run([sys.executable, str(helper), "ssh", name, zone, "python3 -c " + shlex.quote(code)],
                               text=True, capture_output=True, timeout=120)
        if guard.returncode:
            raise RuntimeError(guard.stderr[-3000:])
        proof = json.loads(guard.stdout)
    cloud("compute", "instances", "stop", name, "--zone=" + zone)
else:
    proof = {"status": "complete", "gpu_processes": "VM already stopped"}
deadline = time.monotonic() + 180
while True:
    pilot = cloud("compute", "instances", "describe", name, "--zone=" + zone)
    if pilot["status"] == "TERMINATED":
        break
    if time.monotonic() >= deadline:
        raise TimeoutError("Pilot stopped-state confirmation pending.")
    time.sleep(5)
egress = json.loads((directory / "egress.json").read_text())
assert egress["new_nat_created"] is True and egress["phase"] == "verified"
assert egress["router"] == name and egress["nat"] == name and egress["subnet"] == name
router = cloud("compute", "routers", "describe", name, "--region=" + region)
matching = [nat for nat in router.get("nats", []) if nat["name"] == name]
if matching:
    nat = matching[0]
    assert nat["sourceSubnetworkIpRangesToNat"] == "LIST_OF_SUBNETWORKS"
    assert len(nat["subnetworks"]) == 1 and nat["subnetworks"][0]["name"].endswith("/" + name)
    cloud("compute", "routers", "nats", "delete", name, "--router=" + name, "--region=" + region)
router = cloud("compute", "routers", "describe", name, "--region=" + region)
assert not any(nat["name"] == name for nat in router.get("nats", []))
original = cloud("compute", "instances", "describe", "rico-source-l4-uswest4c", "--zone=us-west4-c")
assert original["status"] == "TERMINATED"
result = {"confirmed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "project": "mantra-477901",
          "pilot": {"name": name, "id": pilot["id"], "zone": zone, "status": pilot["status"], "last_start": pilot.get("lastStartTimestamp"), "last_stop": pilot.get("lastStopTimestamp"), "vm_start_to_stop_seconds": (datetime.datetime.fromisoformat(pilot["lastStopTimestamp"]) - datetime.datetime.fromisoformat(pilot["lastStartTimestamp"])).total_seconds()},
          "original": {"name": original["name"], "zone": "us-west4-c", "status": original["status"]},
          "pre_shutdown_guard": proof, "source_commit": summary["source_commit"],
          "collection_sha256": receipt["sha256"], "report_publication": publication["reference"] if publication else None, "native_cpu_publication_deferred_to_mac": deferred_cpu, "github_report_sha": github["verified_remote_sha"], "new_scoped_nat_removed": True, "persistent_disks_preserved": True}
(directory / "shutdown.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)

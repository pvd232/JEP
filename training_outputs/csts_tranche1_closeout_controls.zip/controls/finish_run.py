"""Observe this invocation and collect its completed native artifacts once."""

import datetime
import fcntl
import json
import os
import subprocess
import sys
import time
from pathlib import Path

directory = Path(__file__).resolve().parent


def state(phase, **details):
    value = {"phase": phase, "pid": os.getpid(), "updated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), **details}
    path = directory / "closeout_state.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


with (directory / "closeout.lock").open("a+") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        while True:
            state("observing_native_runner")
            result = subprocess.run([sys.executable, str(directory / "observe.py")], capture_output=True, text=True, timeout=150)
            if result.returncode:
                print("Status transport is temporarily unavailable: " + result.stderr[-500:], flush=True)
                time.sleep(30)
                continue
            status = json.loads((directory / "latest_status.json").read_text())
            summary = status.get("summary") or {}
            print(json.dumps({"at": status["observed_at"], "status": summary.get("status"), "stage": summary.get("current_stage"),
                              "traces": [{"arm": t["arm"], "epochs": t["completed_epochs"], "status": t["status"]} for t in status.get("traces", [])]}), flush=True)
            if summary.get("status") == "complete":
                break
            if summary.get("status") == "failed" and not status.get("runner_processes"):
                raise RuntimeError(json.dumps(summary.get("failure")))
            time.sleep(30)
        state("verifying_and_collecting_native_artifacts")
        subprocess.run([sys.executable, str(directory / "collect.py")], check=True)
        state("collected_awaiting_report_publication")
        print("Completed artifacts verified locally; report publication is the remaining closeout phase.", flush=True)
    except BaseException as error:
        state("requires_reconciliation", failure={"type": type(error).__name__, "message": str(error)})
        raise

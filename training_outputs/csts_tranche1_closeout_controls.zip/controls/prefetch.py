"""Read frozen small results so CPU analysis can overlap native verification."""
import hashlib
import json
import shlex
import subprocess
import sys
import tarfile
from pathlib import Path

directory=Path(__file__).resolve().parent
helper=directory.parents[1]/'tmp/jep-gpu/run_with_session.py'
code=r'''
import hashlib,io,json,sys,tarfile
from pathlib import Path
root=Path('/home/machina/jep-csts-tranche1-20261023/convergence_results')
assert json.loads((root/'summary.json').read_text())['status']=='complete'
files={p.name:p.read_bytes() for p in root.glob('*.json')}
files['preview_manifest.json']=json.dumps({n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in files.items()}).encode()
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as stream:
 for name,raw in files.items():
  info=tarfile.TarInfo(name);info.size=len(raw);stream.addfile(info,io.BytesIO(raw))
'''
archive=directory/'preview.tar.gz'
with archive.open('wb') as output:
    result=subprocess.run([sys.executable,str(helper),'ssh','jep-csts-format-20261021','asia-northeast3-a',
                           'python3 -c '+shlex.quote(code)],stdout=output,stderr=subprocess.PIPE,timeout=120)
assert result.returncode==0,result.stderr.decode(errors='replace')[-2000:]
destination=directory/'preview_results'
destination.mkdir(exist_ok=True)
with tarfile.open(archive,'r:gz') as stream:
    stream.extractall(destination,filter='data')
for name,identity in json.loads((destination/'preview_manifest.json').read_text()).items():
    raw=(destination/name).read_bytes()
    assert len(raw)==identity['bytes'] and hashlib.sha256(raw).hexdigest()==identity['sha256']
print('Frozen small results transferred; final report will also check the native collection manifest.',flush=True)

"""Transfer the published repair and launch the guarded evaluation recovery."""
import fcntl
import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path

directory = Path(__file__).resolve().parent
helper = directory.parents[1]/'tmp/jep-gpu/run_with_session.py'
def remote(command, **kwargs):
    return subprocess.run([sys.executable,str(helper),'ssh','jep-csts-format-20261021',
                           'asia-northeast3-a',command],capture_output=True,timeout=180,**kwargs)

with (directory/'closeout.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    bundle = directory/'recovery.bundle'
    digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
    receive = "import hashlib,pathlib,sys; raw=sys.stdin.buffer.read(); assert hashlib.sha256(raw).hexdigest()=="+repr(digest)+"; pathlib.Path('/home/machina/jep-tranche1-control-20261023/recovery.bundle').write_bytes(raw)"
    with bundle.open('rb') as stream:
        result = remote('python3 -c '+shlex.quote(receive),stdin=stream)
    assert result.returncode == 0, result.stderr.decode(errors='replace')[-2000:]
    result = remote('/home/machina/jep-format-env/bin/python -c '+shlex.quote((directory/'remote_recover.py').read_text()))
    (directory/'remote-recovery.log').write_bytes(result.stdout+result.stderr)
    assert result.returncode == 0, result.stdout.decode(errors='replace')[-3000:]+result.stderr.decode(errors='replace')[-2000:]
    receipt=json.loads(result.stdout.decode().splitlines()[-1])
    (directory/'evaluation-recovery-launcher.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)

"""Verify the isolated checkout and existing GPU environment, then launch once."""

import datetime
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

control = Path("/home/machina/jep-tranche1-control-20261023")
repo = Path("/home/machina/jep-csts-tranche1-20261023")
source_commit = "e2545bbc8e509d12b01e12ce43435b897bcb410f"
python = "/home/machina/jep-format-env/bin/python"
control.mkdir(exist_ok=True)
assert Path("/home/machina/jep-env-ready").exists()
assert shutil.disk_usage(control).free > 10 * 1024**3


def command(arguments, **kwargs):
    return subprocess.run(arguments, text=True, check=True, capture_output=True, **kwargs).stdout


def write(name, value):
    (control / name).write_text(json.dumps(value, indent=2) + "\n")


if not repo.exists():
    command(["git", "clone", "--no-checkout", str(control / "source.bundle"), str(repo)])
    command(["git", "-C", str(repo), "remote", "set-url", "origin", "https://github.com/pvd232/JEP.git"])
    command(["git", "-C", str(repo), "checkout", "--detach", source_commit])
assert command(["git", "-C", str(repo), "rev-parse", "HEAD"]).strip() == source_commit
assert not command(["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=no"]).strip()
assert not (repo / "convergence_results/summary.json").exists(), "Inspect existing run before launching."
assert not (control / "launcher.json").exists(), "Inspect existing launcher before launching."
if not (repo / "csts_data").exists():
    shutil.copytree("/home/machina/jep-csts-formats-20261021/csts_data", repo / "csts_data")
settings = json.loads((repo / "configs/csts-tranche-1.json").read_text())
for expected in settings["splits"].values():
    path = repo / expected["path"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected["sha256"]

gpu = command(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"]).strip()
assert "NVIDIA L4" in gpu and "580.126.20" in gpu
assert not command(["nvidia-smi", "--query-compute-apps=pid,process_name", "--format=csv,noheader"]).strip()
environment = os.environ.copy()
environment.update(HF_HOME="/home/machina/jep-model-cache", TMPDIR="/home/machina/jep-worker-scratch",
                   PYTHONPATH=str(repo), PYTHONUNBUFFERED="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
probe = command([python, "-c", "import importlib.metadata as m,json,platform,torch; print(json.dumps({'python':platform.python_version(),'torch':torch.__version__,'cuda':torch.version.cuda,'viper':json.loads(m.distribution('viper-provenance').read_text('direct_url.json'))['vcs_info']['commit_id']}))"], cwd=repo, env=environment)
versions = json.loads(probe)
assert versions["viper"] == "e4ce91fa0a9330e769644aba0fccdfe062d5d821"
assert versions["torch"] == "2.14.0+cu130"
test_command = [python, "-m", "pytest", "-q", "tests/test_csts_precision.py", "tests/test_csts_joint.py", "tests/test_csts_convergence.py"]
tests = subprocess.run(test_command, cwd=repo, env=environment, text=True, capture_output=True, timeout=180)
(control / "preflight-tests.log").write_text(tests.stdout + tests.stderr)
write("preflight.json", {"source_commit": source_commit, "gpu": gpu, "environment": versions,
                         "test_command": test_command, "test_returncode": tests.returncode,
                         "input_hashes_verified": True, "confirmed_at": datetime.datetime.now(datetime.timezone.utc).isoformat()})
assert tests.returncode == 0, tests.stdout[-4000:] + tests.stderr[-2000:]
command(["sudo", "shutdown", "-h", "+50", "Tranche 1 GPU safety deadline"])
with (control / "training.log").open("ab", buffering=0) as output:
    argv = [python, "-m", "csts_pilot.convergence_run", "--execute"]
    child = subprocess.Popen(argv, cwd=repo, env=environment, stdin=subprocess.DEVNULL,
                             stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
time.sleep(0.2)
assert child.poll() is None, "Native runner exited immediately; inspect training.log."
receipt = {"pid": child.pid, "source_commit": source_commit, "command": argv, "cwd": str(repo),
           "log": str(control / "training.log"), "settings": settings,
           "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "safety_shutdown_minutes": 50}
write("launcher.json", receipt)
print(json.dumps(receipt), flush=True)

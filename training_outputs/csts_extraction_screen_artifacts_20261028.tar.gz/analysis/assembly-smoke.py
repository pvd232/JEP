"""Synthetic, inference-free integration checks for the multi-origin assembler."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

path = Path('/tmp/jep-extraction-screen-assembly-20261028.py')
spec = importlib.util.spec_from_file_location('assembly', path)
assembly = importlib.util.module_from_spec(spec)
spec.loader.exec_module(assembly)

BUILD = r'''
import sys,json
from pathlib import Path
v=json.load(sys.stdin)
sys.path.insert(0,v['code'])
from csts_pilot import extraction_comparison as m
from csts_pilot.extraction_native import NATIVE_MODELS
root=Path(v['root']);data=root/'data';data.mkdir(parents=True)
rows=[]
for i in range(2):
 rows.append({'row_id':str(i),'sentence1':f'Left {i}.','sentence2':f'Right {i}.',
 'condition':'color','rating':float(1+4*i),'target':float(i),'pair_id':str(i),'group_id':str(i)})
raw=m.encoded(rows);(data/'validation.json').write_bytes(raw)
config={'model':'gpt-6.1-sol','reasoning_effort':'max','arms':list(m.ARMS),
 'native_models':NATIVE_MODELS,'sample_rows':2,'max_output_tokens':1024,'max_payload_bytes':65536,
 'sample_seed':42,'review_seed':7,'timeout_seconds':1,
 'dataset':{'revision':'synthetic','validation':{'rows':2,'sha256':m.digest(raw)}}}
config_path=root/'config.json';config_path.write_bytes(m.encoded(config));run=root/'run'
m.prepare(config_path,data,run)
references=root/'references.json';references.write_bytes(m.encoded([
 {'id':item['id'],'expected_answer':'No color is stated.'} for item in m.read(run/'sources.json')]))
m.seal_references(run,references)
for arm in v['arms']:
 for index,item in enumerate(m.items_for(run,arm)):
  folder=run/'captures'/arm/item['id'];folder.mkdir(parents=True)
  request={'item':item,'prompt':m.prompt_for(item,arm),'arm':arm,
           'protocol_sha256':m.digest((run/'protocol.json').read_bytes())}
  m.write_new(folder/'request.json',request)
  payload=json.dumps({'status':'not_specified','reason':'No color stated.','propositions':[]}) if arm=='gpt_propositions' else '[]'
  valid=not(arm=='gpt_propositions' and index==0)
  if not valid:payload=None
  if arm=='gpt_propositions':
   m.write_new(folder/'response.json',{'payload':payload})
   (folder/'events.jsonl').write_text(json.dumps({'type':'turn.completed'})+'\n')
  else:m.write_new(folder/'generation.json',{'payload':payload,'truncated':False,'synthetic':True})
  result={'id':item['id'],'arm':arm,'payload':payload,'valid':valid,
   'raw_artifacts':{p.name:m.digest(p.read_bytes()) for p in folder.iterdir() if p.is_file()}}
  if valid:result['parsed']=m.validate_payload(payload,arm,item)
  else:result['error']='Synthetic parser failure'
  m.write_new(folder/'result.json',result)
print(json.dumps({'run':str(run),'code':v['code'],'protocol_sha256':m.digest((run/'protocol.json').read_bytes())}))
'''

with tempfile.TemporaryDirectory(prefix='assembly-smoke-') as temporary:
    root=Path(temporary)
    origins={}
    for name,code,arms in (
        ('original','/tmp/jep-extraction-screen-v2-code-20261028',['gpt_propositions','knowcoder']),
        ('amended','/tmp/jep-extraction-gollie-compat-v3-20261028',['gollie']),
    ):
        request={'root':str(root/name),'code':code,'arms':arms}
        process=subprocess.run([sys.executable,'-B','-I','-c',BUILD],input=json.dumps(request),
                               text=True,capture_output=True,check=True)
        origin=json.loads(process.stdout)
        for arm in arms:origins[arm]=origin
    declaration={'arms':origins,'expected_sources':4,'review_kind':'synthetic',
                 'amendment':{'reason':'Synthetic default-RoPE alias normalization repair.',
                              'parent_protocol_sha256':origins['gpt_propositions']['protocol_sha256'],
                              'allowed_prompt_change_arms':[]}}
    declaration_path=root/'origins.json';declaration_path.write_bytes(assembly.encoded(declaration))
    output=root/'analysis'
    result=assembly.prepare(declaration_path,output)
    assert result['candidates']==12 and result['arms']['gpt_propositions']['failed']==1
    assert assembly.prepare(declaration_path,output)==result
    packet=assembly.read(output/'review-packet.json')
    assert all(set(row)=={'candidate_id','passage','condition','expected_answer','raw_output','structurally_valid'} for row in packet)
    assert len({row['candidate_id'] for row in packet})==12
    failed=[row for row in packet if not row['structurally_valid']]
    assert len(failed)==1 and failed[0]['raw_output']==''
    assert all(isinstance(row['raw_output'],str) for row in packet)
    manifest=assembly.read(output/'origin-manifest.json')
    assert 'absent_response_review_transport' in manifest
    origin_failed=[path for path in (Path(origins['gpt_propositions']['run'])/'captures/gpt_propositions').glob('*/result.json')
                   if not assembly.read(path)['valid']]
    assert assembly.read(origin_failed[0])['payload'] is None
    reviews=[{'candidate_id':row['candidate_id'],'reviewer_id':'synthetic-reviewer',
              'rationale':'Synthetic acceptance fixture.',**{field:True for field in assembly.FIELDS}} for row in packet]
    review_path=root/'review.json';review_path.write_bytes(assembly.encoded(reviews))
    second_review_path=root/'review-second.json'
    second_reviews=[dict(item,reviewer_id='synthetic-reviewer-2') for item in reviews]
    second_review_path.write_bytes(assembly.encoded(second_reviews))
    for paths in ([review_path],[review_path,review_path]):
        try:assembly.summarize(output,paths)
        except ValueError:pass
        else:raise AssertionError('Insufficient or duplicate reviewers passed')
    same_review_path=root/'review-copy.json';same_review_path.write_bytes(review_path.read_bytes())
    try:assembly.summarize(output,[review_path,same_review_path])
    except ValueError:pass
    else:raise AssertionError('Copied review contents passed')
    overlap_path=root/'review-overlap.json'
    overlap_path.write_bytes(assembly.encoded([dict(item,rationale='Changed prose only.') for item in reviews]))
    try:assembly.summarize(output,[review_path,overlap_path])
    except ValueError:pass
    else:raise AssertionError('Shared reviewer identities passed')
    report=assembly.summarize(output,[review_path,second_review_path])
    assert report['individual_reviews'][0]['arms']['gpt_propositions']['all_criteria_accepted']==3
    assert report['individual_reviews'][0]['paired_vs_propositions']['gollie']['mean_difference']==.25
    assert not report['disagreement_candidates']
    changed=assembly.read(output/'review-map.json');changed[0]['group_id']='changed'
    (output/'review-map.json').write_bytes(assembly.encoded(changed))
    try:assembly.summarize(output,[review_path,second_review_path])
    except ValueError:pass
    else:raise AssertionError('Review map tampering passed')
    wrong=dict(declaration);wrong['arms']=dict(origins)
    wrong['arms']['gollie']=dict(origins['gollie'],protocol_sha256='0'*64)
    try:assembly.validate_origins(wrong)
    except RuntimeError:pass
    else:raise AssertionError('Wrong origin protocol passed')
    print(json.dumps({'synthetic_candidates':12,'origin_implementations':2,
                      'fixed_denominator_failure_preserved':True,'paired_difference':.25,
                      'idempotent_publication':True,'tampering_rejected':True,'inference_calls':0}))

#!/usr/bin/env python3
"""Read-only derivation of MODEL-ASSISTED blinded reviews from retained proofs.

No inference, APIs, network access, original writes, mappings, or arm identities.
Use a new --output directory outside every original/recovery review directory.
Original failed parent/audit statuses remain explicitly reported and unchanged.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys
import types

BASE = Path('/tmp/jep-extraction-reference-capture-20261028')
OPERATOR_SHA = 'e1d19b1dab47d71aaaa558c5dd79580decf721a261c4b4c85170b0f60c93997f'
ACCELERATOR_SHA = 'c0aa0280cd24e2cd6d6a9d3a432a932c606a77e74a80a596b4acd439a6e37c07'
RECOVERY_HELPER_SHA = 'e9be24b4e71888494b295f3a356c400246751e3768645f44ec68e1440cb91d0c'
TRANSPORT_SOURCE_SHA = 'ee9ec882c78501f46d0ddf3ae3f57a271e365524e804301ecc1a06dab3cca6c3'
CAPACITY_MESSAGE = 'Selected model is at capacity. Please try a different model.'
# Exact reviewed grammar from csts_pilot/transport_revalidation.py; no broader errors.
WARNING = re.compile(r'Reconnecting\.\.\. [1-5]/5 \((?:request timed out|stream disconnected before completion: invalid peer certificate: UnknownIssuer)\)')
ARTIFACTS = ('prompt.txt', 'schema.json', 'command.json', 'events.jsonl',
             'response.json', 'stderr.log', 'audit.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode(text):
    def invalid(value):
        raise ValueError('Nonfinite JSON constant: ' + value)
    return json.loads(text, object_pairs_hook=object_pairs, parse_constant=invalid)


def read(path):
    return decode(path.read_text())


def save(path, value):
    with path.open('x') as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def locked_module(path, name, expected):
    raw = path.read_bytes()
    if sha(raw) != expected:
        raise ValueError('Hash-locked source changed: ' + str(path))
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def artifact_hashes(folder):
    return {name: sha((folder/name).read_bytes()) for name in ARTIFACTS
            if (folder/name).is_file()}


def expected_schema(operator, items, reviewer):
    props = {'candidate_id': {'type': 'string', 'enum': [x['candidate_id'] for x in items]},
             'reviewer_id': {'type': 'string', 'enum': [reviewer]},
             **{key: {'type': 'boolean'} for key in operator.FIELDS},
             'rationale': {'type': 'string'}}
    return {'type': 'object', 'additionalProperties': False,
            'properties': {'reviews': {'type': 'array', 'items': {
                'type': 'object', 'additionalProperties': False,
                'properties': props, 'required': list(props)}}}, 'required': ['reviews']}


def expected_command(operator, root, folder):
    # Approved recovery helper passes its literal /tmp OUTPUT to the unchanged
    # operator; originals/accelerator resolve their roots to /private/tmp on Mac.
    # Preserve that one recorded launch spelling instead of normalizing options.
    if root == (BASE/'review-b-capacity-recovery').resolve():
        root = BASE/'review-b-capacity-recovery'
        folder = root/folder.name
    command = [operator.CLI, '--no-daemon', '--ask-for-approval', 'never', 'exec',
               '--ignore-user-config', '--ignore-rules', '--ephemeral',
               '--skip-git-repo-check', '-C', str(root/'closed-book'),
               '-s', 'read-only', '-m', operator.MODEL, '-c', 'model_reasoning_effort="max"',
               '-c', 'web_search="disabled"']
    for feature in ('shell_tool', 'multi_agent', 'apps', 'plugins', 'memories',
                    'skill_search', 'browser_use', 'computer_use',
                    'image_generation', 'view_image', 'sleep_tool', 'hooks'):
        command += ['--disable', feature]
    return command + ['--json', '--color', 'never', '--output-schema', str(folder/'schema.json'),
                      '-o', str(folder/'response.json'), '-']


def validate_events(events, response):
    """Generalize reviewed transport proof to the exact reviews JSON envelope."""
    if sum(isinstance(e, dict) and e.get('type') == 'thread.started' for e in events) != 1:
        raise ValueError('Expected exactly one original thread')
    if sum(isinstance(e, dict) and e.get('type') == 'turn.started' for e in events) != 1:
        raise ValueError('Expected exactly one original turn')
    completed, answers, warnings, item_types = 0, [], [], set()
    allowed = {'thread.started', 'turn.started', 'item.started', 'item.updated',
               'item.completed', 'error', 'turn.failed', 'turn.completed'}
    for index, event in enumerate(events):
        if not isinstance(event, dict) or event.get('type') not in allowed:
            raise ValueError('Malformed or unknown Codex event')
        kind = event['type']
        if kind == 'turn.failed':
            raise ValueError('Codex inference failed')
        if kind == 'error':
            if (set(event) != {'type', 'message'} or not isinstance(event['message'], str)
                    or not WARNING.fullmatch(event['message'])):
                raise ValueError('Unrecognized Codex error')
            warnings.append(event['message'])
        if kind == 'turn.completed':
            completed += 1
            if index != len(events)-1:
                raise ValueError('Completed turn must be the final event')
        item = event.get('item', {})
        if not isinstance(item, dict) or item.get('type') not in (None, 'agent_message', 'reasoning'):
            raise ValueError('Closed-book violation')
        if item.get('type') is not None:
            item_types.add(item['type'])
        if kind == 'item.completed' and item.get('type') == 'agent_message':
            if not isinstance(item.get('text'), str):
                raise ValueError('Missing final agent response text')
            answers.append(decode(item['text']))
    if completed != 1 or len(answers) != 1:
        raise ValueError('Expected exactly one completed turn and one final agent message')
    if answers[0] != response:
        raise ValueError('Raw final agent JSON and retained response JSON differ')
    return {'completed_turns': 1, 'failed_turns': 0, 'final_agent_messages': 1,
            'raw_final_equals_retained_response': True, 'tool_activity_events': 0,
            'item_types': sorted(item_types), 'recognized_reconnect_warnings': warnings,
            'warning_policy': 'Exact reviewed reconnect grammar only; no other errors accepted'}


def validate_capture(operator, root, index, items, reviewer):
    folder = root/f'batch-{index:03d}'
    before = artifact_hashes(folder)
    required = {'prompt.txt', 'schema.json', 'command.json', 'events.jsonl', 'response.json'}
    if not required.issubset(before):
        raise ValueError('Missing retained proof files: ' + ', '.join(sorted(required-set(before))))
    prompt = (operator.RUBRIC + '\nREVIEWER_ID: ' + json.dumps(reviewer) +
              '\n\nBLINDED INPUTS:\n' + json.dumps(items, ensure_ascii=False))
    if (folder/'prompt.txt').read_text() != prompt:
        raise ValueError('Retained prompt differs from reconstructed exact batch')
    if read(folder/'schema.json') != expected_schema(operator, items, reviewer):
        raise ValueError('Retained response schema differs from unchanged operator')
    if read(folder/'command.json') != expected_command(operator, root, folder):
        raise ValueError('Retained command differs from unchanged operator')
    if not (folder/'audit.json').is_file():
        raise ValueError('Missing completed per-folder process audit')
    audit = read(folder/'audit.json')
    if audit.get('candidate_ids') != [x['candidate_id'] for x in items]:
        raise ValueError('Original per-folder audit candidate coverage differs')
    if type(audit.get('exit_code')) is not int or audit['exit_code'] != 0:
        raise ValueError('Original capture lacks an audited integer zero process exit code')
    response = read(folder/'response.json')
    events = [decode(line) for line in (folder/'events.jsonl').read_text().splitlines() if line.strip()]
    proof = validate_events(events, response)
    rows = operator.validate_reviews(response, items, reviewer)
    if before != artifact_hashes(folder):
        raise ValueError('Retained proof files changed during collection')
    return rows, {'folder': str(folder), 'raw_artifact_sha256': before,
                  'capture_proof': proof, 'original_folder_audit': audit,
                  'original_folder_audit_missing': audit is None,
                  'original_folder_failed_status_preserved': bool(audit and audit.get('status') != 'completed')}


def validate_capacity_policy(operator, review, recovery, items, original):
    """Only the separately authorized, zero-score original B024 capacity failure."""
    if review.name != 'review-b' or original['reviewer_id'] != 'model:gpt-6.1-sol:max:review-b':
        raise ValueError('Capacity recovery is restricted to review-B batch024')
    if recovery != (review.parent/'review-b-capacity-recovery').resolve():
        raise ValueError('Unexpected capacity recovery directory')
    if sha((BASE/'recover_capacity_batch.py').read_bytes()) != RECOVERY_HELPER_SHA:
        raise ValueError('Approved capacity recovery helper changed')
    folder = review/'batch-024'
    policy_path = recovery/'capacity-recovery-policy.json'
    policy = read(policy_path)
    actual = {p.name: sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file()}
    required = {'audit.json', 'events.jsonl', 'prompt.txt', 'schema.json', 'command.json'}
    if not required.issubset(actual) or policy.get('original_artifact_sha256') != actual:
        raise ValueError('Capacity policy original-artifact hashes differ')
    if Path(policy.get('original_folder', '')).resolve() != folder:
        raise ValueError('Capacity policy original folder differs')
    audit = read(folder/'audit.json')
    events = [decode(line) for line in (folder/'events.jsonl').read_text().splitlines() if line.strip()]
    if (audit.get('status') != 'failed' or audit.get('exit_code') in (None, 0)
            or (folder/'response.json').exists()):
        raise ValueError('Original is not a nonzero, no-response capacity failure')
    if [e.get('type') for e in events] != ['thread.started', 'turn.started', 'error', 'turn.failed']:
        raise ValueError('Original capacity event sequence differs')
    failed_error = events[3].get('error')
    if isinstance(failed_error, dict):
        failed_error = failed_error.get('message')
    if (events[2].get('message') != CAPACITY_MESSAGE or failed_error != CAPACITY_MESSAGE
            or any(e.get('item') for e in events)):
        raise ValueError('Original capacity failure contains unexpected/scored/tool content')
    ids = [row['candidate_id'] for row in items]
    prompt = (operator.RUBRIC + '\nREVIEWER_ID: ' + json.dumps(original['reviewer_id']) +
              '\n\nBLINDED INPUTS:\n' + json.dumps(items, ensure_ascii=False))
    checks = {'status': 'authorized_capacity_recovery_before_call',
              'original_status_preserved': 'failed', 'original_response_absent': True,
              'original_error_exact': CAPACITY_MESSAGE, 'original_exit_code': audit['exit_code'],
              'original_had_no_scored_content': True, 'candidate_ids': ids,
              'reviewer_id': original['reviewer_id'], 'seed': original['seed'],
              'model_alias': operator.MODEL, 'reasoning_effort': 'max',
              'operator_sha256': OPERATOR_SHA, 'recovery_helper_sha256': RECOVERY_HELPER_SHA,
              'same_prompt_sha256': sha(prompt.encode()), 'same_schema': True,
              'maximum_recovery_calls': 1, 'operator_semantic_retries': 0}
    if any(policy.get(key) != value for key, value in checks.items()):
        raise ValueError('Capacity recovery policy differs from the authorized narrow contract')
    if (folder/'prompt.txt').read_text() != prompt or read(folder/'schema.json') != expected_schema(operator, items, original['reviewer_id']):
        raise ValueError('Original capacity batch prompt/schema differs')
    return {'policy_path': str(policy_path), 'policy_sha256': sha(policy_path.read_bytes()),
            'original_capacity_failure_preserved': True,
            'operational_recovery_separate_from_primary': True,
            'original_artifact_sha256': actual}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--capacity-recovery-root', type=Path)
    args = parser.parse_args(argv)
    review, output = args.review_dir.resolve(), args.output.resolve()
    recovery = args.capacity_recovery_root.resolve() if args.capacity_recovery_root else None
    if review.name not in ('review-a', 'review-b') or review.parent != BASE.resolve():
        raise ValueError('Only the fixed original review-a/review-b directories are supported')
    protected = [BASE.resolve()/'review-a', BASE.resolve()/'review-b',
                 BASE.resolve()/'review-b-capacity-recovery']
    if any(output == path or path in output.parents for path in protected):
        raise ValueError('Collector output must be separate from original/recovery artifacts')
    if output.exists():
        raise ValueError('Collector output already exists; refusing replacement')
    operator = locked_module(BASE/'review_candidates.py', 'unchanged_operator', OPERATOR_SHA)
    accelerator = locked_module(BASE/'accelerate_reviews.py', 'unchanged_accelerator', ACCELERATOR_SHA)
    provenance_raw, original, batches = accelerator.reconstruct(operator, review)
    if original.get('criterion_fields') != list(operator.FIELDS) or original.get('semantic_retries') != 0:
        raise ValueError('Original review criterion/retry design differs')
    expected_ids = [row['candidate_id'] for batch in batches for row in batch]
    if len(batches) != 60 or len(expected_ids) != 717 or len(set(expected_ids)) != 717:
        raise ValueError('Reconstructed exact cohort coverage differs')
    parent_path = review/'batch-status.json'
    parent_raw = parent_path.read_bytes() if parent_path.exists() else None
    parent_rows = decode(parent_raw.decode()) if parent_raw is not None else []
    parent_by_batch = {row['batch']: row for row in parent_rows}
    if len(parent_by_batch) != len(parent_rows):
        raise ValueError('Duplicate original parent batch statuses')
    acceleration = review.parent/('acceleration-'+review.name[-1])/'batch-status.json'
    accel_raw = acceleration.read_bytes() if acceleration.exists() else None
    accel_rows = decode(accel_raw.decode()) if accel_raw is not None else []
    accel_by_batch = {row['batch']: row for row in accel_rows}
    results, accepted = [], {}
    for index, items in enumerate(batches):
        status = {'batch': index, 'candidate_ids': [x['candidate_id'] for x in items],
                  'status': 'missing_or_failed', 'original_parent_status': parent_by_batch.get(index),
                  'accelerator_status': accel_by_batch.get(index),
                  'original_folder_audit_missing': not (review/f'batch-{index:03d}'/'audit.json').is_file()}
        parent = parent_by_batch.get(index)
        status['original_parent_collision'] = bool(parent and str(parent.get('error', '')).startswith('FileExistsError:'))
        try:
            rows, proof = validate_capture(operator, review, index, items, original['reviewer_id'])
            status.update(status='accepted_original_retained_capture', **proof)
        except Exception as exc:
            status['original_collection_error'] = type(exc).__name__ + ': ' + str(exc)
            status['original_raw_artifact_sha256'] = artifact_hashes(review/f'batch-{index:03d}')
            rows = None
            if recovery is not None and index == 24:
                try:
                    policy = validate_capacity_policy(operator, review, recovery, items, original)
                    rows, proof = validate_capture(operator, recovery, index, items, original['reviewer_id'])
                    status.update(status='accepted_separate_capacity_recovery', capacity_policy=policy,
                                  recovery_proof=proof)
                except Exception as recovery_exc:
                    status['capacity_recovery_error'] = type(recovery_exc).__name__ + ': ' + str(recovery_exc)
        if rows is not None:
            for row in rows:
                if row['candidate_id'] in accepted:
                    raise ValueError('Duplicate candidate across accepted batches')
                accepted[row['candidate_id']] = row
        results.append(status)
    missing = [identity for identity in expected_ids if identity not in accepted]
    rows = [accepted[identity] for identity in expected_ids if identity in accepted]
    complete = not missing and len(rows) == 717
    output.mkdir(parents=True)
    save(output/'reviews.partial.json', rows)
    if complete:
        save(output/'reviews.json', rows)
    save(output/'batch-collection.json', results)
    save(output/'missing-candidates.json', missing)
    manifest = {'review_type': 'DERIVED MODEL-ASSISTED BLINDED REVIEW; NOT HUMAN EXPERT ADJUDICATION',
                'status': 'completed' if complete else 'incomplete_missing_or_failed_batches',
                'original_review_directory': str(review), 'reviewer_id': original['reviewer_id'],
                'model_alias': original['model_alias'], 'reasoning_effort': original['reasoning_effort'],
                'immutable_model_snapshot': None, 'original_primary_status_preserved': True,
                'original_provenance': original, 'original_provenance_sha256': sha(provenance_raw),
                'original_parent_batch_status_sha256': sha(parent_raw) if parent_raw is not None else None,
                'acceleration_batch_status_sha256': sha(accel_raw) if accel_raw is not None else None,
                'operator_sha256': OPERATOR_SHA, 'accelerator_sha256': ACCELERATOR_SHA,
                'collector_sha256': sha(Path(__file__).read_bytes()), 'packet_sha256': original['packet_sha256'],
                'criterion_fields': list(operator.FIELDS), 'all_judgments_actual_booleans': True,
                'semantic_edits': 0, 'model_calls': 0, 'original_artifact_writes': 0,
                'batch_count': 60, 'expected_reviews': 717, 'completed_reviews': len(rows),
                'missing_reviews': len(missing), 'output_order': 'Reconstructed original batch order',
                'capacity_recovery_requested': str(recovery) if recovery else None,
                'capacity_recoveries_accepted': sum(r['status']=='accepted_separate_capacity_recovery' for r in results),
                'transport_warning_grammar': WARNING.pattern,
                'reviewed_transport_policy_source_sha256': TRANSPORT_SOURCE_SHA,
                'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'derived_artifact_sha256': {p.name: sha(p.read_bytes()) for p in output.iterdir() if p.is_file()}}
    save(output/'provenance.json', manifest)
    print(json.dumps({key: manifest[key] for key in ('status', 'reviewer_id', 'completed_reviews', 'missing_reviews', 'capacity_recoveries_accepted')}))
    return 0 if complete else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(1)

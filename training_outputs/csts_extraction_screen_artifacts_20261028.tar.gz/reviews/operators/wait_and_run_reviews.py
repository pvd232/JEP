#!/usr/bin/env python3
"""Wait for the complete sealed blinded cohort; dispatch two model-assisted reviews."""
import argparse
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OPERATOR = Path('/tmp/jep-extraction-reference-capture-20261028/review_candidates.py')
SEALED_ARTIFACTS = {'assembly-spec.json', 'origin-manifest.json', 'references.json',
                    'review-packet.json', 'review-map.json', 'review-template.json',
                    'operational-counts.json'}
PACKET_FIELDS = {'candidate_id', 'passage', 'condition', 'expected_answer',
                 'raw_output', 'structurally_valid'}
EXPECTED_COUNT = 717
EXPECTED_IDS = {f'candidate_{i:05d}' for i in range(EXPECTED_COUNT)}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def validate_ready(run):
    # Mapping/template bytes are hashed only. Their contents never enter prompts.
    seal_bytes = (run / 'review-seal.json').read_bytes()
    seal = json.loads(seal_bytes)
    artifacts = seal.get('artifacts')
    if not isinstance(artifacts, dict) or set(artifacts) != SEALED_ARTIFACTS:
        raise ValueError('Unexpected seal artifact contract')
    observed = {}
    packet_raw = None
    for name, expected in artifacts.items():
        raw = (run / name).read_bytes()
        observed[name] = sha(raw)
        if observed[name] != expected:
            raise ValueError('Sealed artifact hash mismatch: ' + name)
        if name == 'review-packet.json':
            packet_raw = raw
    packet = json.loads(packet_raw)
    if not isinstance(packet, list) or len(packet) != EXPECTED_COUNT:
        raise ValueError('Review requires the complete 717-candidate packet')
    identities = []
    groups = Counter()
    for item in packet:
        if not isinstance(item, dict) or set(item) != PACKET_FIELDS:
            raise ValueError('Unexpected blinded packet fields')
        if any(not isinstance(item[key], str) for key in PACKET_FIELDS - {'structurally_valid'}):
            raise ValueError('Malformed packet text field')
        if type(item['structurally_valid']) is not bool:
            raise ValueError('Malformed structural-validity flag')
        identities.append(item['candidate_id'])
        groups[(item['passage'], item['condition'], item['expected_answer'])] += 1
    if len(set(identities)) != EXPECTED_COUNT or set(identities) != EXPECTED_IDS:
        raise ValueError('Candidate coverage differs or has duplicate IDs')
    if len(groups) != 239 or set(groups.values()) != {3}:
        raise ValueError('Expected 239 blinded source/condition groups represented three times')
    return {'seal_sha256': sha(seal_bytes), 'sealed_artifact_sha256': observed,
            'candidate_count': EXPECTED_COUNT, 'source_condition_groups': len(groups),
            'representations_per_group': 3, 'validated_at_utc': now()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--active-run', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--wait-timeout', type=int, default=14400)
    args = parser.parse_args()
    run, output = args.active_run.resolve(), args.output_root.resolve()
    output.mkdir(parents=True, exist_ok=True)
    provenance_path = output / 'controller-provenance.json'
    if provenance_path.exists():
        raise ValueError('Existing controller provenance; refusing duplicate dispatch')
    operator_hash = sha(OPERATOR.read_bytes())
    launches = []
    for suffix, seed in (('a', 2026102801), ('b', 2026102802)):
        destination = output / ('review-' + suffix)
        if destination.exists():
            raise ValueError('Existing review output directory; refusing duplicate dispatch')
        command = [sys.executable, str(OPERATOR), '--packet', str(run / 'review-packet.json'),
                   '--output', str(destination), '--reviewer-id',
                   'model:gpt-6.1-sol:max:review-' + suffix,
                   '--seed', str(seed), '--expected-candidates', str(EXPECTED_COUNT)]
        launches.append({'review': suffix, 'seed': seed, 'command': command,
                         'output': str(destination), 'log': str(output / ('review-' + suffix + '.log'))})
    provenance = {'review_type': 'MODEL-ASSISTED BLINDED REVIEW; NOT HUMAN EXPERT ADJUDICATION',
                  'controller_started_at_utc': now(), 'status': 'waiting_for_seal',
                  'active_run': str(run), 'operator': str(OPERATOR),
                  'operator_sha256': operator_hash,
                  'controller_sha256': sha(Path(__file__).read_bytes()),
                  'launches': launches, 'review_batch_size': 12, 'workers_per_review': 6,
                  'required_candidates': EXPECTED_COUNT,
                  'blinding': 'Only the six blinded packet fields enter reviewer contexts; mappings are hashed without semantic inspection.',
                  'independence_limitation': 'Separate processes, fresh model contexts and different orders; same model alias and shared model-assisted references.',
                  'semantic_retries': 0, 'wait_timeout_seconds': args.wait_timeout}
    write(provenance_path, provenance)
    print(json.dumps({'status': provenance['status'], 'at_utc': now()}), flush=True)
    started = time.monotonic()
    marker = run / 'review-seal.json'
    while not marker.exists():
        if time.monotonic() - started > args.wait_timeout:
            provenance.update(status='failed_wait_timeout', finished_at_utc=now())
            write(provenance_path, provenance)
            return 1
        time.sleep(10)
    # The seal writer closes its final file before this stable-stat check returns.
    previous = marker.stat()
    time.sleep(1)
    current = marker.stat()
    if (previous.st_size, previous.st_mtime_ns) != (current.st_size, current.st_mtime_ns):
        time.sleep(1)
    try:
        if sha(OPERATOR.read_bytes()) != operator_hash:
            raise ValueError('Reviewer operator changed while awaiting the sealed packet')
        provenance['cohort_validation'] = validate_ready(run)
        provenance.update(status='launching', dispatch_started_at_utc=now())
        write(provenance_path, provenance)
        processes = []
        for launch in launches:
            with Path(launch['log']).open('x') as log:
                process = subprocess.Popen(launch['command'], stdin=subprocess.DEVNULL,
                                           stdout=log, stderr=subprocess.STDOUT,
                                           cwd=str(output), start_new_session=True)
            launch.update(pid=process.pid, launched_at_utc=now())
            processes.append((launch, process))
            write(provenance_path, provenance)
        provenance['status'] = 'reviews_running'
        write(provenance_path, provenance)
        print(json.dumps({'status': 'reviews_running',
                          'pids': [process.pid for _, process in processes], 'at_utc': now()}), flush=True)
        while any(process.poll() is None for _, process in processes):
            time.sleep(10)
        for launch, process in processes:
            launch['exit_code'] = process.returncode
            result = Path(launch['output']) / 'reviews.json'
            launch['complete_review_file_exists'] = result.is_file()
            if result.is_file():
                rows = json.loads(result.read_bytes())
                if (not isinstance(rows, list) or len(rows) != EXPECTED_COUNT or
                        {row.get('candidate_id') for row in rows} != EXPECTED_IDS):
                    raise ValueError('Completed reviewer output has invalid candidate coverage')
                launch['reviews_sha256'] = sha(result.read_bytes())
        success = all(p.returncode == 0 and Path(launch['output'], 'reviews.json').is_file()
                      for launch, p in processes)
        provenance.update(status='completed' if success else 'failed_review_run',
                          finished_at_utc=now())
        write(provenance_path, provenance)
        print(json.dumps({'status': provenance['status'], 'at_utc': now()}), flush=True)
        return 0 if success else 1
    except Exception as exc:
        provenance.update(status='failed_validation_or_dispatch', error=type(exc).__name__ + ': ' + str(exc),
                          finished_at_utc=now())
        write(provenance_path, provenance)
        print(json.dumps({'status': provenance['status'], 'error': provenance['error']}), flush=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())

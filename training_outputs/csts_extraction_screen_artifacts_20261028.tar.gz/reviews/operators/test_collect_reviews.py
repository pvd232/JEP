"""No-model, synthetic retained-proof fixtures for the derived review collector."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile

BASE = Path('/tmp/jep-extraction-reference-capture-20261028')
spec = importlib.util.spec_from_file_location('collector_under_test', BASE/'collect_reviews.py')
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)
operator = collector.locked_module(BASE/'review_candidates.py', 'locked_test_operator', collector.OPERATOR_SHA)
REVIEWER = 'model:gpt-6.1-sol:max:review-a'
ITEMS = [{'candidate_id': 'synthetic_candidate', 'passage': 'A dog runs.',
          'condition': 'type of animal', 'expected_answer': 'One dog.',
          'raw_output': 'One dog.', 'structurally_valid': True}]
ROW = {'candidate_id': 'synthetic_candidate', 'reviewer_id': REVIEWER,
       **{key: True for key in operator.FIELDS}, 'rationale': 'The sole animal is a dog.'}
RESPONSE = {'reviews': [ROW]}


def base_events(response):
    return [{'type': 'thread.started', 'thread_id': 'synthetic-thread'},
            {'type': 'turn.started'},
            {'type': 'item.completed', 'item': {'type': 'agent_message',
                                               'text': json.dumps(response)}},
            {'type': 'turn.completed'}]


def write_fixture(root, *, response=None, events=None, audit='normal'):
    folder = root/'batch-000'
    folder.mkdir(exist_ok=True)
    response = RESPONSE if response is None else response
    events = base_events(response) if events is None else events
    prompt = (operator.RUBRIC+'\nREVIEWER_ID: '+json.dumps(REVIEWER)+
              '\n\nBLINDED INPUTS:\n'+json.dumps(ITEMS, ensure_ascii=False))
    (folder/'prompt.txt').write_text(prompt)
    (folder/'schema.json').write_text(json.dumps(collector.expected_schema(operator, ITEMS, REVIEWER)))
    (folder/'command.json').write_text(json.dumps(collector.expected_command(operator, root, folder)))
    (folder/'response.json').write_text(json.dumps(response))
    (folder/'events.jsonl').write_text('\n'.join(json.dumps(event) for event in events)+'\n')
    path = folder/'audit.json'
    if audit == 'missing':
        if path.exists(): path.unlink()
    else:
        data = {'status': 'completed', 'candidate_ids': ['synthetic_candidate'], 'exit_code': 0}
        if audit != 'normal': data.update(audit)
        path.write_text(json.dumps(data))
    return folder


checks = []


def check(name, callback, succeeds):
    try:
        callback()
    except (ValueError, TypeError):
        assert not succeeds, name+' unexpectedly failed'
    else:
        assert succeeds, name+' unexpectedly passed'
    checks.append(name)


with tempfile.TemporaryDirectory(prefix='collector-synthetic-tests-') as tmp:
    root = Path(tmp)
    def capture(**kwargs):
        write_fixture(root, **kwargs)
        return collector.validate_capture(operator, root, 0, ITEMS, REVIEWER)
    check('valid retained proof accepted', lambda: capture(), True)
    for message in ('Reconnecting... 1/5 (request timed out)',
                    'Reconnecting... 5/5 (stream disconnected before completion: invalid peer certificate: UnknownIssuer)'):
        events = base_events(RESPONSE)
        events.insert(2, {'type': 'error', 'message': message})
        check('exact warning accepted '+message, lambda ev=events: capture(events=ev, audit={'status': 'failed'}), True)
    events = base_events(RESPONSE)
    events.insert(2, {'type': 'error', 'message': 'Reconnecting... 6/5 (request timed out)'})
    check('nonallowlisted reconnect rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.insert(2, {'type': 'error', 'message': 'Reconnecting... 1/5 (request timed out)', 'extra': True})
    check('extra warning fields rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.insert(2, {'type': 'turn.failed', 'error': {'message': 'failure'}})
    check('failed turn rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.insert(2, {'type': 'item.completed', 'item': {'type': 'command_execution'}})
    check('tool activity rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.insert(2, copy.deepcopy(events[2]))
    check('extra final response rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.append({'type': 'thread.started', 'thread_id': 'another'})
    check('event after completed turn rejected', lambda: capture(events=events), False)
    events = base_events(RESPONSE)
    events.insert(2, {'type': 'unknown.event'})
    check('unknown event rejected', lambda: capture(events=events), False)
    check('missing audit rejected', lambda: capture(audit='missing'), False)
    for exit_code in (None, False, 1):
        check('invalid audit exit rejected '+repr(exit_code), lambda value=exit_code: capture(audit={'exit_code': value}), False)
    changed = copy.deepcopy(RESPONSE)
    changed['reviews'][0]['rationale'] = 'A changed retained response.'
    check('changed final-response rejected', lambda: capture(response=changed, events=base_events(RESPONSE)), False)
    bad = copy.deepcopy(RESPONSE)
    bad['reviews'][0]['faithful'] = 'true'
    check('string boolean rejected', lambda: capture(response=bad), False)
    bad = copy.deepcopy(RESPONSE)
    bad['reviews'][0]['reviewer_id'] = 'wrong'
    check('wrong reviewer rejected', lambda: capture(response=bad), False)
    check('missing candidate rejected', lambda: capture(response={'reviews': []}), False)
    check('duplicate JSON keys rejected', lambda: collector.decode('{"reviews":[],"reviews":[]}'), False)
    check('nonfinite JSON rejected', lambda: collector.decode('{"x":NaN}'), False)
    recovery_root = (BASE/'review-b-capacity-recovery').resolve()
    command = collector.expected_command(operator, recovery_root, recovery_root/'batch-024')
    for flag, value in (('-C', str(BASE/'review-b-capacity-recovery'/'closed-book')),
                        ('--output-schema', str(BASE/'review-b-capacity-recovery'/'batch-024'/'schema.json')),
                        ('-o', str(BASE/'review-b-capacity-recovery'/'batch-024'/'response.json'))):
        assert command[command.index(flag)+1] == value, 'Recovery literal /tmp command regression'
    checks.append('approved recovery literal /tmp paths preserved')

print(json.dumps({'synthetic_checks_passed': len(checks), 'model_calls': 0,
                  'original_artifact_writes': 0, 'checks': checks}, indent=2))

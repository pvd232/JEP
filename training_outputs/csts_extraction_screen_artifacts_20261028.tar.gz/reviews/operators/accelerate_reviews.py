#!/usr/bin/env python3
"""Cooperatively claim untouched review batches using the unchanged operator.

Scheduling amendment only. An existing batch directory is never modified/retried.
The original operator's atomic folder.mkdir() owns the claim before any prompt or
inference. Collisions are skips, not calls. All original parent/audit files remain.
"""
import argparse
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import ssl
import sys
import time

EXPECTED_OPERATOR_SHA = 'e1d19b1dab47d71aaaa558c5dd79580decf721a261c4b4c85170b0f60c93997f'
OPERATOR = Path('/tmp/jep-extraction-reference-capture-20261028/review_candidates.py')
EXTRA_WORKERS = 4


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def load_operator():
    actual = sha(OPERATOR.read_bytes())
    if actual != EXPECTED_OPERATOR_SHA:
        raise ValueError('Original review operator changed; refusing cooperative scheduling')
    spec = importlib.util.spec_from_file_location('unchanged_review_operator', OPERATOR)
    operator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(operator)
    return operator


def reconstruct(operator, review):
    provenance_raw = (review / 'provenance.json').read_bytes()
    provenance = json.loads(provenance_raw)
    if (provenance['reviewer_id'] not in ('model:gpt-6.1-sol:max:review-a',
                                         'model:gpt-6.1-sol:max:review-b')
            or provenance['model_alias'] != 'gpt-6.1-sol'
            or provenance['reasoning_effort'] != 'max'
            or provenance['candidate_count'] != 717 or provenance['batch_size'] != 12):
        raise ValueError('Original review provenance differs from the locked design')
    packet_raw, packet = operator.read_packet(Path(provenance['packet_path']))
    if sha(packet_raw) != provenance['packet_sha256'] or len(packet) != 717:
        raise ValueError('Original blinded packet changed or has incomplete coverage')
    order_seed = sha((str(provenance['seed']) + ':' + provenance['reviewer_id']).encode())
    if order_seed != provenance['derived_order_seed_sha256']:
        raise ValueError('Original batch-order seed differs')
    ordered = [{key: row[key] for key in operator.INPUT_FIELDS} for row in packet]
    random.Random(order_seed).shuffle(ordered)
    batches = [ordered[i:i+operator.BATCH_SIZE]
               for i in range(0, len(ordered), operator.BATCH_SIZE)]
    if len(batches) != 60 or operator.BATCH_SIZE != 12:
        raise ValueError('Unexpected reconstructed review batch count')
    # Verify any already-started batch prompt bytes without modifying the folder.
    for index, items in enumerate(batches):
        prompt_path = review / f'batch-{index:03d}' / 'prompt.txt'
        if prompt_path.exists():
            expected = (operator.RUBRIC + '\nREVIEWER_ID: ' + json.dumps(provenance['reviewer_id']) +
                        '\n\nBLINDED INPUTS:\n' + json.dumps(items, ensure_ascii=False))
            if prompt_path.read_text() != expected:
                raise ValueError('Reconstructed batch prompt differs from the original: ' + str(index))
    return provenance_raw, provenance, batches


def claim_one(operator, review, reviewer_id, index, items):
    started = time.monotonic()
    try:
        # review_batch begins with atomic folder.mkdir(), outside its try block.
        result = operator.review_batch(index, items, review, reviewer_id)
        return {key: value for key, value in result.items() if key != 'reviews'}
    except FileExistsError:
        return {'batch': index, 'status': 'skipped_existing_atomic_claim',
                'model_calls': 0, 'batch_folder_writes': 0,
                'seconds': round(time.monotonic() - started, 2)}
    except Exception as exc:
        return {'batch': index, 'status': 'failed_acceleration_dispatch',
                'error': type(exc).__name__ + ': ' + str(exc),
                'seconds': round(time.monotonic() - started, 2)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    review, output = args.review_dir.resolve(), args.output.resolve()
    if output.exists():
        raise ValueError('Acceleration output already exists; refusing duplicate dispatch')
    operator = load_operator()
    provenance_raw, original, batches = reconstruct(operator, review)
    # Secure trust is scoped to this new process and its new child processes.
    import certifi
    ca_path = Path(certifi.where())
    context = ssl.create_default_context(cafile=str(ca_path))
    if context.verify_mode != ssl.CERT_REQUIRED or not context.check_hostname:
        raise ValueError('Certificate validation and hostname verification must remain enabled')
    os.environ['CODEX_CA_CERTIFICATE'] = str(ca_path)
    output.mkdir(parents=True)
    amendment = {'amendment_type': 'Scheduling and secure per-process CA only; no scientific prompt/schema/model change',
                 'review_type': 'MODEL-ASSISTED BLINDED REVIEW; NOT HUMAN EXPERT ADJUDICATION',
                 'status': 'recorded_before_claims', 'started_at_utc': now(),
                 'operator_path': str(OPERATOR), 'operator_sha256': EXPECTED_OPERATOR_SHA,
                 'accelerator_sha256': sha(Path(__file__).read_bytes()),
                 'original_review_directory': str(review),
                 'original_provenance_sha256_at_dispatch': sha(provenance_raw),
                 'reviewer_id': original['reviewer_id'], 'seed': original['seed'],
                 'packet_sha256': original['packet_sha256'],
                 'batch_size': operator.BATCH_SIZE, 'batch_count': len(batches),
                 'original_workers_per_review': 6, 'additional_workers_per_review': EXTRA_WORKERS,
                 'maximum_combined_workers_per_review': 10,
                 'claim_order': 'reverse existing batch index; per-batch contents/order unchanged',
                 'claim_rule': 'Unchanged review_batch atomic folder.mkdir() before any write or inference; FileExistsError skips with zero writes/calls.',
                 'semantic_retries': 0, 'existing_folder_retries': 0,
                 'known_existing_failed_folders': 'Never rerun; failures remain explicit.',
                 'parent_aggregation_note': 'Original parent may mark accelerator-owned folder collisions failed; derive a separate collector output from retained per-folder proofs after all workers finish. Original statuses are preserved.',
                 'secure_trust': {'environment_variable': 'CODEX_CA_CERTIFICATE',
                                  'value': str(ca_path), 'certificate_bundle_sha256': sha(ca_path.read_bytes()),
                                  'certifi_version': certifi.__version__,
                                  'certificate_validation': True, 'hostname_verification': True,
                                  'scope': 'This accelerator process and its new subprocesses only'}}
    save(output / 'scheduling-amendment.json', amendment)
    print(json.dumps({'status': amendment['status'], 'reviewer_id': original['reviewer_id'],
                      'additional_workers': EXTRA_WORKERS}), flush=True)
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=EXTRA_WORKERS) as pool:
        pending = {pool.submit(claim_one, operator, review, original['reviewer_id'], index, batches[index]): index
                   for index in reversed(range(len(batches)))}
        for future in concurrent.futures.as_completed(pending):
            result = future.result()
            results.append(result)
            save(output / 'batch-status.json', sorted(results, key=lambda row: row['batch']))
            print(json.dumps({key: value for key, value in result.items()
                              if key != 'candidate_ids'}), flush=True)
    amendment.update(status='acceleration_finished', finished_at_utc=now(),
                     batch_status_counts={status: sum(row['status'] == status for row in results)
                                          for status in sorted({row['status'] for row in results})})
    save(output / 'scheduling-amendment.json', amendment)
    print(json.dumps({'status': amendment['status'],
                      'batch_status_counts': amendment['batch_status_counts']}), flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(1)

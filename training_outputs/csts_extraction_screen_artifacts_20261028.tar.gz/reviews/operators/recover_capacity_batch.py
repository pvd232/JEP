#!/usr/bin/env python3
"""One declared operational recovery of review-B batch024; no semantic retries."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import ssl
import sys

BASE = Path('/tmp/jep-extraction-reference-capture-20261028')
ORIGINAL = BASE / 'review-b'
OUTPUT = BASE / 'review-b-capacity-recovery'
INDEX = 24
REVIEWER = 'model:gpt-6.1-sol:max:review-b'
OPERATOR_SHA = 'e1d19b1dab47d71aaaa558c5dd79580decf721a261c4b4c85170b0f60c93997f'
ACCELERATOR_SHA = 'c0aa0280cd24e2cd6d6a9d3a432a932c606a77e74a80a596b4acd439a6e37c07'
CAPACITY_MESSAGE = 'Selected model is at capacity. Please try a different model.'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def load(path, name, expected_sha):
    if sha(path.read_bytes()) != expected_sha:
        raise ValueError('Hash-locked operator/helper changed')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    operator = load(BASE / 'review_candidates.py', 'unchanged_operator', OPERATOR_SHA)
    scheduler = load(BASE / 'accelerate_reviews.py', 'approved_scheduler', ACCELERATOR_SHA)
    _, provenance, batches = scheduler.reconstruct(operator, ORIGINAL)
    if provenance['reviewer_id'] != REVIEWER:
        raise ValueError('This narrow recovery applies only to original review-B')
    folder = ORIGINAL / f'batch-{INDEX:03d}'
    original_audit = json.loads((folder / 'audit.json').read_text())
    events = [json.loads(line) for line in (folder / 'events.jsonl').read_text().splitlines()
              if line.strip()]
    if (original_audit.get('status') != 'failed'
            or original_audit.get('exit_code') in (None, 0)
            or (folder / 'response.json').exists()):
        raise ValueError('Original does not meet nonzero/no-response capacity recovery policy')
    if [event.get('type') for event in events] != ['thread.started', 'turn.started', 'error', 'turn.failed']:
        raise ValueError('Unexpected original event history; no recovery allowed')
    if events[2].get('message') != CAPACITY_MESSAGE:
        raise ValueError('Original error is not the exact observed capacity rejection')
    failed_error = events[3].get('error')
    if isinstance(failed_error, dict):
        failed_error = failed_error.get('message')
    if failed_error != CAPACITY_MESSAGE:
        raise ValueError('Terminal failure is not the same capacity rejection')
    if any(event.get('item') for event in events):
        raise ValueError('Original contains scored/tool content; no recovery allowed')
    items = batches[INDEX]
    if len(items) != 12 or original_audit['candidate_ids'] != [row['candidate_id'] for row in items]:
        raise ValueError('Capacity recovery candidate coverage differs')
    expected_prompt = (operator.RUBRIC + '\nREVIEWER_ID: ' + json.dumps(REVIEWER) +
                       '\n\nBLINDED INPUTS:\n' + json.dumps(items, ensure_ascii=False))
    if (folder / 'prompt.txt').read_text() != expected_prompt:
        raise ValueError('Capacity recovery prompt differs from original')
    original_schema = json.loads((folder / 'schema.json').read_text())
    properties = {'candidate_id': {'type': 'string', 'enum': [row['candidate_id'] for row in items]},
                  'reviewer_id': {'type': 'string', 'enum': [REVIEWER]},
                  **{field: {'type': 'boolean'} for field in operator.FIELDS},
                  'rationale': {'type': 'string'}}
    expected_schema = {'type': 'object', 'additionalProperties': False,
                       'properties': {'reviews': {'type': 'array', 'items': {
                           'type': 'object', 'additionalProperties': False,
                           'properties': properties, 'required': list(properties)}}},
                       'required': ['reviews']}
    if original_schema != expected_schema:
        raise ValueError('Capacity recovery schema differs from original')
    import certifi
    ca_path = Path(certifi.where())
    context = ssl.create_default_context(cafile=str(ca_path))
    if context.verify_mode != ssl.CERT_REQUIRED or not context.check_hostname:
        raise ValueError('Secure certificate and hostname validation required')
    os.environ['CODEX_CA_CERTIFICATE'] = str(ca_path)
    # Atomic recovery-root claim prevents a second operational recovery attempt.
    OUTPUT.mkdir()
    (OUTPUT / 'closed-book').mkdir()
    hashes = {p.name: sha(p.read_bytes()) for p in sorted(folder.iterdir()) if p.is_file()}
    receipt = {'policy': 'Exactly one separately recorded capacity-only operational recovery; not best-of and not a semantic retry',
               'recorded_before_model_call_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'status': 'authorized_capacity_recovery_before_call',
               'authorization': 'Root explicitly authorized exactly one B024 capacity-only recovery; code_review independently approved the narrow policy and launch code.',
               'review_type': 'MODEL-ASSISTED BLINDED REVIEW; NOT HUMAN EXPERT ADJUDICATION',
               'original_folder': str(folder), 'original_status_preserved': 'failed',
               'original_artifact_sha256': hashes, 'original_response_absent': True,
               'original_error_exact': CAPACITY_MESSAGE, 'original_exit_code': original_audit['exit_code'],
               'original_had_no_scored_content': True,
               'candidate_ids': [row['candidate_id'] for row in items],
               'reviewer_id': REVIEWER, 'seed': provenance['seed'], 'model_alias': operator.MODEL,
               'reasoning_effort': 'max', 'operator_sha256': OPERATOR_SHA,
               'recovery_helper_sha256': sha(Path(__file__).read_bytes()),
               'same_prompt_sha256': sha(expected_prompt.encode()),
               'same_schema': True, 'maximum_recovery_calls': 1,
               'operator_semantic_retries': 0, 'further_failure_policy': 'Retain unreviewed bounds; no further automatic attempt.',
               'secure_trust': {'CODEX_CA_CERTIFICATE': str(ca_path),
                                'certificate_bundle_sha256': sha(ca_path.read_bytes()),
                                'certificate_validation': True, 'hostname_verification': True}}
    save(OUTPUT / 'capacity-recovery-policy.json', receipt)
    print(json.dumps({'status': receipt['status'], 'batch': INDEX}), flush=True)
    # One invocation only, using the exact unchanged semantic operator and batch.
    result = operator.review_batch(INDEX, items, OUTPUT, REVIEWER)
    save(OUTPUT / 'recovery-result.json', {key: value for key, value in result.items() if key != 'reviews'})
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('reviews', 'candidate_ids')}), flush=True)
    return 0 if result['status'] == 'completed' else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(1)

# Optional historical KnowCoder author-runtime probe

Prepared only. No environment installation, GPU access or inference is authorized by this package.

The fixture, source and original design files are byte-identical to the sealed v2 repair package. Each invocation loads one separately declared checkpoint. The existing primary screen and modern repair outputs remain untouched. This probe reproduces the historical core versions and author inference settings; the host OS and GPU driver remain current.

## Proposed isolated setup

The official vLLM v0.2.2 release contains a CPython 3.10 CUDA 11.8 wheel. Python 3.12/3.13 cannot use that wheel. Use a separate interpreter and environment, never modify the notebook environment:

```sh
uv python install 3.10
uv venv --python 3.10 /content/knowcoder-author-py310
uv pip install --python /content/knowcoder-author-py310/bin/python \
  'https://download.pytorch.org/whl/cu118/torch-2.1.0%2Bcu118-cp310-cp310-linux_x86_64.whl' \
  'https://download.pytorch.org/whl/cu118/xformers-0.0.22.post7%2Bcu118-cp310-cp310-manylinux2014_x86_64.whl' \
  'https://github.com/vllm-project/vllm/releases/download/v0.2.2/vllm-0.2.2%2Bcu118-cp310-cp310-manylinux1_x86_64.whl' \
  transformers==4.34.1 tokenizers==0.14.1 huggingface-hub==0.17.3 \
  numpy==1.25.2 ray==2.8.1 pyarrow==14.0.1 pandas==2.1.3 \
  sentencepiece==0.1.99 einops==0.7.0 psutil==5.9.6 ninja==1.11.1.1 \
  pydantic==1.10.13 fastapi==0.104.1 uvicorn==0.24.0.post1 protobuf==4.25.1
uv pip check --python /content/knowcoder-author-py310/bin/python
```

These core pins come from the author freeze. It also contains unrelated notebook/training packages and unavailable development builds; those are deliberately excluded. FlashAttention compilation is unnecessary for this vLLM inference path. The installation commands above have not been executed or runtime-tested.

Before authorizing model execution, save the resolved environment and test imports including `vllm._C`. Check free GPU memory after any prior model process exits.

## Future invocation after explicit operator authorization

```sh
/content/knowcoder-author-py310/bin/python legacy-vllm/run_legacy.py \
  --checkpoint base \
  --snapshot-path /existing/cache/models--golaxy--KnowCoder-7B-base/snapshots/4a7a076f573fe87fe0a97670c63c64214484742f \
  --output /content/knowcoder-legacy-base-results-20261028
```

Use `--checkpoint ie` and the separately pinned snapshot `90ba076763dfb2e9efefd84a0e599f15ae533597` in another process if authorized. Output directories must be fresh. The runner downloads no model files and requires existing complete pinned snapshots.

The runner gates installed vLLM, Torch, Transformers and Tokenizers versions before importing the GPU runtime. It validates exact metadata, vocabulary, architecture and the 291 indexed parameter names; existing shard sizes and official HF cache object names are checked. It does not claim to introspect all live vLLM parameter tensors or recompute full shard hashes.

All 15 fixed prompts per checkpoint are encoded with the author's fast tokenizer settings. No source truncation occurs. The LLM constructor uses author max_model_len=4096, max_num_seqs=4, max_num_batched_tokens=16384 and dtype=auto, which must resolve to FP16. Sampling uses n=1, best_of=1, temperature=0, triple-quote stopping and author max_tokens=640. This 640-token author setting is an explicit change from the modern diagnostic's 1024-token cap.

Inputs, actual returned prompt IDs, output IDs, API text, raw decodes, precision and environment are retained. All raw batch completions are saved before response validation. The runner parses both API text and the exact author token-ID decoding projection, declared in advance. Parsing uses the unchanged v2 AST parser; generated code is never executed. Empty outputs, schema failures and semantic correctness are distinct.

## Primary provenance

- Author requirements: https://github.com/ICT-GoKnow/KnowCoder/blob/b7859789fc7641e03916074088859aa592332ad3/sft/requirements.txt
- Author inference: https://github.com/ICT-GoKnow/KnowCoder/blob/b7859789fc7641e03916074088859aa592332ad3/eval/src/inference.py
- Official release/assets: https://github.com/vllm-project/vllm/releases/tag/v0.2.2
- Verified v0.2.2 APIs, copied verbatim for audit: https://github.com/vllm-project/vllm/blob/v0.2.2/vllm/entrypoints/llm.py and https://github.com/vllm-project/vllm/blob/v0.2.2/vllm/outputs.py
- Official Torch wheel SHA256: a81b554184492005543ddc32e96469f9369d778dedd195d73bda9bed407d6589
- Official xFormers wheel SHA256: 06377ae0e94f9b4fe99e08663dbf3d0d133535d7648e050e435f881facc3b34d
- NVIDIA backward compatibility: https://docs.nvidia.com/deploy/cuda-compatibility/frequently-asked-questions.html

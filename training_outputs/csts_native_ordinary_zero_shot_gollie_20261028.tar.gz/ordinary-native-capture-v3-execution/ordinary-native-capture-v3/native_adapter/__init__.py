"""Isolated task-aware native extraction proposal; no model runtime is imported."""

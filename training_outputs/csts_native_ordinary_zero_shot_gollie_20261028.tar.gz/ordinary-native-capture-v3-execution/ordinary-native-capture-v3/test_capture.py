"""CPU-only tests for frozen ordinary capture binding and safe parsing."""
from pathlib import Path
import importlib.util
import json
import sys
import unittest
import tempfile
import shutil
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,'/tmp/jep-native-tokenizer-20261028')
from tokenizers import Tokenizer
import run_capture as capture

class ActualTokenizer:
    def __init__(self):
        self.inner=Tokenizer.from_file(str(ROOT/'legacy_support/pinned-metadata/ie/tokenizer.json'))
    def encode(self,prompt,add_special_tokens=True):
        return self.inner.encode(prompt,add_special_tokens=add_special_tokens).ids

class CaptureTests(unittest.TestCase):
    def test_frozen_nine_and_two_exact_controls(self):
        cases=capture.build_cases('knowcoder_ie',ActualTokenizer())
        self.assertEqual(len(cases),11)
        self.assertEqual(sum(x['kind']=='ordinary' for x in cases),9)
        original=json.loads((ROOT/'know-companions.json').read_text())
        for case,reference in zip(cases[9:],original):
            self.assertEqual(case['prompt'],reference['variant']['prompt'])
            self.assertEqual(capture.sha(case['prompt'].encode()),reference['prompt_sha256'])
        for case in cases[:9]:
            self.assertNotIn('Negated',case['prompt'])
            self.assertNotIn('Uncertain',case['prompt'])
            self.assertIn('object-oriented programming task',case['prompt'])

    def test_go_runtime_count_only_and_helper_drift_rejected(self):
        class GoTokenizer:
            eos_token_id=2
            def encode(self,prompt,add_special_tokens=True):
                return [1]+[3]*max(1,len(prompt)//100)+[2]
        self.assertEqual(len(capture.build_cases('gollie',GoTokenizer())),9)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            shutil.copyfile(ROOT/'ordinary-requests.json',root/'ordinary-requests.json')
            contracts=json.loads((ROOT/'gollie-binding-contracts.json').read_text())
            contracts['animal']['implementation_sha256']['schema.py']='0'*64
            (root/'gollie-binding-contracts.json').write_text(json.dumps(contracts))
            with patch.object(capture,'ROOT',root):
                with self.assertRaisesRegex(ValueError,'Frozen Go binding differs'):
                    capture.build_cases('gollie',GoTokenizer())

    def test_native_food_and_malicious_output_distinguished(self):
        food=next(x for x in capture.build_cases('knowcoder_ie',ActualTokenizer()) if x['case_id']=='food')
        valid=capture.classify({'api_text':'results = [Food("sandwich"), Food("pickle")]','truncated':False},food,'knowcoder_ie')
        self.assertEqual(valid['native_status'],'parsed_and_grounded')
        self.assertFalse(valid['empty_list_emitted'])
        empty=capture.classify({'api_text':'results = []','truncated':False},food,'knowcoder_ie')
        self.assertTrue(empty['empty_list_emitted'])
        bad=capture.classify({'api_text':"__import__('os').system('false')",'truncated':False},food,'knowcoder_ie')
        self.assertEqual(bad['native_status'],'schema_or_grounding_failed')

    def test_truncation_is_not_an_abstention(self):
        food=next(x for x in capture.build_cases('knowcoder_ie',ActualTokenizer()) if x['case_id']=='food')
        result=capture.classify({'api_text':'results = [','truncated':True},food,'knowcoder_ie')
        self.assertTrue(result['truncated'])
        self.assertIsNone(result['empty_list_emitted'])
        self.assertIn('exhausted',result['error'])

if __name__=='__main__':unittest.main()

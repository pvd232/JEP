"""Model-only development packet for the 21 newly specified condition scopes."""
import hashlib,json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from native_adapter.schema import compile_condition,implementation_identity,native_prompt,plan_digest
conditions={'background features','contents of bathroom','design of bathroom','environment','items used by people','man with food','means of transportation','method of transportation','mode of transportation','nature of place',"object's purpose", "people's immediate attention",'person','purpose of running','quantity of food','rider','substance on ground','sweetness of food','train on track','type of hobby','type of play'}
items=[]
for row in json.loads(Path('/tmp/jep-extraction-a100-screen-v2-20261028/sources.json').read_text()):
 if row['condition'] not in conditions:continue
 plan=compile_condition(row['condition']);requests={}
 for model in ('gollie','knowcoder'):
  requests[model]={}
  for stage in list(plan.get('stage_contract') or {None:None}):
   prompt=native_prompt(plan,model,row['passage'],task_stage=stage,profile='positive_anchor')
   requests[model][stage or '__single__']={'prompt':prompt,'model':model,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'plan_sha256':plan_digest(plan),'profile':'positive_anchor','task_stage':stage,'count_stage':None,'implementation_sha256':implementation_identity(),'max_new_tokens':512,'actual_tokenizer_check_required':True,'purpose':'exposed_scope_contract_development_only'}
 items.append({'source_id':row['id'],'condition':row['condition'],'passage':row['passage'],'plan':plan,'plan_sha256':plan_digest(plan),'profile':'positive_anchor','coverage_complete':False,'requests':requests})
value={'status':'proposed_scope_contracts_not_executed_or_production_approved','sources':len(items),'conditions':len(conditions),'items':items,'model_calls':0,'warning':'No answers/gold provided to models. A proposed scope contract is not model fidelity or ground truth. Root/reviewer must authorize an explicit finite development batch.'}
path=ROOT/'evidence/scope_development_inputs_v1.json';path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');print(path,len(items))

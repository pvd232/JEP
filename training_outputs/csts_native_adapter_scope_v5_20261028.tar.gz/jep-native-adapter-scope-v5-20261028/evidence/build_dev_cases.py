"""Project known development sources into finite, source-grounded gate fixtures."""
import json,pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from native_adapter.schema import compile_condition,plan_digest
rows=json.loads(pathlib.Path('/tmp/jep-extraction-a100-screen-v2-20261028/sources.json').read_text())
by_id={row['id']:row for row in rows}
selected=[
 ('animal','0e0f8e525cb9cab9cd247b885b55b18c701e71f9424a2bf7c585c8b4290ffdc5', "[Animal(span='elephant')]", "[Animal('elephant')]"),
 ('food','038c7bfbf57a1553e093ee710a45dfa397f4214cae400afc4a69fc07dda9819f', "[Food(span='sandwich'), Food(span='pickle')]", "[Food('sandwich'), Food('pickle')]"),
 ('vehicle','09a106cd7adabcbd963da9cb273d410ce07e34b12323ccfa9d3dc3b0f0b47358', "[Vehicle(span='train')]", "[Vehicle('train')]"),
 ('helmet','5e85e75e8c5a68fc1892b938c6bb0a5d0b19c0663377423fa4b589d0fab170f0', "[Helmet(span='blue helmets')]", "[Helmet('blue helmets')]"),
 ('animal_color','4268cdb2b8327804ae548041f12f7d7b7a5ed4fffb40ff31c2a8a8d70b60a268', "[HasColor(object='brown dog', color='brown')]", "[Color(Entity('brown dog'), Entity('brown'))]"),
 ('board_color','0895cb7b5b9c6063ccadbb60d35423140dc64d0a848cda1af164f3b08e623829', "[HasColor(object='white surfboard', color='white')]", "[Color(Entity('white surfboard'), Entity('white'))]"),
 ('spatial_qualifier','6bddbf603e3180f308879b8364c46495b83b479616febc1bc6aa126277167831', "[Location(arg1='A boy', arg2='near the water')]", "[Location(Entity('A boy'), Entity('near the water'))]"),
 ('dog_event','24b010d7477d6d2e8e19f5cf4f35519aad527f4b720692a915517314f25fc398', "[ActivityEvent(mention='fetches', actor=['A dog'], theme=['a stick'], place=['the dead leaves'])]", "[ActivityEvent(trigger='fetches', actor=[Entity('A dog')], theme=[Entity('a stick')], place=[Entity('the dead leaves')])]"),
 ('person_event','735dffb9c8117d53c584d5efdd59df2dff1ca364dc0f13a4fd24f1116e1c4584', "[MovementEvent(mention='throws', actor=['A little girl'], theme=['leaves'], place=['in front of a fence'])]", "[MovementEvent(trigger='throws', actor=[Entity('A little girl')], theme=[Entity('leaves')], place=[Entity('in front of a fence')])]"),
]
cases=[]
for name,identity,go,know in selected:
 row=by_id[identity];plan=compile_condition(row['condition'])
 expected_types = {'animal':['Animal'], 'food':['Food'], 'vehicle':['Vehicle'], 'helmet':['Clothing'], 'animal_color':['Animal','Color'], 'board_color':['Object','Color'], 'spatial_qualifier':['Person','Location'], 'dog_event':['Animal','Entity','Location'], 'person_event':['Person','Entity','Location']}[name]
 cases.append({'case_id':name,'source_id':identity,'provenance':'exposed_development_source','condition':row['condition'],'passage':row['passage'],'family':plan['family'],'profile':'positive_anchor','plan_sha256':plan_digest(plan),'gate_kind':'minimal_native_anchor_smoke','completeness_established':False,'independent_expected_entity_types':expected_types,'expected_native_annotations':{'gollie':go,'knowcoder':know},'model_accuracy_verified':False})
value={'status':'gold_fixture_proposal_requires_independent_semantic_review','cases':cases,'warning':'These supplied annotations test schema/projection. No model has emitted them; passing unit tests does not establish model fidelity.'}
path=pathlib.Path(__file__).with_name('development_gate_cases_v3.json');path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(path,len(cases))

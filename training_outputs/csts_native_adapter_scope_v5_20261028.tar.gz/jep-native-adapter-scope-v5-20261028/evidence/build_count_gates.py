"""Finite exposed-source gates for three independent native count stages."""

import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from native_adapter.schema import compile_condition,implementation_identity,native_prompt,plan_digest
from native_adapter.normalize import normalize_stages

rows=json.loads(Path('/tmp/jep-extraction-a100-screen-v2-20261028/sources.json').read_text())
by_id={row['id']:row for row in rows}
# Every annotation below is a proposed source-grounded development reference,
# not generated output. No similarity label or locked gold is consumed.
selected=[
 ('three_plus_one','0a7d36e084bd22ea9dc3c763c84b3c2bbbc7e37f7876d3971665079e307a0a9e','PersonGroup',['Three people','a man'],['Three'],[('Three people','Three')],[('DistinctFrom','Three people','a man')],4),
 ('repeated_dog_is_subset','11c0d8914453aec9c3b5364f1acb3f28293bdf2f727791568aa72df1f1a2d84e','AnimalGroup',['Two black dogs','one dog'],['Two','one'],[('Two black dogs','Two'),('one dog','one')],[('PartOf','one dog','Two black dogs')],2),
 ('unspecified_plural','7507127642c646106a0ede6e36b0c349ae5c7ae184fbcc3ceb7fe8cda9a355be','PersonGroup',['A number of children'],[],[],[],2),
 ('jersey_not_population','b2a6650564ccf6aa6ff9bca716fdbc30fab8a17c2848eb3446547d29ac22eb29','AnimalGroup',['A brown and white greyhound'],[],[],[],1),
 ('unmentioned_wheels','3165c2eace681157890fd25ee5c9a441c2dbea2abc7fd49492a56f16f6803670','WheelGroup',[],[],[],[],None),
 ('women_excludes_untyped_baby','929a87372d3bad3712d71e2e02cb9751f1f39e266c26222d1f0838ab9a140cd8','WomanGroup',['Two older women'],['Two'],[('Two older women','Two')],[],2),
]

def literal_list(values):return '['+', '.join(values)+']'
cases=[];inputs=[]
for case_id,identity,label,groups,quantities,bindings,edges,lower in selected:
 row=by_id[identity];plan=compile_condition(row['condition'])
 expected={};requests={}
 for model in ('gollie','knowcoder'):
  ent=lambda name,text: name+('('+repr(text)+')' if model=='knowcoder' else '(span='+repr(text)+')')
  rel=lambda name,left,right: name+('(Entity('+repr(left)+'), Entity('+repr(right)+'))' if model=='knowcoder' else '(arg1='+repr(left)+', arg2='+repr(right)+')')
  stage_payloads={
   'mentions':literal_list([ent(label,text) for text in groups]+[ent('Quantity',text) for text in quantities]),
   'quantity_bindings':literal_list([rel('HasQuantity',left,right) for left,right in bindings]),
   'identity':literal_list([rel(name,left,right) for name,left,right in edges]),
  }
  graph=normalize_stages(stage_payloads,plan,model,row['passage'],coverage_complete=False,profile='positive_anchor')
  if lower is None:
   assert graph['status']=='not_specified' and graph['quantity']['kind']=='unknown'
  else:
   assert graph['quantity']['kind']=='lower_bound' and graph['quantity']['lower']==lower
  expected[model]=stage_payloads
  requests[model]={}
  for stage in plan['aggregation']['stages']:
   prompt=native_prompt(plan,model,row['passage'],count_stage=stage,profile='positive_anchor')
   requests[model][stage]={'prompt':prompt,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'plan_sha256':plan_digest(plan),'profile':'positive_anchor','count_stage':stage,'task_stage':None,'max_new_tokens':512,'implementation_sha256':implementation_identity(),'ordinary_count_dispatch_enabled':False,'purpose':'finite_exposed_count_stage_canary_only','actual_tokenizer_check_required':True}
 common={'case_id':case_id,'source_id':identity,'condition':row['condition'],'passage':row['passage'],'plan':plan,'plan_sha256':plan_digest(plan),'profile':'positive_anchor','coverage_complete':False,'provenance':'already_exposed_development_source'}
 cases.append({**common,'expected_native_stages':expected,'minimal_conditional_quantity':{'kind':'unknown' if lower is None else 'lower_bound','lower':lower,'upper':None},'completeness_established':False,'review_status':'proposed_reference_requires_independent_source_review'})
 inputs.append({**common,'requests':requests})

base={'status':'not_executed_pending_independent_scope_and_reference_review','model_calls':0,'count_family_enabled':False,'stages':['mentions','quantity_bindings','identity'],'warning':'Separate source-only native tasks. Gold is not model input. Schema-valid union cannot establish source support, identity or completeness; no exact scene totals are asserted.'}
for name,value in (('count_development_gates_v1.json',{**base,'cases':cases}),('count_stage_canary_inputs_v1.json',{**base,'items':inputs})):
 path=ROOT/'evidence'/name;path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
 print(name,hashlib.sha256(path.read_bytes()).hexdigest())

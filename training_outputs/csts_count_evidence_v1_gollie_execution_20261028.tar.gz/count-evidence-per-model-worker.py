"""One frozen six-source extractive CountEvidence phase; contrast controls are never dispatched."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
ROOT=TASK/'count-evidence-v1-execution'
ENV=TASK/'environments/knowcoder-author-py310'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['knowcoder','gollie'],required=True);parser.add_argument('--protocol-sha256',required=True);args=parser.parse_args();model=args.model
    output=TASK/('results/count-evidence-v1-'+model);receipt=TASK/('results/count-evidence-v1-'+model+'-worker.json');log=TASK/('logs/count-evidence-v1-'+model+'.log');archive=TASK/('results/count-evidence-v1-'+model+'-execution.tar.gz')
    if any(path.exists() for path in [output,receipt,log,archive]):raise ValueError('CountEvidence attempt exists; inspect, do not repeat')
    record={'status':'started','phase':'preflight','model':model,'started_at':time.time(),'authorized_sources':6,'maximum_model_calls':6,'output_token_cap':512,'automatic_retries':False,'contrast_control_calls_authorized':False,'general_counts_enabled':False,'fresh_or_locked_calls':False,'model_quality_passed':False,'numeric_reasoning_claimed':False,'positive_presence_claimed':False,'identity_claimed':False}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    try:
        for prior_model in ['knowcoder_ie','gollie']:
            prior=TASK/('results/native-task-contract-v2-'+prior_model+'-worker.json')
            if json.loads(prior.read_text()).get('status')!='complete':raise RuntimeError('Prior own native worker not complete; no overlapping generation')
        if model=='gollie':
            preceding=TASK/'results/count-evidence-v1-knowcoder-worker.json'
            if (TASK/'count-evidence-v1-knowcoder-dispatch.json').exists():
                record['phase']='waiting_for_count_evidence_know_exit';write(receipt,record);deadline=time.monotonic()+1500
                while not preceding.exists() or json.loads(preceding.read_text()).get('status') not in ('complete','failed'):
                    if time.monotonic()>deadline:raise RuntimeError('Prior own CountEvidence worker did not finish')
                    time.sleep(2)
        recipe=ROOT/'recipe/extractive-count-evidence';provider=ROOT/'provider/native-general-capture'
        protocol=recipe/('protocol-exposed_six-'+model+'.json')
        if digest(protocol)!=args.protocol_sha256:raise ValueError('Reviewed CountEvidence protocol differs')
        protocol_value=json.loads(protocol.read_text())
        if protocol_value.get('phase')!='exposed_six':raise ValueError('Only six exposed sources authorized; contrasts held')
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if digest(setup)!='3ac4252a8f81be39bd713d70006fa13cd2dbf63f5876296ff1955f0728f25a94' or json.loads(setup.read_text()).get('status')!='ready_import_verified':raise ValueError('Historical runtime receipt differs')
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')];required=int(total*0.6)+8*1024 if model=='knowcoder' else 45*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: actual free memory below reviewed budget')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONPATH=str(provider)+os.pathsep+str(recipe),XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-count-evidence'))
        if model=='gollie':
            driver_root=TASK/'environments/triton-driver-discovery-v2';driver_receipt=driver_root/'receipt.json';driver=json.loads(driver_receipt.read_text())
            if digest(driver_receipt)!='4e67a2813087b42714d618ad55f733645489450096c7af3a58f16cdd544dbbd7':raise ValueError('Reviewed driver receipt differs')
            if driver['status']!='ready_cpu_discovery_verified' or digest(driver_root/'bin/ldconfig')!=driver['wrapper_sha256']:raise ValueError('Driver wrapper differs')
            runtime['PATH']=str(driver_root/'bin')+os.pathsep+runtime.get('PATH','')
            audit=TASK/'results/gollie-pinned-artifact-audit-20261028.json'
            if digest(audit)!='8caeb672bc09a34767369c27a10eb6127791062f037f53cd2827a9f1b6095418' or json.loads(audit.read_text()).get('status')!='verified':raise ValueError('Verified Go primary byte audit differs')
            record.update(driver_receipt_sha256=digest(driver_receipt),primary_artifact_audit_sha256=digest(audit))
        command=[str(ENV/'bin/python'),'-m','run_count_evidence','--model',model,'--protocol',str(protocol),'--output',str(output)]
        record.update(phase='evidence_capture',command=command,pythonpath=runtime['PYTHONPATH'],protocol_sha256=args.protocol_sha256);write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=ROOT,env=runtime,timeout=1200,check=False)
        record['returncode']=result.returncode
        if (output/'summary.json').exists():record['summary']=json.loads((output/'summary.json').read_text())
        if result.returncode or 'summary' not in record:raise RuntimeError('CountEvidence operational error; exact log/raw outputs retained')
        if record['summary'].get('phase')!='exposed_six' or record['summary'].get('planned_sources')!=6 or record['summary'].get('model_calls',7)>6:raise RuntimeError('Capture exceeded or changed the authorized six-source phase')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=digest(log) if log.exists() else None);write(receipt,record)
        index={str(path.relative_to(TASK)):digest(path) for path in sorted(output.rglob('*')) if path.is_file()} if output.exists() else {}
        index_path=TASK/('results/count-evidence-v1-'+model+'-execution-index.json');write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__),TASK/'environments/knowcoder-author-setup-amendment02.json',TASK/'environments/triton-driver-discovery-v2/receipt.json',TASK/'results/gollie-pinned-artifact-audit-20261028.json']:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            if ROOT.exists():tf.add(ROOT,arcname=str(ROOT.relative_to(TASK)))
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
        write(TASK/('results/count-evidence-v1-'+model+'-execution-archive.json'),{'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'status':record['status'],'capture_files':len(index)})
        print(json.dumps(record),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

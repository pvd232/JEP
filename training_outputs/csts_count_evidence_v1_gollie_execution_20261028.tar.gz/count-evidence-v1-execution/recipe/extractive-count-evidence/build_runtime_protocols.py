"""Freeze exact finite CountEvidence runtime protocols; no model calls."""
from pathlib import Path
import json
from copy import deepcopy
import count_evidence_capture as capture
import count_evidence_recipe as recipe

ROOT=Path(__file__).resolve().parent
PREVIOUS=Path('/tmp/jep-finite-count-runtime-20261028')
DEPLOY=Path('/content/jep-native-author-calibration-20261028/count-evidence-v1-execution')


def main():
    for phase in ('exposed_six','contrast_controls'):
        for model in ('knowcoder','gollie'):
            old=json.loads((PREVIOUS/('protocol-'+model+'.json')).read_bytes())
            cfg=old['models'][model]['native_capture']
            for key in ('finite_count_development','compiler_implementation_sha256','compiler_implementation_files',
                        'allow_compiler_stages','stage_overrides','allowed_profiles','capability_gates'):
                cfg.pop(key,None)
            cfg.update(profile='quoted_assertions',prompt_profile=recipe.PROFILE,
                count_evidence_development=capture.authorization(phase),
                support_manifest_path=str(DEPLOY/'provider/native-general-capture/support-seal.json'))
            if model=='gollie':cfg['runtime_shim']['path']=str(DEPLOY/'recipe/extractive-count-evidence/driver_runtime_shim.py')
            protocol={'status':'FROZEN_FINITE_EXTRACTIVE_COUNT_EVIDENCE_DEVELOPMENT_V1','phase':phase,
                'scope':'Same six exposed sources first; contrast controls are a separate frozen phase, never automatic companions.',
                'scene_count_reasoning':'deferred_downstream','count_repair_claimed':False,'count_accuracy_evaluated':False,
                'quality_gate_passed':False,'cost_gain_claimed':False,'shared_gpu_permitted':True,'timing_isolated':False,
                'models':{model:{'handler':{'module':'count_evidence_capture','callable':'capture_one',
                    'sha256':recipe.digest(Path(capture.__file__).read_bytes())},
                    'max_model_calls_per_source':1,'native_capture':cfg}}}
            # Verify the same manifest bytes locally before its agreed deployment.
            # The written protocol retains the exact remote support path and the
            # runtime repeats verification against that deployed location.
            preflight=deepcopy(protocol)
            preflight['models'][model]['native_capture']['support_manifest_path']=str(capture.backend.ROOT/'support-seal.json')
            for source in capture.phase_sources(phase):capture.verify_configuration(source,model,preflight)
            raw=recipe.encoded(protocol)
            (ROOT/('protocol-'+phase+'-'+model+'.json')).write_bytes(raw)
            print(phase,model,recipe.digest(raw))

if __name__=='__main__':main()

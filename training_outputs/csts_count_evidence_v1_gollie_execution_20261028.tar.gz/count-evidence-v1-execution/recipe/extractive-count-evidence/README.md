# Extractive CountEvidence, a distinct evidence-preservation candidate

This is one separately named extractive system, not another symbolic-count
prompt variant or a counting repair. It quotes count-relevant source assertions.
It produces no numeric totals, per-entity quantities, interpreted identity links,
positive Person-presence facts or symbolic count graph. Count reasoning moves to
a downstream component and is currently deferred. No count-accuracy, cost or
production-readiness gain is claimed.

The initial capture phase contains exactly the same six exposed sources/model.
The previous symbolic and conditional guided-count arms remain failed and
unchanged. Fourteen contrast controls and their separate review references were
frozen before any new model call. Those controls are a separate phase and never
automatic companion calls. Reference answers are not read by any prompt builder,
handler, capture driver or model session. The initial dispatch must use only
`protocol-exposed_six-MODEL.json`.

One condition-derived recipe selects the fixed independent Person, Animal, Woman
or Wheel scene already used in the guided-count development experiment. The
same source sentence now demonstrates only exact source quotations. Identifier
and background distractors are excluded. The prompts ask for minimal noun
phrases or clauses preserving relevant cardinals, articles, vague quantities,
negation/uncertainty, subset, inclusion, distinctness and reference cues. A longer
clause is used only when attachment/scope would be lost. There is no whole-caption
fallback, target-case answer, numeric calculation or per-case recipe selection.

`CountEvidence` uses the authors' native unary string/span constructor interface
as transport. Its canonical meaning is an uninterpreted quoted assertion, not an
Entity-presence declaration. The dedicated stdlib parser retains every exact
source offset, including multiple possible matches. It never calls the generic
entity/count normalizer or `quantity_from_text`. The quoted strings “no dogs” and
“not three dogs” remain text with their denial/category/location scope, not zero,
absence or a derived total.

The parser distinguishes literal grounded candidates, ambiguous source matches,
successful empty quote predictions and invalid/ungrounded candidates. Successful
`[]` has status `no_candidate_assertions`; it does not assert that the source
contains no entities/evidence and is not “not specified.” Malformed, ungrounded
and truncated outputs retain their actual raw syntax and fail operationally.
Canonical text can be empty for successful `[]`; it never replaces the nonempty
native raw response. Exact quoting alone does not establish relevance, minimality,
evidence sufficiency or correctness. Those remain explicitly unreviewed.

Frozen contrasts cover watching another person versus including a member;
definite repetition versus another person; jersey five versus five animals;
vague versus four children; unmentioned versus explicit wheels; women versus an
untyped baby; and no dogs versus not-three-dogs with their location scope.
Denials concern dogs in the stated place, not a global number of animals. No
explicit modal-uncertainty contrast is included, so that coverage is untested.

The approved native backend module is reused directly, with cached model/tokenizer
sessions per process. Native CountEvidence code imports no generic symbolic
normalizer. Checkpoints, actual weight-byte proofs, historical runtime, greedy
settings, Know0.6 resource cap and512 output budget are unchanged. Input/source
truncation, retries and forced nonempty outputs are absent. Exact tokenizer
budgets are frozen for both phases (Know maximum750+512; Go maximum640+512).

Deployment root is
`/content/jep-native-author-calibration-20261028/count-evidence-v1-execution`.
The approved provider is in `provider/native-general-capture`; this recipe is in
`recipe/extractive-count-evidence`. Set PYTHONPATH to provider first, recipe
second, and cwd to that root. Run one model/process:

```
HISTORICAL_PYTHON -m run_count_evidence --model knowcoder --protocol RECIPE/protocol-exposed_six-knowcoder.json --output NEW_OUTPUT
HISTORICAL_PYTHON -m run_count_evidence --model gollie --protocol RECIPE/protocol-exposed_six-gollie.json --output ANOTHER_NEW_OUTPUT
```

Each source is claimed once before capture. Outputs contain protocol and
authorization files, six attempt/result folders and a summary.json with planned
sources, actual requests, parser statuses and explicit deferred interpretation.
All prompts/bindings, raw token IDs/output, parser records, source offsets and
backend metadata are retained. The outer operator owns process serialization,
resource guards and self-archiving. A hash-bound copy of the previously reviewed
Go driver-discovery shim changes only the model worker's PATH after verifying
receipt/wrapper/actual driver bytes.

`verify_normalize_record` is an inert CPU replay: the outer caller must first
verify request/raw/capture artifact hashes and exact source/protocol/model. It
then checks frozen input tokens/budget/options, actual retained output IDs and
decodes, checkpoint/runtime/shard audit identity, and reparses quotes from raw
source. Saved parser objects or canonical exports alone are not admissible
provenance. This finite handler does not authorize locked/fresh sources; broader
transfer and generic-evaluator integration require a separate reviewed freeze.

Before first inference, review clarified the Woman focus epistemically: an untyped baby/person is not established as a woman without explicit wording. It does not assert a negative demographic fact. Inert replay may resolve the executing frozen backend support tree by its identical declared manifest/file hashes, without changing the stored remote protocol. Actual capture still enforces its declared deployment path.

"""CPU contract proofs only; fake generation never establishes evidence sufficiency."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import count_evidence_capture as capture
import count_evidence_recipe as recipe
import count_evidence as parser
from count_evidence_codec import codec
import run_count_evidence

PROVIDER=Path('/tmp/jep-native-general-capture-20261028')


def protocol(model='knowcoder',phase='exposed_six'):
    identity=json.loads((PROVIDER/'support-seal.json').read_bytes())
    cfg={'support_manifest_path':str(PROVIDER/'support-seal.json'),
        'support_manifest_sha256':recipe.digest((PROVIDER/'support-seal.json').read_bytes()),
        'model_id':'golaxy/KnowCoder-7B-IE' if model=='knowcoder' else 'HiTZ/GoLLIE-7B',
        'revision':'90ba076763dfb2e9efefd84a0e599f15ae533597' if model=='knowcoder' else 'd3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9',
        'tokenizer_id':'golaxy/KnowCoder-7B-IE' if model=='knowcoder' else 'HiTZ/GoLLIE-7B',
        'tokenizer_revision':'90ba076763dfb2e9efefd84a0e599f15ae533597' if model=='knowcoder' else 'd3e41fef45f6a7d438c46ba7d9fce5d0d486c7a9',
        'snapshot':'fake','backend':'author_vllm_0.2.2_cu118' if model=='knowcoder' else 'pinned_original_flash_model',
        'dtype':'float16' if model=='knowcoder' else 'bfloat16','runtime_manifest_path':'fake','runtime_manifest_sha256':'0'*64,
        'profile':'quoted_assertions','prompt_profile':recipe.PROFILE,'max_new_tokens':512,'context_limit':2048 if model=='knowcoder' else 16384,
        'generation':{'do_sample':False,'num_beams':1,'num_return_sequences':1,'gpu_memory_utilization':0.6,'max_num_seqs':4},
        'count_evidence_development':capture.authorization(phase)}
    return {'phase':phase,'models':{model:{'handler':{'module':'count_evidence_capture','callable':'capture_one',
        'sha256':recipe.digest(Path(capture.__file__).read_bytes())},'max_model_calls_per_source':1,'native_capture':cfg}}}


class FakeBackend:
    instances=0;payload='results=[]';truncated=False
    def __init__(self,model,cfg):
        type(self).instances+=1;self.calls=0;self.model=model;self.codec=codec(model);self.metadata={'fake_backend':True};self.last_raw=None
    def count_tokens(self,text):return self.codec.count_tokens(text)
    def generate(self,bound):
        self.calls+=1
        inputs=self.codec.encode(bound['prompt']);outputs=self.codec.encode(self.payload)[1:]+[2]
        return {'payload':self.payload,'api_text':self.payload,'truncated':self.truncated,
            'input_token_ids':inputs,'output_token_ids':outputs,'input_tokens':len(inputs),'output_tokens':len(outputs),
            'raw_decoded_generation':self.codec.decode(outputs,skip_special_tokens=True),
            'raw_decode_with_special_tokens':self.codec.decode(outputs),
            'author_projection':capture.backend.know_support.author_projection(self.codec,inputs,outputs),
            'stop_reason':'length' if self.truncated else 'stop',
            'generation_options':{'n':1,'best_of':1,'temperature':0.0,'stop':'"""','max_tokens':512}}



class CaptureTests(unittest.TestCase):
    def setUp(self):
        capture._SESSIONS.clear();FakeBackend.instances=0;FakeBackend.payload='results=[]';FakeBackend.truncated=False
        self.source=capture.phase_sources('exposed_six')[0]
    def call(self,source=None,p=None):
        with patch.object(capture,'BACKEND_FACTORY',FakeBackend):
            return capture.capture_one(source or self.source,'knowcoder',p or protocol())
    def test_empty_prediction_is_not_zero_absence_or_not_specified(self):
        record=self.call();self.assertEqual(record['runtime_status'],'ok',record['error'])
        self.assertEqual(record['normalized_evidence']['status'],'no_candidate_assertions')
        self.assertEqual(record['canonical_text'],'');self.assertFalse(record['count_accuracy_evaluated'])
        self.assertEqual(record['scene_count_reasoning'],'deferred_downstream')
    def test_literal_partial_quote_does_not_claim_sufficiency(self):
        FakeBackend.payload='results=[CountEvidence("Three people")]'
        record=self.call();self.assertTrue(record['parse_valid'],record['error'])
        self.assertEqual(record['canonical_text'],'Three people')
        self.assertEqual(record['evidence_sufficiency_status'],'unreviewed')
        self.assertFalse(record['normalized_evidence']['semantic_support_validated'])
        self.assertFalse(record['normalized_evidence']['numeric_count_interpreted'])
        def keys(value):
            if isinstance(value,dict):
                for k,v in value.items():yield k;yield from keys(v)
            elif isinstance(value,list):
                for v in value:yield from keys(v)
        self.assertFalse(set(keys(record['normalized_evidence'])) & {'entities','quantity','relations','identity_links','total'})
    def test_malformed_and_ungrounded_predictions_retain_raw_without_empty_fallback(self):
        for payload in ('results=[Quantity("Three")]',"__import__('os').system('false')",'results=[CountEvidence("missing quote")]'):
            FakeBackend.payload=payload;record=self.call()
            self.assertFalse(record['parse_valid']);self.assertEqual(record['runtime_status'],'error')
            self.assertEqual(record['raw_output'],payload);self.assertIsNone(record['normalized_evidence'])
            self.assertEqual(record['model_calls'],1)
    def test_native_denial_stays_uninterpreted_scoped_source_quote(self):
        source=next(s for s in capture.phase_sources('contrast_controls') if s['control_name']=='non_cardinal_denial')
        FakeBackend.payload='results=[CountEvidence("There are not three dogs in the yard")]'
        record=self.call(source,protocol(phase='contrast_controls'))
        self.assertTrue(record['parse_valid'],record['error'])
        self.assertEqual(record['canonical_text'],'There are not three dogs in the yard')
        self.assertFalse(record['normalized_evidence']['numeric_count_interpreted'])
    def test_controls_never_dispatch_as_automatic_companions(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(capture,'BACKEND_FACTORY',FakeBackend):
            output=Path(directory)/'output';summary=run_count_evidence.run('knowcoder',protocol(),output)
            self.assertEqual(summary['planned_sources'],6);self.assertEqual(summary['model_calls'],6)
            self.assertEqual(FakeBackend.instances,1)
            self.assertEqual(len([p for p in output.iterdir() if p.is_dir()]),6)
    def test_inert_replay_recomputes_literal_assertions_and_rejects_tampering(self):
        FakeBackend.payload='results=[CountEvidence("Three people")]';p=protocol();record=self.call(p=p)
        with patch.object(capture,'_verify_record_metadata'),patch.object(capture,'BACKEND_FACTORY',side_effect=AssertionError('CPU verifier called backend')):
            parsed=capture.verify_normalize_record(self.source,'knowcoder',p,record)
            self.assertEqual(parsed,record['normalized_evidence'])
            bad=deepcopy(record);bad['normalized_evidence']['quotes'][0]['quote']='a man'
            with self.assertRaises(ValueError):capture.verify_normalize_record(self.source,'knowcoder',p,bad)
            bad=deepcopy(record);bad['generation']['output_token_ids'][0]=91
            with self.assertRaises(ValueError):capture.verify_normalize_record(self.source,'knowcoder',p,bad)
    def test_inert_replay_allows_hash_verified_support_relocation_without_protocol_rewrite(self):
        FakeBackend.payload='results=[CountEvidence("Three people")]';p=protocol()
        p['models']['knowcoder']['native_capture']['support_manifest_path']='/original-colab/provider/support-seal.json'
        before=deepcopy(p)
        with patch.object(capture,'_verify_provider'):
            record=self.call(p=p)
        self.assertTrue(record['parse_valid'],record['error'])
        with patch.object(capture,'_verify_record_metadata'):
            self.assertEqual(capture.verify_normalize_record(self.source,'knowcoder',p,record),record['normalized_evidence'])
        self.assertEqual(p,before)
        with self.assertRaises(ValueError):capture.verify_configuration(self.source,'knowcoder',p)
    def test_phase_source_drift_rejected_before_model_load(self):
        changed=dict(self.source,passage=self.source['passage']+' changed')
        record=self.call(changed);self.assertEqual(record['model_calls'],0);self.assertEqual(FakeBackend.instances,0)
    def test_truncated_output_is_failure_not_empty_assertion(self):
        FakeBackend.truncated=True;record=self.call()
        self.assertEqual(record['runtime_status'],'truncated');self.assertFalse(record['parse_valid'])
        self.assertIsNone(record['normalized_evidence'])


class PromptAndControlTests(unittest.TestCase):
    def test_all_twenty_sources_have_frozen_actual_tokenizer_bindings(self):
        for phase in ('exposed_six','contrast_controls'):
            packet=json.loads((recipe.ROOT/(phase+'-requests.json')).read_bytes())
            self.assertEqual(len(packet['items']),6 if phase=='exposed_six' else 14)
            for row in packet['items']:
                for model in ('knowcoder','gollie'):
                    actual=recipe.bind(recipe.plan(row['source']['condition']),model,row['source']['passage'],codec(model).count_tokens)
                    self.assertEqual(actual,row['requests'][model])
                    self.assertLessEqual(actual['input_tokens']+512,actual['context_limit'])
    def test_demo_quotes_are_exact_and_exclude_identifier_background(self):
        for condition in recipe.ONTOLOGIES:
            p=recipe.plan(condition);demo=recipe.demonstration(p)
            for model in ('knowcoder','gollie'):
                result=parser.normalize_count_evidence(recipe.demo_payload(p,model),model,demo['sentence'],condition)
                self.assertEqual(result['status'],'candidate_assertions')
                text=parser.canonical_text(result)
                for excluded in ('27','46','83','92','cart','crate','child','badge','ticket','serial','tag'):
                    self.assertNotIn(excluded,text)
    def test_control_references_are_not_an_input_dependency(self):
        runtime_modules=(recipe.ROOT/'count_evidence_recipe.py').read_text()+(recipe.ROOT/'count_evidence_capture.py').read_text()+(recipe.ROOT/'build_inference_packets.py').read_text()
        self.assertNotIn('control-review-references',runtime_modules)
    def test_symbolic_interpreter_is_not_imported_or_called(self):
        text=(recipe.ROOT/'count_evidence.py').read_text()+(recipe.ROOT/'count_evidence_recipe.py').read_text()+(recipe.ROOT/'count_evidence_capture.py').read_text()
        self.assertNotIn('quantity_from_text',text);self.assertNotIn('native_adapter',text)

if __name__=='__main__':unittest.main()

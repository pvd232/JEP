"""One fixed extractive CountEvidence recipe, without count interpretation.

This is a source-quote preservation task. Count reasoning moves downstream and
is deferred. The constructor is a native string/span transport; its dedicated
canonical semantics is an uninterpreted quoted assertion, never entity presence.
"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
PROFILE='native_extractive_count_evidence_v1'
SYSTEM='You are a highly skilled assistant at digesting and extracting information from textual content. Below is an input containing standard type definitions and textual content. Please complete it with the extracted information in the form of structured code.'
ONTOLOGIES={'number of people':('Person','people, including occupational and age terms'),
 'number of animals':('Animal','animals, including species terms'),
 'number of women':('Woman','explicitly identified women; an untyped baby or other person is not established as a woman without explicit wording'),
 'number of wheels':('Wheel','explicitly mentioned wheels; vehicles do not imply any unmentioned wheels')}
POLICY=('Quote the smallest exact source noun phrase or clause needed as count evidence. '
 'Preserve every relevant cardinal or vague quantity, article, denial, uncertainty, subset, inclusion, distinctness and repeated-reference cue. '
 'Keep a longer clause when needed to preserve attachment, scope or how mentions relate; isolated noun phrases must not lose watching-versus-including meaning. '
 'Exclude irrelevant identifier numbers and background clauses. Do not infer unmentioned parts or people. '
 'Do not return totals, paraphrases, numeric interpretations, identity links or positive-presence facts. '
 'Return [] only when no evidence about the requested target is stated. Never copy the whole caption by default.')


def digest(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def plan(condition):
    text=' '.join(condition.casefold().split())
    if text not in ONTOLOGIES:raise ValueError('No frozen extractive CountEvidence ontology for this condition')
    ontology,focus=ONTOLOGIES[text]
    return {'system':PROFILE,'condition':condition,'ontology':ontology,'focus':focus,
        'task':'exact_source_count_evidence_quotes','count_reasoning':'deferred_downstream',
        'quoted_assertions_not_entity_presence':True,'totals_produced':False,
        'auxiliary_entity_quantities_produced':False}


def schema(p,model):
    description=('An exact quoted source assertion or noun phrase relevant to '+p['condition']+'. '
        'Target: '+p['focus']+'. This object preserves source wording, including denial; it does not assert positive entity presence or a computed count.')
    if model=='knowcoder':return ('class Entity:\n\tdef __init__(self, name: str):\n\t\tself.name = name\n\n'
        'class CountEvidence(Entity):\n\t"""Description: '+description+'"""\n\tpass')
    if model=='gollie':return ('# The following lines describe the task definition\n@dataclass\nclass CountEvidence(Entity):\n    """'+description+'"""\n    span: str')
    raise ValueError('Unknown native model')


def target_prompt(p,model,passage):
    if not isinstance(passage,str) or not passage.strip():raise ValueError('Nonempty source required')
    source=json.dumps(passage,ensure_ascii=False)
    if model=='knowcoder':
        instruction='This is an object-oriented programming task: Some Entity Classes are defined above. Please instantiate all the corresponding Entity Objects in the following sentence.'
        return SYSTEM+'\nInput:\n'+schema(p,model)+'\n\n# '+POLICY+'\n\n"""\n'+instruction+'\n"""\nsentence = '+source+'\nOutput:\n'
    return schema(p,model)+'\n\n# '+POLICY+'\n# This is the text to analyze\ntext = '+source+'\n\n# The annotation instances that take place in the text above are listed here\nresult ='


def demonstration(p):
    return json.loads((ROOT/'demonstrations.json').read_bytes())[p['ontology']]


def demo_payload(p,model):
    quotes=demonstration(p)['evidence_quotes']
    body='['+','.join('CountEvidence('+('span=' if model=='gollie' else '')+json.dumps(q,ensure_ascii=False)+')' for q in quotes)+']'
    return ('results = ' if model=='knowcoder' else '')+body


def prompt(p,model,passage):
    example=demonstration(p)
    demo=target_prompt(p,model,example['sentence'])
    target=target_prompt(p,model,passage)
    if model=='knowcoder':
        prefix=SYSTEM+'\nInput:\n'
        if not target.startswith(prefix):raise ValueError('Canonical Know wrapper changed')
        return demo+demo_payload(p,model)+'\nInput:\n'+target[len(prefix):]
    return demo+' '+demo_payload(p,model)+'\n\n'+target


def identity():
    return {'recipe_sha256':digest(Path(__file__).read_bytes()),'demonstrations_sha256':digest((ROOT/'demonstrations.json').read_bytes())}


def bind(p,model,passage,count_tokens):
    raw=prompt(p,model,passage);tokens=count_tokens(raw);context=2048 if model=='knowcoder' else 16384
    if type(tokens) is not int or tokens<1 or tokens+512>context:
        raise ValueError('Exact input plus512 reserve exceeds native budget; no input truncation')
    return {'prompt':raw,'model':model,'input_tokens':tokens,'max_new_tokens':512,'context_limit':context,
        'profile':'quoted_count_assertions','prompt_profile':PROFILE,'count_stage':None,'task_stage':'count_evidence',
        'plan_sha256':digest(encoded(p)),'prompt_sha256':digest(raw.encode()),'implementation_sha256':identity(),
        'count_reasoning':'deferred_downstream','scene_total_produced':False}


def verify_binding(bound,p,model,passage,count_tokens):
    if bound!=bind(p,model,passage,count_tokens):raise ValueError('CountEvidence recipe/source/tokenizer binding changed')
    return True

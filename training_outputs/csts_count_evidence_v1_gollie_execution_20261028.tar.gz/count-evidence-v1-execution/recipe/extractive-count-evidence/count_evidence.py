"""Parse literal CountEvidence outputs without interpreting their assertions.

This module deliberately has no extractor, model, numeric interpretation, entity
graph, or inference code. Offsets are Python character offsets in the supplied
passage, with an exclusive end. See README.md for the result contract.
"""

from __future__ import annotations

import ast
import hashlib
from pathlib import Path


REPRESENTATION = "uninterpreted_count_relevant_source_assertions"
MAX_PAYLOAD_CHARS = 65536
MAX_AST_NODES = 10000
MAX_AST_DEPTH = 128
SUPPORTED_MODELS = ("knowcoder", "gollie")


class _Rejected(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="surrogatepass")).hexdigest()


def implementation_identity() -> dict:
    """Return the identity of this exact module file, without external imports."""
    path = Path(__file__).resolve()
    return {
        "implementation": "literal_count_evidence_parser_v2",
        "module": "count_evidence",
        "module_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "representation": REPRESENTATION,
        "max_payload_chars": MAX_PAYLOAD_CHARS,
        "max_ast_nodes": MAX_AST_NODES,
        "max_ast_depth": MAX_AST_DEPTH,
    }


def _bounded_tree(tree: ast.AST) -> None:
    stack = [(tree, 0)]
    count = 0
    while stack:
        node, depth = stack.pop()
        count += 1
        if count > MAX_AST_NODES:
            raise _Rejected("ast_node_limit", "AST exceeds the node limit")
        if depth > MAX_AST_DEPTH:
            raise _Rejected("ast_depth_limit", "AST exceeds the depth limit")
        stack.extend((child, depth + 1) for child in ast.iter_child_nodes(node))


def _literal_quotes(payload: str, model: str) -> list[str]:
    if model not in SUPPORTED_MODELS:
        raise _Rejected("unsupported_model", "model must be knowcoder or gollie")
    if len(payload) > MAX_PAYLOAD_CHARS:
        raise _Rejected("payload_size_limit", "payload exceeds the character limit")
    try:
        # Only payload boundary whitespace is removed. No fences, prefixes,
        # comments, constructor text, or string contents are rewritten.
        tree = ast.parse(payload.strip(), mode="exec")
    except (SyntaxError, ValueError, RecursionError, MemoryError) as exc:
        raise _Rejected("invalid_syntax", "payload is not valid bounded Python syntax") from exc
    _bounded_tree(tree)
    if len(tree.body) != 1:
        raise _Rejected("top_level_form", "expected exactly one top-level statement")
    statement = tree.body[0]
    if isinstance(statement, ast.Expr):
        value = statement.value
    elif model == "knowcoder" and isinstance(statement, ast.Assign):
        if (len(statement.targets) != 1
                or not isinstance(statement.targets[0], ast.Name)
                or statement.targets[0].id != "results"):
            raise _Rejected("assignment_target", "only a sole results assignment is allowed")
        value = statement.value
    else:
        raise _Rejected("top_level_form", "expected a literal list or KnowCoder results assignment")
    if not isinstance(value, ast.List):
        raise _Rejected("literal_list_required", "the output must be a literal list")
    expected_keyword = "name" if model == "knowcoder" else "span"
    quotes = []
    for entry in value.elts:
        if (not isinstance(entry, ast.Call)
                or not isinstance(entry.func, ast.Name)
                or entry.func.id != "CountEvidence"):
            raise _Rejected("constructor_required", "every item must call CountEvidence directly")
        if len(entry.args) == 1 and not entry.keywords:
            literal = entry.args[0]
        elif not entry.args and len(entry.keywords) == 1:
            keyword = entry.keywords[0]
            if keyword.arg != expected_keyword:
                raise _Rejected("constructor_keyword", "unexpected CountEvidence keyword")
            literal = keyword.value
        else:
            raise _Rejected("constructor_arity", "CountEvidence requires exactly one string argument")
        if not isinstance(literal, ast.Constant) or type(literal.value) is not str:
            raise _Rejected("literal_string_required", "CountEvidence requires a literal string")
        if not literal.value.strip():
            raise _Rejected("empty_quote", "CountEvidence requires a nonblank string")
        quotes.append(literal.value)
    return quotes


def _all_spans(passage: str, quote: str) -> list[dict]:
    spans = []
    start = passage.find(quote)
    while start != -1:
        spans.append({"start": start, "end": start + len(quote)})
        # Advancing one character retains overlapping occurrences.
        start = passage.find(quote, start + 1)
    return spans


def normalize_count_evidence(payload: str, model: str, passage: str, condition) -> dict:
    """Validate syntax and literal grounding; never interpret the quoted claims.

    Unsupported/rejected output is represented explicitly as invalid, with raw
    payload and hash retained. An accepted empty list is a candidate prediction
    only; it makes no claim about absence of evidence or entities in the source.
    """
    if not isinstance(payload, str) or not isinstance(passage, str):
        raise TypeError("payload and passage must be strings")
    record = {
        "representation": REPRESENTATION,
        "model": model,
        "condition": condition,
        "quotes": [],
        "candidate_grounding_status": "not_evaluated",
        "ambiguity_origins": [],
        "status": "invalid_candidate_assertions",
        "parse_status": "rejected",
        "rejection_reasons": [],
        "semantic_support_validated": False,
        "numeric_count_interpreted": False,
        "raw_payload_sha256": _sha256_text(payload),
        "raw_payload": payload,
    }
    try:
        strings = _literal_quotes(payload, model)
    except _Rejected as exc:
        record["rejection_reasons"] = [{"code": exc.code, "message": str(exc)}]
        return record
    record["parse_status"] = "accepted"
    missing = False
    repeated = False
    for index, quote in enumerate(strings, 1):
        quote_id = f"quote_{index:04d}"
        spans = _all_spans(passage, quote)
        if not spans:
            grounding = "ungrounded"
            origin = "missing_exact_source_substring"
            missing = True
            record["rejection_reasons"].append({
                "code": "ungrounded_quote", "quote_id": quote_id,
                "message": "quote has no exact case-sensitive source occurrence",
            })
        elif len(spans) > 1:
            grounding = "ambiguous"
            origin = "multiple_exact_source_occurrences"
            repeated = True
        else:
            grounding = "unique"
            origin = None
        record["quotes"].append({
            "quote_id": quote_id,
            "quote": quote,
            "span_candidates": spans,
            "grounding_status": grounding,
        })
        if origin is not None:
            record["ambiguity_origins"].append({"quote_id": quote_id, "origin": origin})
    if missing:
        record["status"] = "invalid_candidate_assertions"
        record["candidate_grounding_status"] = "contains_ungrounded_quotes"
    elif repeated:
        record["status"] = "ambiguous_candidate_grounding"
        record["candidate_grounding_status"] = "multiple_exact_occurrences"
    elif strings:
        record["status"] = "candidate_assertions"
        record["candidate_grounding_status"] = "unique_exact_occurrences"
    else:
        record["status"] = "no_candidate_assertions"
        record["candidate_grounding_status"] = "no_candidate_assertions"
    return record


def canonical_text(record: dict) -> str:
    """Join valid literal quote values in order, without adding interpretation.

    A rejected parse or ungrounded quote raises; callers must propagate failure.
    Only a successfully parsed empty list yields an empty string. Multiple exact
    locations are retained as ambiguity in the record, not silently resolved.
    """
    if (record.get("representation") != REPRESENTATION
            or record.get("parse_status") != "accepted"
            or record.get("status") not in {
                "candidate_assertions", "no_candidate_assertions", "ambiguous_candidate_grounding"
            }):
        raise ValueError("cannot canonicalize invalid candidate assertions")
    quotes = record.get("quotes")
    if not isinstance(quotes, list):
        raise ValueError("invalid quote list")
    texts = []
    for entry in quotes:
        if (not isinstance(entry, dict) or type(entry.get("quote")) is not str
                or not entry["quote"].strip() or not entry.get("span_candidates")
                or entry.get("grounding_status") not in {"unique", "ambiguous"}):
            raise ValueError("invalid or ungrounded quote")
        texts.append(entry["quote"])
    if (not texts) != (record["status"] == "no_candidate_assertions"):
        raise ValueError("quote list and status disagree")
    return "\n".join(texts)

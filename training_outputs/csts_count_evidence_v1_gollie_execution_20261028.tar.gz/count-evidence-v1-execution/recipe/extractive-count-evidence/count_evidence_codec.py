"""CPU-only pinned tokenizer accounting; no model or symbolic-count imports."""
from pathlib import Path
from tokenizers import Tokenizer
import native_capture_backends as backend


def codec(model):
    folder=backend.ROOT/('legacy_support/pinned-metadata/ie' if model=='knowcoder' else 'gollie_pinned')
    tokenizer=Tokenizer.from_file(str(folder/'tokenizer.json'))
    class Codec:
        def encode(self,text):
            ids=tokenizer.encode(text,add_special_tokens=True).ids
            if model=='gollie' and ids and ids[-1]==2:ids=ids[:-1]
            return ids
        def count_tokens(self,text):return len(self.encode(text))
        def decode(self,ids,skip_special_tokens=False):return tokenizer.decode(ids,skip_special_tokens=skip_special_tokens)
    return Codec()

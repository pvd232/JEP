"""Finite one-pass extractive CountEvidence capture; count reasoning is deferred."""
from pathlib import Path
import json
import threading
import count_evidence_recipe as recipe
import count_evidence as assertion_parser
import native_capture_backends as backend

ROOT=Path(__file__).resolve().parent
_SESSIONS={}
_LOCK=threading.RLock()
BACKEND_FACTORY=backend.Backend
PHASE_FILES={'exposed_six':'exposed-sources.json','contrast_controls':'control-sources.json'}


def phase_sources(phase):
    if phase not in PHASE_FILES:raise ValueError('Unknown predeclared CountEvidence phase')
    return json.loads((ROOT/PHASE_FILES[phase]).read_bytes())


def implementation_identity():
    return {**recipe.identity(),'parser':assertion_parser.implementation_identity(),
        'handler_sha256':recipe.digest(Path(__file__).read_bytes())}


def authorization(phase):
    return {'purpose':'extractive_count_evidence_not_counting','phase':phase,
        'sources_sha256':recipe.digest((ROOT/PHASE_FILES[phase]).read_bytes()),
        'inference_packet_sha256':recipe.digest((ROOT/(phase+'-requests.json')).read_bytes()),
        'source_ids':[s['id'] for s in phase_sources(phase)],
        'implementation':implementation_identity(),'model_calls_per_source':1,
        'scene_count_reasoning':'deferred_downstream','quality_gate_passed':False,
        'not_a_symbolic_count_repair':True,'automatic_control_companions':False}


def _verify_provider(cfg,allow_verified_relocation=False):
    declared=Path(cfg['support_manifest_path']).resolve()
    path=(backend.ROOT/'support-seal.json').resolve()
    if not allow_verified_relocation and declared!=path:
        raise ValueError('Runtime native provider differs from declared deployment')
    raw=path.read_bytes()
    if recipe.digest(raw)!=cfg['support_manifest_sha256']:raise ValueError('Approved native provider manifest changed')
    manifest=json.loads(raw);root=path.parent.resolve()
    for relative,sha in manifest['files'].items():
        artifact=(root/relative).resolve()
        if not artifact.is_relative_to(root) or recipe.digest(artifact.read_bytes())!=sha:
            raise ValueError('Approved native provider artifact changed: '+relative)
    if Path(backend.__file__).resolve()!=root/'native_capture_backends.py':
        raise ValueError('Loaded native backend has wrong origin')


def verify_configuration(source,model,protocol,allow_verified_relocation=False):
    if model not in {'knowcoder','gollie'}:raise ValueError('Unknown native model')
    phase=protocol['phase'];descriptor=protocol['models'][model];cfg=descriptor['native_capture']
    frozen={s['id']:s for s in phase_sources(phase)}
    if source.get('id') not in frozen or source!=frozen[source['id']]:
        raise ValueError('CountEvidence source is outside the exact frozen phase')
    expected_handler={'module':'count_evidence_capture','callable':'capture_one','sha256':recipe.digest(Path(__file__).read_bytes())}
    if descriptor['handler']!=expected_handler or descriptor['max_model_calls_per_source']!=1 or type(descriptor['max_model_calls_per_source']) is not int:
        raise ValueError('Finite quoted-assertion handler/call cap changed')
    if cfg['count_evidence_development']!=authorization(phase):raise ValueError('Quoted assertion recipe identity changed')
    if cfg['prompt_profile']!=recipe.PROFILE or cfg['profile']!='quoted_assertions' or cfg['max_new_tokens']!=512:
        raise ValueError('CountEvidence profile/output budget changed')
    if cfg['context_limit']!=(2048 if model=='knowcoder' else 16384):raise ValueError('Native context bound changed')
    if cfg['generation'].get('do_sample') is not False or cfg['generation'].get('num_beams')!=1 or cfg['generation'].get('num_return_sequences')!=1:
        raise ValueError('Only one reviewed greedy output is supported')
    if model=='knowcoder' and (cfg['generation'].get('gpu_memory_utilization')!=0.6 or cfg['generation'].get('max_num_seqs')!=4):
        raise ValueError('Reviewed Know resource settings changed')
    _verify_provider(cfg,allow_verified_relocation=allow_verified_relocation)
    return cfg,recipe.plan(source['condition'])


def _session(model,cfg):
    fields=('model_id','revision','tokenizer_id','tokenizer_revision','snapshot','backend','dtype',
        'runtime_manifest_path','runtime_manifest_sha256','support_manifest_sha256')
    key=recipe.digest(recipe.encoded({k:cfg[k] for k in fields}|{'model':model,'runtime_shim':cfg.get('runtime_shim')}))
    if key not in _SESSIONS:_SESSIONS[key]=BACKEND_FACTORY(model,cfg)
    return _SESSIONS[key]


def capture_one(source,model,protocol):
    result={'id':source.get('id'),'source_id':source.get('id'),'model':model,'protocol_canonical_sha256':recipe.digest(recipe.encoded(protocol)),
        'route_supported':False,'coverage_complete':False,'development_authorized':False,'runtime_status':'not_run','parse_valid':False,'truncated':False,
        'raw_output':None,'normalized_evidence':None,'error':'','model_calls':0,'bound_inputs':[],
        'bound_input_verified':False,'generation':None,'scene_count_reasoning':'deferred_downstream',
        'evidence_sufficiency_status':'unreviewed','count_accuracy_evaluated':False,
        'automatic_retries':False,'automatic_control_companions':False}
    session=None;before=0
    try:
        cfg,plan=verify_configuration(source,model,protocol)
        result['development_authorized']=True
        result['route_supported']=True
        with _LOCK:
            session=_session(model,cfg);before=session.calls
            bound=recipe.bind(plan,model,source['passage'],session.count_tokens)
            frozen={row['source']['id']:row for row in json.loads((ROOT/(protocol['phase']+'-requests.json')).read_bytes())['items']}
            if bound!=frozen[source['id']]['requests'][model]:raise ValueError('Frozen exact CountEvidence prompt/tokenizer binding changed')
            bound['assertion_parser_identity']=assertion_parser.implementation_identity()
            # The parser identity is separately bound; recipe verification covers
            # every field it owns without importing symbolic count code.
            recipe.verify_binding({k:v for k,v in bound.items() if k!='assertion_parser_identity'},plan,model,source['passage'],session.count_tokens)
            result['prepared_input']=bound
            calls_before=session.calls
            try:generated=session.generate(bound)
            finally:
                delta=session.calls-calls_before
                if delta not in (0,1):raise ValueError('Undeclared native request count')
                if delta:result['bound_inputs'].append(bound)
            result.update(generation=generated,raw_output=generated['payload'])
            if generated['truncated']:
                result.update(runtime_status='truncated',truncated=True,error='Native output budget exhausted')
            else:
                evidence=assertion_parser.normalize_count_evidence(generated['payload'],model,source['passage'],source['condition'])
                result['parser_record']=evidence
                accepted=(evidence['parse_status']=='accepted' and evidence['status'] in {'candidate_assertions','no_candidate_assertions','ambiguous_candidate_grounding'})
                if accepted:
                    result.update(runtime_status='ok',parse_valid=True,normalized_evidence=evidence,canonical_text=assertion_parser.canonical_text(evidence))
                else:
                    result.update(runtime_status='error',error='Invalid or ungrounded CountEvidence output; raw/parser record retained')
            result['bound_input_verified']=recipe.verify_binding({k:v for k,v in bound.items() if k!='assertion_parser_identity'},plan,model,source['passage'],session.count_tokens)
    except Exception as error:
        result.update(runtime_status='timeout' if isinstance(error,TimeoutError) else 'error',error=type(error).__name__+': '+str(error))
        if session is not None and getattr(session,'last_raw',None) is not None:
            result['raw_backend_error_response']=session.last_raw
    finally:
        if session is not None:
            result['model_calls']=session.calls-before
            if result['model_calls']:result['backend_metadata']=session.metadata
    return result


def _verify_record_metadata(record,model,cfg):
    """Check retained runtime and full actual-byte shard audit identity on CPU."""
    meta=record.get('backend_metadata',{})
    if meta.get('checkpoint')!={'model_id':cfg['model_id'],'revision':cfg['revision']} or meta.get('runtime_manifest_sha256')!=cfg['runtime_manifest_sha256']:
        raise ValueError('Recorded checkpoint/runtime identity differs')
    required={'torch':'2.1.0+cu118','transformers':'4.34.1','tokenizers':'0.14.1','vllm':'0.2.2+cu118'}
    if any(meta.get('versions',{}).get(k)!=v for k,v in required.items()):raise ValueError('Recorded historical runtime versions differ')
    if model=='knowcoder':
        wanted={'max_num_seqs':4,'max_model_len':4096,'max_num_batched_tokens':16384,'dtype':'auto','gpu_memory_utilization':0.6,'tokenizer_mode':'auto','trust_remote_code':True}
        if any(meta.get('engine_kwargs',{}).get(k)!=v for k,v in wanted.items()):raise ValueError('Recorded Know engine options differ')
        pinned=backend.ROOT/'legacy_support/pinned-metadata/ie'
    else:
        if meta.get('original_source_sha256')!=backend.GO_SOURCE_SHA:raise ValueError('Recorded Go model implementation differs')
        pinned=backend.ROOT/'gollie_pinned'
    selected=set(json.loads((pinned/'pytorch_model.bin.index.json').read_bytes())['weight_map'].values())
    info=json.loads((pinned/'model-info.json').read_bytes())
    primary={r['rfilename']:r['lfs'] for r in info['siblings'] if r['rfilename'] in selected}
    checks=meta.get('snapshot_audit',{}).get('shard_file_checks',{})
    if set(checks)!=selected or set(primary)!=selected:raise ValueError('Recorded selected-shard audit is incomplete')
    for name,lfs in primary.items():
        proof=checks[name]
        if proof.get('recomputed_sha256')!=lfs['sha256'] or proof.get('size')!=lfs['size'] or proof.get('full_file_hash_recomputed') is not True:
            raise ValueError('Recorded actual weight bytes differ: '+name)


def verify_normalize_record(source,model,protocol,record):
    """Inert CPU replay after the outer request/raw/artifact hash chain is verified.

    No model session, GPU, symbolic count interpretation or saved parser flag is
    consulted as evidence. Exact token-derived payload is reparsed from source.
    """
    from count_evidence_codec import codec
    cfg,plan=verify_configuration(source,model,protocol,allow_verified_relocation=True)
    if record.get('id')!=source['id'] or record.get('model')!=model or record.get('protocol_canonical_sha256')!=recipe.digest(recipe.encoded(protocol)):
        raise ValueError('Stored CountEvidence source/model/protocol differs')
    if record.get('route_supported') is not True or record.get('coverage_complete') is not False or record.get('automatic_retries') is not False or record.get('automatic_control_companions') is not False:
        raise ValueError('Stored route/completeness/automatic-call claim differs')
    if record.get('scene_count_reasoning')!='deferred_downstream' or record.get('count_accuracy_evaluated') is not False or record.get('evidence_sufficiency_status')!='unreviewed':
        raise ValueError('Stored record claims undeclared interpretation or quality')
    calls=record.get('model_calls');bindings=record.get('bound_inputs')
    if type(calls) is not int or calls not in (0,1) or not isinstance(bindings,list) or len(bindings)!=calls:
        raise ValueError('Stored native request count/bindings differ')
    if calls==0:
        if record.get('generation') is not None or record.get('normalized_evidence') is not None or record.get('parse_valid') is not False or record.get('runtime_status') not in {'error','timeout'}:
            raise ValueError('Zero-call record promoted into model evidence')
        return None
    cpu=codec(model);expected=recipe.bind(plan,model,source['passage'],cpu.count_tokens)
    expected['assertion_parser_identity']=assertion_parser.implementation_identity()
    if bindings!=[expected]:raise ValueError('Stored quoted-assertion input binding differs')
    _verify_record_metadata(record,model,cfg)
    generated=record.get('generation')
    if generated is None:
        if record.get('normalized_evidence') is not None or record.get('parse_valid') is not False or record.get('runtime_status') not in {'error','timeout'}:
            raise ValueError('Failed request promoted into model evidence')
        return None
    inputs=generated.get('input_token_ids');outputs=generated.get('output_token_ids')
    if inputs!=cpu.encode(expected['prompt']) or not isinstance(outputs,list) or not all(type(x) is int and 0<=x<(32000 if model=='knowcoder' else 32016) for x in outputs):
        raise ValueError('Stored token IDs differ from the native invocation')
    raw=cpu.decode(outputs,skip_special_tokens=True)
    if generated.get('raw_decoded_generation')!=raw or generated.get('raw_decode_with_special_tokens')!=cpu.decode(outputs):raise ValueError('Stored raw decode differs from token IDs')
    if generated.get('input_tokens')!=len(inputs) or generated.get('output_tokens')!=len(outputs) or len(outputs)>512:
        raise ValueError('Stored exact token budget differs')
    expected_options=({'n':1,'best_of':1,'temperature':0.0,'stop':'"""','max_tokens':512} if model=='knowcoder' else
        {'method':'manual_greedy_cache','max_new_tokens':512,'do_sample':False,'num_beams':1})
    if generated.get('generation_options')!=expected_options:raise ValueError('Stored actual native decoding options differ')
    if model=='knowcoder':
        payload=generated.get('api_text')
        if not isinstance(payload,str) or payload.strip()!=raw.split('"""',1)[0].strip() or generated.get('payload')!=payload:
            raise ValueError('Stored API payload differs beyond declared stop/whitespace envelope')
        if generated.get('author_projection')!=backend.know_support.author_projection(cpu,inputs,outputs):raise ValueError('Author token projection differs')
        reason=generated.get('stop_reason')
        if reason not in {'stop','length'}:raise ValueError('Unexpected vLLM termination reason')
        truncated=reason=='length'
        if not truncated and (not outputs or (outputs[-1]!=2 and '"""' not in raw)):raise ValueError('Native stop lacks EOS/declared stop marker')
    else:
        payload=raw
        if generated.get('payload')!=payload:raise ValueError('Stored Go payload differs from raw decoding')
        truncated=len(outputs)==512 and (not outputs or outputs[-1]!=2)
        if generated.get('stop_reason')!=('length' if truncated else 'eos') or (not truncated and (not outputs or outputs[-1]!=2)):
            raise ValueError('Stored Go termination differs from token IDs')
    if generated.get('truncated') is not truncated or record.get('truncated') is not truncated or record.get('raw_output')!=payload:
        raise ValueError('Stored output/truncation presentation differs')
    if truncated:
        if record.get('runtime_status')!='truncated' or record.get('parse_valid') is not False or record.get('normalized_evidence') is not None:raise ValueError('Truncation promoted into evidence')
        return None
    parsed=assertion_parser.normalize_count_evidence(payload,model,source['passage'],source['condition'])
    if record.get('parser_record')!=parsed:raise ValueError('Stored parser assertions differ from raw/source replay')
    accepted=parsed['parse_status']=='accepted' and parsed['status'] in {'candidate_assertions','no_candidate_assertions','ambiguous_candidate_grounding'}
    if not accepted:
        if record.get('runtime_status')!='error' or record.get('parse_valid') is not False or record.get('normalized_evidence') is not None:raise ValueError('Rejected quotes promoted into valid evidence')
        return None
    if record.get('runtime_status')!='ok' or record.get('parse_valid') is not True or record.get('normalized_evidence')!=parsed or record.get('canonical_text')!=assertion_parser.canonical_text(parsed):
        raise ValueError('Stored accepted quote representation differs from raw replay')
    return parsed

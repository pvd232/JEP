"""Freeze exact prompts for both predeclared CountEvidence phases; no references read."""
from pathlib import Path
import json
import count_evidence_recipe as recipe
from count_evidence_codec import codec

ROOT=Path(__file__).resolve().parent


def main():
    for phase,name in (('exposed_six','exposed-sources.json'),('contrast_controls','control-sources.json')):
        sources=json.loads((ROOT/name).read_bytes());items=[]
        for source in sources:
            p=recipe.plan(source['condition'])
            bindings={m:recipe.bind(p,m,source['passage'],codec(m).count_tokens) for m in ('knowcoder','gollie')}
            items.append({'source':source,'plan':p,'requests':bindings})
        packet={'phase':phase,'profile':recipe.PROFILE,'source_count':len(items),'items':items,
            'recipe_identity':recipe.identity(),'expected_references_in_model_inputs':False,
            'count_reasoning':'deferred_downstream','quality_gate_passed':False}
        (ROOT/(phase+'-requests.json')).write_text(json.dumps(packet,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
        print(phase,len(items),max(item['requests']['knowcoder']['input_tokens'] for item in items),max(item['requests']['gollie']['input_tokens'] for item in items))

if __name__=='__main__':main()

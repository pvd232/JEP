"""Capture exactly one predeclared CountEvidence phase, with no automatic controls."""
import argparse
import json
import os
from pathlib import Path
import uuid
import count_evidence_capture as capture


def write_once(path,value):
    raw=capture.recipe.encoded(value);temporary=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as out:out.write(raw);out.flush();os.fsync(out.fileno())
        os.link(temporary,path)
    finally:
        if temporary.exists():temporary.unlink()


def run(model,protocol,output):
    phase=protocol['phase'];sources=capture.phase_sources(phase)
    expected=6 if phase=='exposed_six' else 14
    if len(sources)!=expected:raise ValueError('Frozen CountEvidence phase inventory changed')
    for source in sources:capture.verify_configuration(source,model,protocol)
    output=Path(output);output.mkdir(exist_ok=False)
    write_once(output/'protocol.json',protocol);write_once(output/'authorization.json',capture.authorization(phase))
    results=[]
    for index,source in enumerate(sources):
        folder=output/('%02d-'%index+source['id']);folder.mkdir()
        write_once(folder/'attempt.json',{'source':source,'protocol_sha256':capture.recipe.digest(capture.recipe.encoded(protocol)),
            'source_claimed_once':True,'single_attempt':True})
        record=capture.capture_one(source,model,protocol)
        write_once(folder/'result.json',record);results.append(record)
    summary={'phase':phase,'planned_sources':expected,'model_calls':sum(r['model_calls'] for r in results),
        'parsed_sources':sum(r['runtime_status']=='ok' and r['parse_valid'] for r in results),
        'failed_sources':sum(not(r['runtime_status']=='ok' and r['parse_valid']) for r in results),
        'evidence_sufficiency':'unreviewed','scene_count_reasoning':'deferred_downstream',
        'count_accuracy_evaluated':False,'count_repair_claimed':False,'cost_gain_claimed':False}
    write_once(output/'summary.json',summary);return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=('knowcoder','gollie'),required=True)
    parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();print(json.dumps(run(args.model,json.loads(args.protocol.read_bytes()),args.output),sort_keys=True))

if __name__=='__main__':main()

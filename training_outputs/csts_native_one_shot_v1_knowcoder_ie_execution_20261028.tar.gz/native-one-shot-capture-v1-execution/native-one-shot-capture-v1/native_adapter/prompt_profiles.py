"""Frozen source-independent prompt profiles, separate from schema capabilities."""
from pathlib import Path
import hashlib
import json

ZERO_SHOT='native_zero_shot_v1'
ONE_SHOT='native_fixed_family_one_shot_v1'
DEMONSTRATIONS_SHA256='23a4c1091997f9953990757561494966b8883fc2aa6ec263c0ca678de0ce9a84'
SYSTEM='You are a highly skilled assistant at digesting and extracting information from textual content. Below is an input containing standard type definitions and textual content. Please complete it with the extracted information in the form of structured code.'


def identity(prompt_profile,native_task,schema_profile,count_stage=None,task_stage=None):
    if prompt_profile==ZERO_SHOT:
        return {'prompt_profile':ZERO_SHOT,'demonstrations_sha256':None,'family':None,'demonstrations':0}
    if prompt_profile!=ONE_SHOT:raise ValueError('Unknown frozen native prompt profile')
    if native_task not in {'NER','RE','EE'} or schema_profile!='positive_anchor' or count_stage is not None or task_stage is not None:
        raise ValueError('One-shot profile is qualified only for ordinary positive NER/RE/EE schemas')
    raw=(Path(__file__).parent/'demonstrations.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=DEMONSTRATIONS_SHA256:
        raise ValueError('Frozen one-shot demonstration bytes changed')
    return {'prompt_profile':ONE_SHOT,'demonstrations_sha256':DEMONSTRATIONS_SHA256,'family':native_task,'demonstrations':1}


def render(target_prompt,model,native_task,prompt_profile,schema_profile,count_stage=None,task_stage=None):
    """Retain the complete target query; add one fixed completed family example."""
    receipt=identity(prompt_profile,native_task,schema_profile,count_stage,task_stage)
    if receipt['demonstrations']==0:return target_prompt
    raw=(Path(__file__).parent/'demonstrations.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=DEMONSTRATIONS_SHA256:
        raise ValueError('Frozen one-shot demonstration bytes changed')
    examples=json.loads(raw)
    example=examples[native_task]
    if model=='knowcoder':
        prefix=SYSTEM+'\nInput:\n'
        if not target_prompt.startswith(prefix) or not target_prompt.endswith('\nOutput:\n'):
            raise ValueError('Target must retain the canonical KnowCoder wrapper')
        query=target_prompt[len(prefix):]
        return prefix+example['know_query']+'\nOutput:\n'+example['know_output']+'\nInput:\n'+query
    if model=='gollie':
        if not target_prompt.endswith('result ='):
            raise ValueError('Target must retain the canonical GoLLIE completion marker')
        return example['go_query']+' '+example['go_output']+'\n\n'+target_prompt
    raise ValueError('Unknown native model')

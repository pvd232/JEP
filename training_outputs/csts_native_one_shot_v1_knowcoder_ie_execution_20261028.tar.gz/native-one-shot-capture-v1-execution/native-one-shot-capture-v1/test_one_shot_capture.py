"""CPU-only capture integration proof; no model calls."""
import json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,'/tmp/jep-native-tokenizer-20261028')
from tokenizers import Tokenizer
import run_capture as capture
class KnowTokenizer:
    def __init__(self):self.tokenizer=Tokenizer.from_file(str(ROOT/'legacy_support/pinned-metadata/ie/tokenizer.json'))
    def encode(self,text,add_special_tokens=True):return self.tokenizer.encode(text,add_special_tokens=add_special_tokens).ids
class GoTokenizer:
    eos_token_id=2
    def encode(self,text,add_special_tokens=True):return [1]+[3]*max(1,len(text)//100)+[2]
class Integration(unittest.TestCase):
    def test_exact_nine_no_companions_and_all_targets_unchanged(self):
        original={x['case_id']:x for x in json.loads((ROOT/'ordinary-requests.json').read_text())['items']}
        for model,tok in [('knowcoder_ie',KnowTokenizer()),('gollie',GoTokenizer())]:
            cases=capture.build_cases(model,tok);self.assertEqual(len(cases),9)
            for case in cases:
                self.assertEqual(case['kind'],'ordinary')
                bound=case['binding'];native='knowcoder' if model=='knowcoder_ie' else 'gollie'
                self.assertEqual(bound['profile'],'positive_anchor')
                self.assertEqual(bound['prompt_profile'],'native_fixed_family_one_shot_v1')
                self.assertEqual(bound['prompt_profile_identity']['demonstrations'],1)
                self.assertEqual(bound['target_prompt_sha256'],original[case['case_id']]['requests'][native]['prompt_sha256'])
    def test_actual_leading_space_payload_is_only_parser_envelope(self):
        case=next(x for x in capture.build_cases('knowcoder_ie',KnowTokenizer()) if x['case_id']=='animal')
        raw=' results = [Animal("elephant")]'
        result=capture.classify({'api_text':raw,'truncated':False},case,'knowcoder_ie')
        self.assertEqual(result['native_status'],'parsed_and_grounded')
        self.assertEqual(raw,' results = [Animal("elephant")]')
    def test_truncation_and_malicious_output_keep_failure(self):
        case=capture.build_cases('knowcoder_ie',KnowTokenizer())[0]
        result=capture.classify({'api_text':'results = [','truncated':True},case,'knowcoder_ie')
        self.assertTrue(result['truncated'])
        result=capture.classify({'api_text':"__import__('os').system('false')",'truncated':False},case,'knowcoder_ie')
        self.assertEqual(result['native_status'],'schema_or_grounding_failed')
if __name__=='__main__':unittest.main()

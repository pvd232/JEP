"""Capture one frozen ordinary native adapter candidate, with exposed reference controls."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tarfile
import time
import traceback

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "legacy_support"))
import run_legacy as know_backend
from modern_parser_support import sha, write
from native_adapter.schema import bounded_input, native_prompt, verify_bound_input
from native_adapter.prompt_profiles import ONE_SHOT, ZERO_SHOT
from native_adapter.normalize import normalize_native
import gollie_backend_support


def build_cases(model, tokenizer):
    """Bind exactly the same nine targets to one frozen family demonstration."""
    document=json.loads((ROOT/"one-shot-requests.json").read_text())
    original={x["case_id"]:x for x in json.loads((ROOT/"ordinary-requests.json").read_text())["items"]}
    cases=[]
    def count(prompt):
        ids=tokenizer.encode(prompt,add_special_tokens=True)
        if model=="gollie":
            if not ids or ids[-1]!=tokenizer.eos_token_id:
                raise ValueError("Expected author Go final EOS")
            ids=ids[:-1]
        return len(ids)
    for item in document["items"]:
        native="knowcoder" if model=="knowcoder_ie" else "gollie"
        candidate=item["requests"][native]
        frozen=original[item["case_id"]]["requests"][native]
        target=native_prompt(item["plan"],native,item["passage"],profile="positive_anchor",prompt_profile=ZERO_SHOT)
        if target!=frozen["prompt"] or sha(target.encode())!=frozen["prompt_sha256"]:
            raise ValueError("Original zero-shot target query changed")
        bound=bounded_input(item["plan"],native,item["passage"],count,max_new_tokens=512,
                            profile="positive_anchor",prompt_profile=ONE_SHOT)
        verify_bound_input(bound,item["plan"],item["passage"],count)
        static={key:value for key,value in bound.items() if key!="input_tokens"}
        if static!={key:value for key,value in candidate.items() if key!="input_tokens"}:
            raise ValueError("Frozen one-shot prompt/helper/profile binding differs")
        if native=="knowcoder" and bound["input_tokens"]!=candidate["input_tokens"]:
            raise ValueError("Know actual tokenizer count changed")
        if bound["target_prompt_sha256"]!=frozen["prompt_sha256"]:
            raise ValueError("One-shot changed the original target schema or sentence")
        cases.append({"case_id":item["case_id"],"kind":"ordinary","prompt":bound["prompt"],
            "source_id":item["source_id"],"passage":item["passage"],"condition":item["condition"],
            "plan":item["plan"],"binding":bound})
    if len(cases)!=9:raise ValueError("Exactly nine predeclared development cases required")
    return cases


def classify(generation, case, model):
    """Separate literal emptiness, schema/grounding errors and unreviewed semantics."""
    payload = generation["api_text"] if model == "knowcoder_ie" else generation["raw_decoded_generation"]
    record = {"case_id": case["case_id"], "kind": case["kind"],
        "semantic_status": "unreviewed", "empty_list_emitted": None,
        "truncated": generation["truncated"], "native_status": "schema_or_grounding_failed"}
    try:
        record["empty_list_emitted"] = not know_backend.list_node(payload).elts
    except (ValueError, SyntaxError, RecursionError):
        pass
    if generation["truncated"]:
        record["error"] = "Output budget exhausted"
        return record
    try:
        if case["kind"] == "ordinary":
            native = "knowcoder" if model == "knowcoder_ie" else "gollie"
            evidence = normalize_native(payload, case["plan"], native, case["passage"],
                coverage_complete=False, profile="positive_anchor")
            record.update(native_status="parsed_and_grounded", evidence=evidence)
        else:
            reference = case["reference"]
            parsed = know_backend.parse_record(payload, reference["fixture"], reference["variant"])
            record.update(native_status=parsed["parse_status"], companion_result=parsed)
    except (ValueError, SyntaxError, RecursionError) as error:
        record["error"] = str(error)
    return record


def capture_know(args, protocol):
    """Use the previously reviewed historical author vLLM API and pinned IE snapshot."""
    versions = know_backend.versions()
    identity = protocol["models"]["knowcoder_ie"]
    declared = {"model_id": identity["model_id"], "revision": identity["revision"]}
    snapshot = args.snapshot.resolve()
    audit = know_backend.snapshot_metadata(snapshot, declared,
        ROOT / "legacy_support/pinned-metadata/ie")
    audit["shards"] = know_backend.verify_weight_files(snapshot, audit)
    import torch
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot), use_fast=True, legacy=False,
        padding_side="left", trust_remote_code=True, local_files_only=True)
    cases = build_cases("knowcoder_ie", tokenizer)
    ids = [tokenizer.encode(case["prompt"]) for case in cases]
    for sequence in ids:
        if sequence.count(1) != 1 or sequence[0] != 1 or 2 in sequence:
            raise ValueError("Know input BOS/EOS serialization differs")
    write(args.output / "inputs.json", [{"case_id": c["case_id"], "kind": c["kind"],
        "prompt": c["prompt"], "input_token_ids": tokens,
        "binding": c.get("binding")} for c, tokens in zip(cases, ids)])
    kwargs = {"model": str(snapshot), "tokenizer_mode": "auto", "trust_remote_code": True,
        "max_num_seqs": 4, "max_model_len": 4096, "max_num_batched_tokens": 16384, "dtype": "auto",
        "gpu_memory_utilization": 0.6}
    options = {"n": 1, "best_of": 1, "temperature": 0.0, "stop": '"""', "max_tokens": 512}
    engine = LLM(**kwargs)
    if str(engine.llm_engine.model_config.dtype) != "torch.float16":
        raise ValueError("Pinned Know IE did not resolve to FP16")
    for case, tokens in zip(cases, ids):
        if engine.get_tokenizer().encode(case["prompt"]) != tokens:
            raise ValueError("Know engine tokenizer differs from supplied author IDs")
    write(args.output / "runtime.json", {"versions": versions, "snapshot_audit": audit,
        "actual_dtype": str(engine.llm_engine.model_config.dtype), "llm_kwargs": kwargs,
        "sampling_kwargs": options, "torch": torch.__version__, "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0), "system_checkpoint": declared})
    responses = engine.generate(prompt_token_ids=ids, sampling_params=SamplingParams(**options))
    write(args.output / "raw-batch.json", [{"request_id": r.request_id,
        "prompt": r.prompt, "prompt_token_ids": list(r.prompt_token_ids), "finished": r.finished,
        "outputs": [{"index": o.index, "text": o.text, "token_ids": list(o.token_ids),
            "finish_reason": o.finish_reason,
            "cumulative_logprob": know_backend.diagnostic_number(o.cumulative_logprob)}
            for o in r.outputs]} for r in responses])
    if len(responses) != len(cases):
        raise ValueError("Incomplete native request count")
    for case, supplied, response in zip(cases, ids, responses):
        if list(response.prompt_token_ids) != supplied or len(response.outputs) != 1 or not response.finished:
            raise ValueError("Know response identity or completion differs")
        out = response.outputs[0]
        tokens = list(out.token_ids)
        generated = {"case_id": case["case_id"], "kind": case["kind"], "prompt": case["prompt"],
            "input_token_ids": supplied, "output_token_ids": tokens,
            "input_tokens": len(supplied), "output_tokens": len(tokens),
            "api_text": out.text, "raw_decoded_generation": tokenizer.decode(tokens, skip_special_tokens=True),
            "raw_decode_with_special_tokens": tokenizer.decode(tokens, skip_special_tokens=False),
            "author_projection": know_backend.author_projection(tokenizer, supplied, tokens),
            "stop_reason": out.finish_reason, "truncated": out.finish_reason == "length"}
        write(args.output / (case["case_id"] + "-generation.json"), generated)
        write(args.output / (case["case_id"] + "-result.json"), classify(generated, case, "knowcoder_ie"))
        print(json.dumps({"case_id": case["case_id"], "raw": out.text}), flush=True)
    return {"ordinary_cells": 9, "reference_companion_cells": 0, "model_generations": len(cases)}


def capture_go(args, protocol):
    """Use the exact pinned original custom model and verified historical Flash API."""
    from importlib import metadata
    versions = know_backend.versions()
    if metadata.version("flash-attn") != "2.3.4":
        raise ValueError("Unexpected official FlashAttention wheel identity")
    identity = protocol["models"]["gollie"]
    snapshot = args.snapshot.resolve()
    if snapshot.name != identity["revision"]:
        raise ValueError("Go snapshot revision differs")
    source = snapshot / "modeling_flash_llama.py"
    if sha(source.read_bytes()) != identity["source_sha256"]:
        raise ValueError("Original pinned Go code changed")
    import torch
    import flash_attn
    from transformers import AutoTokenizer, LlamaConfig
    if not torch.cuda.is_available():
        raise ValueError("Original Go Flash backend requires CUDA")
    tokenizer = AutoTokenizer.from_pretrained(snapshot, add_eos_token=True, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.unk_token_id if tokenizer.unk_token_id is not None else tokenizer.eos_token_id
    cases = build_cases("gollie", tokenizer)
    tensors = []
    for case in cases:
        encoded = tokenizer(case["prompt"], add_special_tokens=True, return_tensors="pt")["input_ids"]
        if int(encoded[0, -1]) != tokenizer.eos_token_id:
            raise ValueError("Expected author tokenizer-added final EOS")
        tensors.append(encoded[:, :-1])
    write(args.output / "inputs.json", [{"case_id": c["case_id"], "prompt": c["prompt"],
        "input_token_ids": t[0].tolist(), "binding": c["binding"]}
        for c, t in zip(cases, tensors)])
    spec = importlib.util.spec_from_file_location("pinned_gollie_ordinary_model", source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    config = LlamaConfig.from_pretrained(snapshot, local_files_only=True)
    model, report = module.LlamaForCausalLM.from_pretrained(snapshot, config=config,
        torch_dtype=torch.bfloat16, device_map={"": 0}, output_loading_info=True,
        local_files_only=True)
    gollie_backend_support.strict_load_info(report)
    parameters = dict(model.named_parameters())
    indexed = json.loads((snapshot / "pytorch_model.bin.index.json").read_text())["weight_map"]
    if len(parameters) != 291 or set(parameters) != set(indexed):
        raise ValueError("Go learned tensor identity differs")
    for name, parameter in parameters.items():
        if parameter.dtype != torch.bfloat16 or not torch.isfinite(parameter).all().item():
            raise ValueError("Invalid Go learned tensor: " + name)
    model.eval()
    if model.model.layers[0].self_attn.rotary_emb.base != 10000:
        raise ValueError("Original Go rotary base differs")
    write(args.output / "runtime.json", {"versions": versions, "flash_metadata": metadata.version("flash-attn"),
        "flash_module_version": flash_attn.__version__, "model_identity": identity,
        "source_sha256": sha(source.read_bytes()), "loading_info": report,
        "verified_finite_parameter_tensors": 291, "actual_dtype": str(model.dtype),
        "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(0),
        "generation": "Reviewed manual greedy original-model forward/cache loop", "max_new_tokens": 512})
    for case, tensor in zip(cases, tensors):
        started = time.monotonic()
        result = gollie_backend_support.greedy(model, tensor.to("cuda"), 512, tokenizer.eos_token_id, torch)
        tokens = result["token_ids"]
        generated = {"case_id": case["case_id"], "kind": "ordinary", "prompt": case["prompt"],
            "input_token_ids": tensor[0].tolist(), "output_token_ids": tokens,
            "input_tokens": tensor.shape[1], "output_tokens": len(tokens),
            "raw_decoded_generation": tokenizer.decode(tokens, skip_special_tokens=True),
            "raw_decode_with_special_tokens": tokenizer.decode(tokens, skip_special_tokens=False),
            "stop_reason": "eos" if result["ended_on_eos"] else "length",
            "truncated": result["length_truncated"], "cache_checks": result["cache_vs_full_prefix"],
            "elapsed_seconds": time.monotonic() - started}
        write(args.output / (case["case_id"] + "-generation.json"), generated)
        write(args.output / (case["case_id"] + "-result.json"), classify(generated, case, "gollie"))
        print(json.dumps({"case_id": case["case_id"], "raw": generated["raw_decoded_generation"]}), flush=True)
    return {"ordinary_cells": 9, "reference_companion_cells": 0, "model_generations": len(cases)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=("knowcoder_ie", "gollie"), required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    seal = json.loads((ROOT / "seal.json").read_text())
    for name, digest in seal["files"].items():
        if sha((ROOT / name).read_bytes()) != digest:
            raise ValueError("Frozen ordinary capture file changed: " + name)
    archive_path = args.output.parent / (args.output.name + ".tar.gz")
    if archive_path.exists():
        raise ValueError("Archive already exists; refusing to repeat")
    args.output.mkdir(parents=True, exist_ok=False)
    protocol = json.loads((ROOT / "protocol.json").read_text())
    write(args.output / "start.json", {"started_at": datetime.now(timezone.utc).isoformat(),
        "seal_sha256": sha((ROOT / "seal.json").read_bytes()), "protocol": protocol,
        "model": args.model, "expected_answers_in_model_inputs": False,
        "counts_negatives_fresh_not_dispatched": True})
    summary = {"status": "failed", "representative_quality_score": False}
    try:
        counts = capture_know(args, protocol) if args.model == "knowcoder_ie" else capture_go(args, protocol)
        summary.update(status="completed", **counts)
    except Exception as error:
        summary.update(error=str(error), traceback=traceback.format_exc())
    finally:
        write(args.output / "complete.json", summary)
        files = {str(p.relative_to(args.output)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
                 for p in sorted(args.output.rglob("*")) if p.is_file()}
        write(args.output / "capture-index.json", files)
        with tarfile.open(archive_path, "w:gz") as archive:
            archive.add(args.output, arcname=args.output.name)
            archive.add(ROOT / "seal.json", arcname="source-seal.json")
        print(json.dumps({"archive": str(archive_path), "sha256": sha(archive_path.read_bytes()),
            "status": summary["status"]}), flush=True)
    raise SystemExit(0 if summary["status"] == "completed" else 1)


if __name__ == "__main__":
    main()

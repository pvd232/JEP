__import__('os').mkdir('/content/jep-native-author-calibration-20261028/final-native-48-bridge-v1-launch.claim')
if not __debug__:raise RuntimeError("Optimized Python is forbidden: reviewed authorization assertions must execute")
def _jep_final_native48_single_dispatch_20261028():
    from pathlib import Path
    import hashlib,json,os,subprocess,sys,tarfile,time,traceback
    task=Path('/content/jep-native-author-calibration-20261028');claim=task/'final-native-48-bridge-v1-launch.claim';receipt=claim/'deployment.json'
    record={'status':'preparing','started_at':time.time(),'models':{},'phase':'locked-canaries','sources_per_model':48,'automatic_retries':False,'exclusive_top_level_claim_acquired':True}
    with receipt.open('x') as out:json.dump(record,out)
    try:
        metadata_path=task/'final-native-48-dispatch-inputs.json';metadata=json.loads(metadata_path.read_text());record['dispatch_inputs_sha256']=hashlib.sha256(metadata_path.read_bytes()).hexdigest()
        assert metadata['worker_sha256']=='b488a3512bbf0c340eafc1bd9b69e38b7bcb2190715f6058b8b3279c2ad3ed5a','Reviewed outer worker differs'
        assert metadata['protocol_sha256']=='235a817398017a780cc354694dd9c48337200818983a1f52d0a33b00629b6946','Final reviewed protocol differs'
        assert metadata['driver_sha256']=='3f1d1e2e898f426bf4019ea2e476dd0315b3751bf1129380aba767297e25dd89','Final reviewed capture driver differs'
        expected_roots=['/tmp/jep-native-positive-diagnostic-capture-20261028','/tmp/jep-native-positive-diagnostic-protocol-v3-20261028','/tmp/jep-native-positive-diagnostic-job-v1-20261028']
        assert [row['expected_root'] for row in metadata['bundles']]==expected_roots,'Final48 source/protocol/job deployment roots differ'
        for row in metadata['bundles']:
            bundle=Path(row['remote']);assert bundle.parent==Path('/content'),'Unexpected uploaded-bundle path'
            assert hashlib.sha256(bundle.read_bytes()).hexdigest()==row['sha256'],'Reviewed source bundle differs'
            assert not Path(row['expected_root']).exists(),'Fresh fixed48 deployment root required; preserve existing paths'
        previous=task/'results/know-refinement-v1-knowcoder_ie-worker.json';assert json.loads(previous.read_text())['status']=='complete','Prior own Know worker not complete'
        for row in metadata['bundles']:
            with tarfile.open(row['remote']) as archive:archive.extractall('/tmp',filter='data')
            assert Path(row['expected_root']).is_dir(),'Bundle did not create its exact approved root'
        job=Path(expected_roots[2]);assert hashlib.sha256((job/'job-seal.json').read_bytes()).hexdigest()==metadata['job_seal_sha256'],'Final48 job seal differs'
        assert hashlib.sha256((job/'protocol.json').read_bytes()).hexdigest()==metadata['protocol_sha256'],'Final48 job protocol differs'
        assert hashlib.sha256((Path(expected_roots[0])/'evaluate_native.py').read_bytes()).hexdigest()==metadata['driver_sha256'],'Final48 driver differs'
        job_seal=json.loads((job/'job-seal.json').read_text());assert job_seal['phase']=='locked-canaries' and job_seal['sources']==48 and job_seal['gold_or_ratings_in_inference_job'] is False,'Only approved fixed48 gold-free projection authorized'
        root=task/'final-native-48-bridge-v1-execution';root.mkdir()
        worker=task/'final-native-48-per-model-worker.py';assert hashlib.sha256(worker.read_bytes()).hexdigest()==metadata['worker_sha256'],'Uploaded outer worker differs'
        for model in ['knowcoder','gollie']:
            dispatch=task/('final-native-48-v1-'+model+'-dispatch.json');assert not dispatch.exists() and not(task/('results/final-native-48-v1-'+model+'-worker.json')).exists(),'Per-model final48 attempt exists'
            row={'status':'prepared','model':model,'worker_sha256':metadata['worker_sha256'],'job_seal_sha256':metadata['job_seal_sha256'],'protocol_sha256':metadata['protocol_sha256'],'driver_sha256':metadata['driver_sha256'],'sources':48,'automatic_retries':False}
            with dispatch.open('x') as out:json.dump(row,out)
            log=task/('logs/final-native-48-v1-'+model+'-controller.log')
            command=[sys.executable,str(worker),'--model',model,'--job-seal-sha256',metadata['job_seal_sha256'],'--protocol-sha256',metadata['protocol_sha256'],'--driver-sha256',metadata['driver_sha256']]
            with log.open('x') as out:process=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,cwd=task,start_new_session=True,env=dict(os.environ))
            row.update(status='dispatched',pid=process.pid,log=str(log),model_worker_started=True);dispatch.write_text(json.dumps(row,indent=2)+'\n');record['models'][model]=row;receipt.write_text(json.dumps(record,indent=2)+'\n')
        record.update(status='dispatched',models_sequential=True)
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({key:value for key,value in record.items() if key!='traceback'}),flush=True)
_jep_final_native48_single_dispatch_20261028()
del _jep_final_native48_single_dispatch_20261028

"""One serialized final fixed48 native integration attempt; failures remain evidence and are never retried."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,tarfile,traceback
TASK=Path('/content/jep-native-author-calibration-20261028')
EXECROOT=TASK/'final-native-48-bridge-v1-execution'
BRIDGE=Path('/tmp/jep-native-positive-diagnostic-capture-20261028')
PROTOCOL=Path('/tmp/jep-native-positive-diagnostic-protocol-v3-20261028')
JOB=Path('/tmp/jep-native-positive-diagnostic-job-v1-20261028')
ENV=TASK/'environments/knowcoder-author-py310'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['knowcoder','gollie'],required=True);parser.add_argument('--job-seal-sha256',required=True);parser.add_argument('--protocol-sha256',required=True);parser.add_argument('--driver-sha256',required=True);args=parser.parse_args();model=args.model
    output=EXECROOT/model;receipt=TASK/('results/final-native-48-v1-'+model+'-worker.json');log=TASK/('logs/final-native-48-v1-'+model+'.log');archive=TASK/('results/final-native-48-v1-'+model+'-execution.tar.gz')
    if any(path.exists() for path in [output,receipt,log,archive]):raise ValueError('Final48 native attempt exists; inspect, do not repeat')
    record={'status':'started','phase':'preflight','model':model,'started_at':time.time(),'planned_sources':48,'automatic_retries':False,'representative_general_quality_claimed':False,'phase_kind':'locked-canaries','claims_in_job_and_operator':True,'original_captures_unchanged':True}
    with receipt.open('x') as handle:json.dump(record,handle,indent=2)
    try:
        previous=TASK/'results/know-refinement-v1-knowcoder_ie-worker.json'
        if json.loads(previous.read_text()).get('status')!='complete':raise RuntimeError('Prior own Know refinement worker not complete')
        if model=='gollie':
            prior=TASK/'results/final-native-48-v1-knowcoder-worker.json';deadline=time.monotonic()+1800
            record['phase']='waiting_for_final48_know_exit';write(receipt,record)
            while not prior.exists() or json.loads(prior.read_text()).get('status') not in ('complete','failed'):
                if time.monotonic()>deadline:raise RuntimeError('Prior own Know final48 worker did not finish')
                time.sleep(2)
        if digest(JOB/'job-seal.json')!=args.job_seal_sha256 or digest(JOB/'protocol.json')!=args.protocol_sha256:raise ValueError('Frozen final48 job/protocol differs')
        driver=BRIDGE/'evaluate_native.py'
        if digest(driver)!=args.driver_sha256:raise ValueError('Reviewed fixed48 capture driver differs')
        job=json.loads((JOB/'job-seal.json').read_text());sources=json.loads((JOB/'sources.json').read_text())
        if job.get('phase')!='locked-canaries' or len(sources)!=48:raise ValueError('Only fixed48 integration phase authorized')
        setup=TASK/'environments/knowcoder-author-setup-amendment02.json'
        if digest(setup)!='3ac4252a8f81be39bd713d70006fa13cd2dbf63f5876296ff1955f0728f25a94' or json.loads(setup.read_text()).get('status')!='ready_import_verified':raise ValueError('Historical runtime receipt differs')
        processes=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=20)
        memory=subprocess.run(['nvidia-smi','--query-gpu=memory.total,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20)
        total,free,utilization=[int(v.strip()) for v in memory.stdout.splitlines()[0].split(',')];required=int(total*0.6)+8*1024 if model=='knowcoder' else 45*1024
        record['gpu_scheduling']={'foreign_compute_processes_before_launch':processes.stdout,'total_mib':total,'free_mib_before_launch':free,'required_free_mib':required,'utilization_percent_before_launch':utilization,'shared_gpu':bool(processes.stdout.strip()),'timing_isolated':False,'foreign_processes_untouched':True};write(receipt,record)
        if free<required:raise RuntimeError('Preserve other work: actual free memory below reviewed budget')
        runtime=dict(os.environ,PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONPATH=str(BRIDGE),XDG_CACHE_HOME=str(TASK/'cache/legacy-runtime'),RAY_TMPDIR=str(TASK/'cache/ray-final-native-48'))
        if model=='gollie':
            driver_root=TASK/'environments/triton-driver-discovery-v2';driver_receipt=driver_root/'receipt.json';driver_record=json.loads(driver_receipt.read_text())
            if digest(driver_receipt)!='4e67a2813087b42714d618ad55f733645489450096c7af3a58f16cdd544dbbd7' or digest(driver_root/'bin/ldconfig')!=driver_record['wrapper_sha256'] or driver_record['status']!='ready_cpu_discovery_verified':raise ValueError('Reviewed Go driver-discovery receipt differs')
            runtime['PATH']=str(driver_root/'bin')+os.pathsep+runtime.get('PATH','')
            audit=TASK/'results/gollie-pinned-artifact-audit-20261028.json'
            if digest(audit)!='8caeb672bc09a34767369c27a10eb6127791062f037f53cd2827a9f1b6095418' or json.loads(audit.read_text()).get('status')!='verified':raise ValueError('Verified Go primary-byte audit differs')
            record.update(driver_receipt_sha256=digest(driver_receipt),primary_artifact_audit_sha256=digest(audit))
        command=[str(ENV/'bin/python'),str(driver),'run-capture','--job',str(JOB),'--model',model,'--output',str(output)]
        record.update(phase='model_capture',command=command,job_seal_sha256=args.job_seal_sha256,protocol_sha256=args.protocol_sha256,driver_sha256=args.driver_sha256);write(receipt,record)
        with log.open('x') as handle:result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT,cwd=BRIDGE,env=runtime,timeout=1800,check=False)
        record['returncode']=result.returncode
        manifest=json.loads((output/'manifest.json').read_text()) if (output/'manifest.json').exists() else None;record['manifest']=manifest
        if result.returncode or not manifest or manifest.get('status')!='completed_capture_attempts' or manifest.get('completed_records')!=48:raise RuntimeError('Final48 capture incomplete; all raw failures/unrun records retained')
        record.update(status='complete',phase='finished')
    except Exception as error:record.update(status='failed',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        record.update(finished_at=time.time(),log_sha256=digest(log) if log.exists() else None);write(receipt,record)
        index={str(path.relative_to(TASK)):digest(path) for path in sorted(output.rglob('*')) if path.is_file()} if output.exists() else {}
        index_path=TASK/('results/final-native-48-v1-'+model+'-execution-index.json');write(index_path,index)
        with tarfile.open(archive,'w:gz') as tf:
            for path in [receipt,index_path,log,Path(__file__),TASK/'final-native-48-bridge-v1-launch.claim',TASK/'final-native-48-dispatch-inputs.json',TASK/'final-native-48-stage-dispatch.py',TASK/'environments/knowcoder-author-setup-amendment02.json',TASK/'environments/triton-driver-discovery-v2/receipt.json',TASK/'results/gollie-pinned-artifact-audit-20261028.json']:
                if path.exists():tf.add(path,arcname=str(path.relative_to(TASK)))
            for source in [BRIDGE,PROTOCOL,JOB]:
                if source.exists():tf.add(source,arcname='inputs/'+source.name)
            if output.exists():tf.add(output,arcname=str(output.relative_to(TASK)))
        write(TASK/('results/final-native-48-v1-'+model+'-execution-archive.json'),{'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'status':record['status'],'capture_files':len(index)})
        print(json.dumps({key:value for key,value in record.items() if key not in ['manifest','traceback']}),flush=True)
    if record['status']!='complete':sys.exit(1)
if __name__=='__main__':main()

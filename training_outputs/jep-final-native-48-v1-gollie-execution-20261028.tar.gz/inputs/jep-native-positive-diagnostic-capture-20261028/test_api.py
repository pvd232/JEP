"""CPU-only callback contract tests with fake backends; no models or held-out data."""
from pathlib import Path
import hashlib
import json
import unittest
import tempfile

import native_capture as api
from native_adapter.schema import compile_condition,implementation_identity


class FakeBackend:
    instances=0
    payload='results = [Food("sandwich"), Food("pickle")]'
    truncated=False
    raises=False
    def __init__(self,model,cfg):
        type(self).instances+=1
        self.calls=0
        self.metadata={"fake_backend":True}
        self.last_raw=None
    def count_tokens(self,prompt):
        return 20
    def generate(self,bound):
        self.calls+=1
        if self.raises:
            self.last_raw={"token_ids":[42],"text":"partial"}
            raise RuntimeError("fake API failure")
        return {"payload":self.payload,"truncated":self.truncated,
            "input_token_ids":[1]+[3]*19,"output_token_ids":[42,2]}


def protocol():
    identity=api.support_identity()
    cfg={
        "model_id":"golaxy/KnowCoder-7B-IE","revision":"90ba076763dfb2e9efefd84a0e599f15ae533597",
        "tokenizer_id":"golaxy/KnowCoder-7B-IE","tokenizer_revision":"90ba076763dfb2e9efefd84a0e599f15ae533597",
        "snapshot":"/fake/pinned-snapshot","backend":"author_vllm_0.2.2_cu118","dtype":"float16",
        "runtime_manifest_path":"/fake/receipt.json","runtime_manifest_sha256":"b"*64,
        "support_manifest_sha256":identity["support_manifest_sha256"],
        "compiler_implementation_sha256":identity["compiler_implementation_sha256"],
        "compiler_implementation_files":implementation_identity(),
        "context_limit":4096,"max_new_tokens":512,"profile":"positive_anchor",
        "contract_recipe":"native_spatial_clause_food_recipe_v1",
        "prompt_profile":"native_know_palette_clause_refinement_v1",
        "allowed_profiles":["positive_anchor"],"allow_compiler_stages":True,"stage_overrides":{},
        "allowed_compiler_families":["unary_typed_mentions","binary_properties_locations","actions_events","other"],
        "unsupported_compiler_families":["aggregate_counts_quantities"],
        "allowed_native_tasks":["NER","RE","NER+RE"],"allow_typed_ner":True,"allow_condition_compiled_re":True,
        "diagnostic_authorization":{},"diagnostic_cohort":{"sources":48,"source_sha256":"c"*64,"source_support_seal_sha256":"d"*64},
        "generation":{"do_sample":False,"num_beams":1,"num_return_sequences":1,
                      "gpu_memory_utilization":0.6,"max_num_seqs":4}}
    descriptor={"handler":{"module":"native_capture","callable":"capture_one","verify_callable":"verify_normalize_record",
        "sha256":identity["handler_sha256"]},"max_model_calls_per_source":3,"native_capture":cfg}
    rows=[{"id":name,"condition":"type of food","passage":"A sandwich and a pickle are on the tray."}
        for name in ["synthetic-food","another-source"]]+[{"id":"empty-source","condition":"type of food","passage":""}]+[
        {"id":"unused-"+str(i),"condition":"synthetic condition","passage":"Synthetic source."}for i in range(45)]
    receipt={"status":"AUTHORIZED_LOCKED48_DIAGNOSTIC","phase":"locked-canaries","model":"knowcoder",
        "descriptor_binding_sha256":api.authorization_binding(descriptor),
        "experimental_calls_only":True,"semantic_qualification_passed":False,"fresh_evaluation_authorized":False,
        "cohort":cfg["diagnostic_cohort"],
        "source_ids":[row["id"]for row in rows],
        "source_record_sha256":{row["id"]:api._digest(api._canonical(row))for row in rows}}
    path=Path(tempfile.mkdtemp(prefix="native-fake-diagnostic-"))/"receipt.json"
    path.write_bytes(api._canonical(receipt))
    cfg["diagnostic_authorization"]={"receipt_path":str(path),"receipt_sha256":api._digest(path.read_bytes())}
    return {"capture_scope":"locked48_diagnostic_only","models":{"knowcoder":descriptor}}


class PublicCallbackTests(unittest.TestCase):
    def setUp(self):
        api._SESSIONS.clear()
        api.BACKEND_FACTORY=FakeBackend
        FakeBackend.instances=0
        FakeBackend.payload='results = [Food("sandwich"), Food("pickle")]'
        FakeBackend.truncated=FakeBackend.raises=False
        self.source={"id":"synthetic-food","condition":"type of food","passage":"A sandwich and a pickle are on the tray."}

    def test_ungated_route_has_zero_calls_and_no_fake_empty_output(self):
        p=protocol()
        p["models"]["knowcoder"]["native_capture"]["diagnostic_authorization"]={}
        result=api.capture_one(self.source,"knowcoder",p)
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertIsNone(result["raw_output"])
        self.assertEqual(FakeBackend.instances,0)

    def test_supported_source_has_one_verified_call_without_companions(self):
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"ok")
        self.assertTrue(result["parse_valid"])
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(len(result["bound_inputs"]),1)
        self.assertTrue(result["bound_input_verified"])
        self.assertFalse(result["coverage_complete"])
        self.assertFalse(result["automatic_companion_cases"])

    def test_cached_session_reused_but_call_counts_are_per_source(self):
        p=protocol()
        first=api.capture_one(self.source,"knowcoder",p)
        second=api.capture_one(dict(self.source,id="another-source"),"knowcoder",p)
        self.assertEqual(FakeBackend.instances,1)
        self.assertEqual([first["model_calls"],second["model_calls"]],[1,1])

    def test_malformed_native_code_keeps_raw_and_actual_call(self):
        FakeBackend.payload="__import__('os').system('false')"
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertFalse(result["parse_valid"])
        self.assertIn("__import__",result["raw_output"])
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(len(result["bound_inputs"]),1)

    def test_api_error_retains_raw_backend_receipt(self):
        FakeBackend.raises=True
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertEqual(result["model_calls"],1)
        self.assertEqual(result["raw_backend_error_response"]["token_ids"],[42])

    def test_truncation_is_not_an_empty_list_fallback(self):
        FakeBackend.payload="results = ["
        FakeBackend.truncated=True
        result=api.capture_one(self.source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"truncated")
        self.assertEqual(result["raw_output"],"results = [")
        self.assertFalse(result["parse_valid"])

    def test_frozen_prompt_drift_fails_before_generation(self):
        source=dict(self.source,inference_requests=[{"prompt":"changed"}])
        result=api.capture_one(source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(result["bound_inputs"],[])

    def test_multistage_budget_rejected_before_backend_creation(self):
        p=protocol()
        p["models"]["knowcoder"]["native_capture"]["allow_compiler_stages"]=True
        source={"id":"synthetic-count","condition":"number of people","passage":"Three people wait."}
        result=api.capture_one(source,"knowcoder",p)
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(FakeBackend.instances,0)

    def test_other_constructor_does_not_inherit_food_capability(self):
        source={"id":"synthetic-animal","condition":"type of animal","passage":"An otter swims."}
        result=api.capture_one(source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"unsupported")
        self.assertEqual(result["model_calls"],0)
        self.assertEqual(FakeBackend.instances,0)

    def test_same_id_with_changed_source_or_condition_has_zero_calls(self):
        for changed in (dict(self.source,passage="Changed public fixture."),dict(self.source,condition="type of animal")):
            result=api.capture_one(changed,"knowcoder",protocol())
            self.assertEqual(result["runtime_status"],"unsupported")
            self.assertEqual(result["model_calls"],0)
        self.assertEqual(FakeBackend.instances,0)

    def test_descriptor_mutation_invalidates_diagnostic_authorization(self):
        p=protocol();p["models"]["knowcoder"]["max_model_calls_per_source"]=2
        result=api.capture_one(self.source,"knowcoder",p)
        self.assertEqual(result["runtime_status"],"unsupported");self.assertEqual(FakeBackend.instances,0)

    def test_only_two_exact_receipt_pointer_fields_are_omitted_from_binding(self):
        p=protocol();descriptor=p["models"]["knowcoder"];original=api.authorization_binding(descriptor)
        descriptor["native_capture"]["diagnostic_authorization"]["receipt_path"]="other-locator"
        self.assertEqual(api.authorization_binding(descriptor),original)
        descriptor["native_capture"]["diagnostic_authorization"]["other_omitted_policy"]=True
        with self.assertRaises(ValueError):api.authorization_binding(descriptor)

    def test_fixed_prompt_profile_preserves_per_route_context_limits(self):
        from native_adapter.schema import bounded_input
        cfg=protocol()["models"]["knowcoder"]["native_capture"]
        spatial=api._compile("location of people",cfg);ordinary=api._compile("type of food",cfg)
        request=lambda plan,model,profile:bounded_input(plan,model,"Public synthetic fixture.",lambda text:20,profile="positive_anchor",prompt_profile=profile)
        self.assertEqual(request(spatial,"knowcoder",cfg["prompt_profile"])["context_limit"],4096)
        self.assertEqual(request(ordinary,"knowcoder",cfg["prompt_profile"])["context_limit"],2048)
        self.assertEqual(request(spatial,"gollie",cfg["contract_recipe"])["context_limit"],16384)

    def test_empty_source_failure_is_never_fabricated_abstention(self):
        FakeBackend.payload='results = []'
        source={"id":"empty-source","condition":"type of food","passage":""}
        result=api.capture_one(source,"knowcoder",protocol())
        self.assertEqual(result["runtime_status"],"error")
        self.assertEqual(result["model_calls"],0);self.assertFalse(result["parse_valid"])
        self.assertIsNone(result["normalized_evidence"]);self.assertIsNone(result["raw_output"])

    def test_second_backend_configuration_is_rejected_without_allocation(self):
        cfg=protocol()["models"]["knowcoder"]["native_capture"]
        api._session("knowcoder",cfg)
        with self.assertRaises(RuntimeError):api._session("gollie",cfg)
        self.assertEqual(FakeBackend.instances,1)


if __name__=="__main__":
    unittest.main()

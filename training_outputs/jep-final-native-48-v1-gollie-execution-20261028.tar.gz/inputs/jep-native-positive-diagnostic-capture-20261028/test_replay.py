"""Inert raw-token replay proofs; synthetic data and fake model outputs only."""
from copy import deepcopy
import json
import unittest
from unittest.mock import patch
import native_capture as api
import native_capture_backends as backends
from test_api import protocol


class TokenizedFakeBackend:
    payload=' results = [Food("sandwich"), Food("pickle")]'
    forced_truncation=False
    raises=False
    def __init__(self,model,cfg):
        self.codec,self.pinned=api._cpu_codec(model,cfg)
        self.calls=0
        self.last_raw=None
        index=json.loads((self.pinned/'pytorch_model.bin.index.json').read_text())
        selected=set(index['weight_map'].values())
        info=json.loads((self.pinned/'model-info.json').read_text())
        checks={r['rfilename']:{'recomputed_sha256':r['lfs']['sha256'],'size':r['lfs']['size'],
                'full_file_hash_recomputed':True} for r in info['siblings'] if r['rfilename'] in selected}
        self.metadata={'checkpoint':{'model_id':cfg['model_id'],'revision':cfg['revision']},
            'runtime_manifest_sha256':cfg['runtime_manifest_sha256'],
            'versions':{'vllm':'0.2.2+cu118','torch':'2.1.0+cu118','transformers':'4.34.1','tokenizers':'0.14.1'},
            'engine_kwargs':{'max_num_seqs':4,'max_model_len':4096,'max_num_batched_tokens':16384,
                'dtype':'auto','gpu_memory_utilization':0.6,'tokenizer_mode':'auto','trust_remote_code':True},
            'snapshot_audit':{'shard_file_checks':checks}}
    def count_tokens(self,prompt):
        return self.codec.count_tokens(prompt)
    def generate(self,bound):
        self.calls+=1
        inputs=self.codec.encode(bound['prompt'])
        if self.raises:
            self.last_raw={"error":"synthetic backend error"}
            raise RuntimeError("synthetic backend error")
        outputs=self.codec.encode(self.payload)[1:]
        if self.forced_truncation:outputs=outputs*(bound['max_new_tokens']//len(outputs)+1);outputs=outputs[:bound['max_new_tokens']]
        else:outputs+=[2]
        raw=self.codec.decode(outputs,skip_special_tokens=True)
        return {'payload':raw,'api_text':raw,'input_token_ids':inputs,'output_token_ids':outputs,
            'input_tokens':len(inputs),'output_tokens':len(outputs),'truncated':self.forced_truncation,'stop_reason':'length' if self.forced_truncation else 'stop',
            'raw_decoded_generation':raw,'raw_decode_with_special_tokens':self.codec.decode(outputs),
            'author_projection':backends.know_support.author_projection(self.codec,inputs,outputs),
            'generation_options':{'n':1,'best_of':1,'temperature':0.0,'stop':'"""','max_tokens':bound['max_new_tokens']}}


class ReplayTests(unittest.TestCase):
    def setUp(self):
        api._SESSIONS.clear()
        TokenizedFakeBackend.payload=' results = [Food("sandwich"), Food("pickle")]'
        TokenizedFakeBackend.forced_truncation=TokenizedFakeBackend.raises=False
        self.source={'id':'synthetic-food','condition':'type of food','passage':'A sandwich and a pickle are on the tray.'}
        self.protocol=protocol()
        with patch.object(api,'BACKEND_FACTORY',TokenizedFakeBackend):
            self.record=api.capture_one(self.source,'knowcoder',self.protocol)
        self.assertEqual(self.record['runtime_status'],'ok',self.record['error'])
    def replay(self,record=None):
        with patch.object(api,'BACKEND_FACTORY',side_effect=AssertionError('CPU verifier called model backend')):
            return api.verify_normalize_record(self.source,'knowcoder',self.protocol,record or self.record)
    def test_failure_captures_replay_as_failures_without_backend(self):
        for failure in ('malformed','truncated','backend'):
            api._SESSIONS.clear()
            TokenizedFakeBackend.payload="__import__('os').system('false')" if failure=='malformed' else 'results = ['
            TokenizedFakeBackend.forced_truncation=failure=='truncated'
            TokenizedFakeBackend.raises=failure=='backend'
            with patch.object(api,'BACKEND_FACTORY',TokenizedFakeBackend):
                record=api.capture_one(self.source,'knowcoder',self.protocol)
            self.assertEqual(record['runtime_status'],'truncated' if failure=='truncated' else 'error')
            self.assertIsNone(self.replay(record))
            bad=deepcopy(record);bad['parse_valid']=True
            with self.assertRaises(ValueError):self.replay(bad)
    def test_recomputes_normalized_claims_without_backend(self):
        self.assertEqual(self.replay(),self.record['normalized_evidence'])
    def test_saved_normalization_tampering_rejected(self):
        r=deepcopy(self.record);r['normalized_evidence']={}
        with self.assertRaises(ValueError): self.replay(r)
    def test_raw_token_id_tampering_rejected(self):
        r=deepcopy(self.record);r['stage_outputs'][0]['generated']['output_token_ids'][1]=99
        with self.assertRaises(ValueError): self.replay(r)
    def test_prompt_and_generation_option_tampering_rejected(self):
        for field in ('prompt','options'):
            r=deepcopy(self.record)
            if field=='prompt':r['bound_inputs'][0]['prompt']+=' changed'
            else:r['stage_outputs'][0]['generated']['generation_options']['temperature']=1
            with self.assertRaises(ValueError):self.replay(r)
    def test_actual_shard_identity_tampering_rejected(self):
        r=deepcopy(self.record)
        next(iter(r['backend_metadata']['snapshot_audit']['shard_file_checks'].values()))['recomputed_sha256']='0'*64
        with self.assertRaises(ValueError):self.replay(r)
    def test_raw_presentation_cannot_replace_native_outputs(self):
        r=deepcopy(self.record);r['raw_output']='results = []'
        with self.assertRaises(ValueError):self.replay(r)
    def test_arbitrary_gate_hash_does_not_enable_route(self):
        cfg=self.protocol['models']['knowcoder']['native_capture']
        cfg['diagnostic_authorization']['receipt_sha256']='a'*64
        with patch.object(api,'BACKEND_FACTORY',TokenizedFakeBackend):
            r=api.capture_one(self.source,'knowcoder',self.protocol)
        self.assertEqual(r['model_calls'],0)
        self.assertEqual(r['runtime_status'],'unsupported')
        api.verify_normalize_record(self.source,'knowcoder',self.protocol,r)
        r.update(runtime_status='ok',parse_valid=True,normalized_evidence={})
        with self.assertRaises(ValueError):api.verify_normalize_record(self.source,'knowcoder',self.protocol,r)

if __name__=='__main__': unittest.main()
